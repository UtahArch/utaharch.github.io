/*------------------------------------------------------------
 *                             CACTI 5.2
 *         Copyright 2008 Hewlett-Packard Development Corporation
 *                         All Rights Reserved
 *
 * Permission to use, copy, and modify this software and its documentation is
 * hereby granted only under the following terms and conditions.  Both the
 * above copyright notice and this permission notice must appear in all copies
 * of the software, derivative works or modified versions, and any portions
 * thereof, and both notices must appear in supporting documentation.
 *
 * Users of this software agree to the terms and conditions set forth herein, and
 * hereby grant back to Hewlett-Packard Company and its affiliated companies ("HP")
 * a non-exclusive, unrestricted, royalty-free right and license under any changes, 
 * enhancements or extensions  made to the core functions of the software, including 
 * but not limited to those affording compatibility with other hardware or software
 * environments, but excluding applications which incorporate this software.
 * Users further agree to use their best efforts to return to HP any such changes,
 * enhancements or extensions that they make and inform HP of noteworthy uses of
 * this software.  Correspondence should be provided to HP at:
 *
 *                       Director of Intellectual Property Licensing
 *                       Office of Strategy and Technology
 *                       Hewlett-Packard Company
 *                       1501 Page Mill Road
 *                       Palo Alto, California  94304
 *
 * This software may be distributed (but not offered for sale or transferred
 * for compensation) to third parties, provided such third parties agree to
 * abide by the terms and conditions of this notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND HP DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS.   IN NO EVENT SHALL HP 
 * CORPORATION BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 *------------------------------------------------------------*/

#include "basic_circuit.h"

double wire_resistance(double resistivity, double wire_width, double wire_thickness,
				double barrier_thickness, double dishing_thickness, double alpha_scatter)
{
	double resistance;
  resistance = alpha_scatter * resistivity /((wire_thickness - barrier_thickness - dishing_thickness)*(wire_width - 2 * barrier_thickness));
  return(resistance);
}

double wire_capacitance(double wire_width, double wire_thickness, double wire_spacing, 
				 double ild_thickness, double miller_value, double horiz_dielectric_constant,
				 double vert_dielectric_constant, double fringe_cap)
{
	double vertical_cap, sidewall_cap, total_cap;
	vertical_cap = 2 * PERMITTIVITY_FREE_SPACE * vert_dielectric_constant * wire_width / ild_thickness;
	sidewall_cap = 2 * PERMITTIVITY_FREE_SPACE * miller_value * horiz_dielectric_constant * wire_thickness / wire_spacing;
	total_cap = vertical_cap + sidewall_cap + fringe_cap;
	return(total_cap);
}


void init_tech_params(double technology)
{
	int i, iter;
	double tech, tech_low, tech_high, alpha;
	int int_tech_low, int_tech_high;
	double  aspect_ratio, wire_width, wire_thickness, wire_spacing, barrier_thickness, dishing_thickness,
		alpha_scatter, ild_thickness, miller_value = 1.5, horiz_dielectric_constant, vert_dielectric_constant,
		fringe_cap, pmos_to_nmos_sizing_r;

	FEATURESIZE = technology;
	technology = technology * 1000.0;
	
	if(technology < 91 && technology > 89){
		tech_low = 90;
		tech_high = 90;
	}
	else if(technology < 66 && technology > 64){
		tech_low = 65;
		tech_high = 65;
	}
	else if(technology < 46 && technology > 44){
		tech_low = 45;
		tech_high = 45;
	}
	else if(technology < 33 && technology > 31){
		tech_low = 32;
		tech_high = 32;
	}
	else if(technology < 110 && technology > 90){
		tech_low = 110;
		tech_high = 90;
	}
	else if(technology < 90 && technology > 65){
		tech_low = 90;
		tech_high = 65;
	}
	else if(technology < 65 && technology > 45){
		tech_low = 65;
		tech_high = 45;
	}
	else if(technology < 45 && technology > 32){
		tech_low = 45;
		tech_high = 32;
	}

	for(iter=0; iter<=1; ++iter){
		if(iter==0){
			tech = tech_low;
		}
		else{
			tech = tech_high;
		}

	if(tech < 91 && tech > 89){//90nm technology-node. Corresponds to year 2004 in ITRS
			//ITRS HP device type
			vdd[0] = 1.2;
			Lphy[0] = 0.037;//Lphy is the physical gate-length. micron
			Lelec[0] = 0.0266;//Lelec is the electrical gate-length. micron
			t_ox[0] = 1.2e-3;//micron
			v_th[0] = 0.23707;//V
			c_ox[0] = 1.79e-14;//F/micron2
			mobility_eff[0] = 342.16 * (1e-2 * 1e6 * 1e-2 * 1e6); //micron2 / Vs
			Vdsat[0] = 0.128; //V
			c_g_ideal[0] = 6.64e-16;//F/micron
			c_fringe[0] = 0.08e-15;//F/micron
			c_junc[0] = 1e-15;//F/micron2
		    I_on_n[0] = 1076.9e-6;//A/micron
			I_on_p[0] = 712.6e-6;//A/micron
			//Note that nmos_effective_resistance_multiplier, nmos_to_pmos_effective_current_drive_ratio and gmp_to_gmn_multiplier values are calculated offline
			nmos_effective_resistance_multiplier = 1.54;
			nmos_to_pmos_effective_current_drive_ratio[0] = 2.45;
			gmp_to_gmn_multiplier[0] = 1.22;
			Rnchannelon[0] = nmos_effective_resistance_multiplier * vdd[0] / I_on_n[0];//ohm-micron
			Rpchannelon[0] = nmos_to_pmos_effective_current_drive_ratio[0] * Rnchannelon[0];//ohm-micron
			I_off_n[0][0] = 3.24e-8 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;//A/micron
			I_off_n[0][10] = 4.01e-8 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][20] = 4.90e-8 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][30] = 5.92e-8 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][40] = 7.08e-8 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][50] = 8.38e-8 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][60] = 9.82e-8 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;;
			I_off_n[0][70] = 1.14e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][80] = 1.29e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][90] = 1.43e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][100] = 1.54e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			for(i = 0; i <= 100; i += 10){
				I_off_p[0][i] = I_off_n[0][i]; 
			}
			
			//ITRS LSTP device type
			vdd[1] = 1.3;
			Lphy[1] = 0.075;
			Lelec[1] = 0.0486;
			t_ox[1] = 2.2e-3;
			v_th[1] = 0.48203;
			c_ox[1] = 1.22e-14;
			mobility_eff[1] = 356.76 * (1e-2 * 1e6 * 1e-2 * 1e6);
			Vdsat[1] = 0.373; 
			c_g_ideal[1] = 9.15e-16;
			c_fringe[1] = 0.08e-15;
			c_junc[1] = 1e-15;
			I_on_n[1] = 503.6e-6;
			I_on_p[1] = 235.1e-6;
			nmos_effective_resistance_multiplier = 1.92;
			nmos_to_pmos_effective_current_drive_ratio[1] = 2.44;
			gmp_to_gmn_multiplier[1] =0.88;
			Rnchannelon[1] = nmos_effective_resistance_multiplier * vdd[1] / I_on_n[1];
			Rpchannelon[1] = nmos_to_pmos_effective_current_drive_ratio[1] * Rnchannelon[1];
			I_off_n[1][0] = 2.81e-12;
			I_off_n[1][10] = 4.76e-12;
			I_off_n[1][20] = 7.82e-12;
			I_off_n[1][30] = 1.25e-11;
			I_off_n[1][40] = 1.94e-11;
			I_off_n[1][50] = 2.94e-11;
			I_off_n[1][60] = 4.36e-11;
			I_off_n[1][70] = 6.32e-11;
			I_off_n[1][80] = 8.95e-11;
			I_off_n[1][90] = 1.25e-10;
			I_off_n[1][100] = 1.7e-10;
			for(i = 0; i <= 100; i += 10){
				I_off_p[1][i] = I_off_n[1][i]; 
			}

			//ITRS LOP device type
			vdd[2] = 0.9;
			Lphy[2] = 0.053;
			Lelec[2] = 0.0354;
			t_ox[2] = 1.5e-3;
			v_th[2] = 0.30764;
			c_ox[2] = 1.59e-14;
			mobility_eff[2] = 460.39 * (1e-2 * 1e6 * 1e-2 * 1e6);
			Vdsat[2] = 0.113; 
			c_g_ideal[2] = 8.45e-16;
			c_fringe[2] = 0.08e-15;
			c_junc[2] = 1e-15;
			I_on_n[2] = 386.6e-6;
			I_on_p[2] = 209.7e-6;
			nmos_effective_resistance_multiplier = 1.77;
			nmos_to_pmos_effective_current_drive_ratio[2] = 2.54;
			gmp_to_gmn_multiplier[2] = 0.98;
			Rnchannelon[2] = nmos_effective_resistance_multiplier * vdd[2] / I_on_n[2];
			Rpchannelon[2] = nmos_to_pmos_effective_current_drive_ratio[2] * Rnchannelon[2];
			I_off_n[2][0] = 2.14e-9;
			I_off_n[2][10] = 2.9e-9;
			I_off_n[2][20] = 3.87e-9;
			I_off_n[2][30] = 5.07e-9;
			I_off_n[2][40] = 6.54e-9;
			I_off_n[2][50] = 8.27e-8;
			I_off_n[2][60] = 1.02e-7;
			I_off_n[2][70] = 1.20e-7;
			I_off_n[2][80] = 1.36e-8;
			I_off_n[2][90] = 1.52e-8;
			I_off_n[2][100] = 1.73e-8;
			for(i = 0; i <= 100; i += 10){
				I_off_p[2][i] = I_off_n[2][i]; 
			}

			
			if(ram_cell_tech_flavor == 3){
				//LP-DRAM cell access transistor technology parameters
				vdd_dram_cell = 1.2;
				Lphy[3] = 0.12;
				Lelec[3] = 0.756;
				v_th_dram_access_transistor = 0.4545;
				width_dram_access_transistor = 0.14;
				I_on_dram_cell = 45e-6;
				I_off_dram_cell_worst_case_length_temp = 21.1e-12;
				Wmemcella_dram = width_dram_access_transistor;
				Wmemcellpmos_dram = 0;
				Wmemcellnmos_dram = 0;
				area_cell_dram = 0.168;
				asp_ratio_cell_dram = 1.46; 
				c_dram_cell = 20e-15;

				//LP-DRAM wordline transistor parameters
				vpp = 1.6;
				t_ox[3] = 2.2e-3;
				v_th[3] = 0.4545;
				c_ox[3] = 1.22e-14;
				mobility_eff[3] =  323.95 * (1e-2 * 1e6 * 1e-2 * 1e6);
				Vdsat[3] = 0.3; 
				c_g_ideal[3] = 1.47e-15;
				c_fringe[3] = 0.08e-15;
				c_junc[3] = 1e-15;
				I_on_n[3] = 321.6e-6;
				I_on_p[3] = 203.3e-6;
				nmos_effective_resistance_multiplier = 1.65;
				nmos_to_pmos_effective_current_drive_ratio[3] = 1.95;
				gmp_to_gmn_multiplier[3] = 0.90;
				Rnchannelon[3] = nmos_effective_resistance_multiplier * vpp / I_on_n[3];
				Rpchannelon[3] = nmos_to_pmos_effective_current_drive_ratio[3] * Rnchannelon[3];
				I_off_n[3][0] = 1.42e-11; 
				I_off_n[3][10] = 2.25e-11;
				I_off_n[3][20] = 3.46e-11;
				I_off_n[3][30] = 5.18e-11;
				I_off_n[3][40] = 7.58e-11;
				I_off_n[3][50] = 1.08e-10;
				I_off_n[3][60] = 1.51e-10;
				I_off_n[3][70] = 2.02e-10;
				I_off_n[3][80] = 2.57e-10;
				I_off_n[3][90] = 3.14e-10;
				I_off_n[3][100] = 3.85e-10;
				for(i = 0; i <= 100; i += 10){
					I_off_p[3][i] = I_off_n[3][i]; 
				}
			}
			else if(ram_cell_tech_flavor == 4){
				//COMM-DRAM cell access transistor technology parameters
				vdd_dram_cell = 1.6;
				Lphy[3] = 0.09;//micron
				Lelec[3] = 0.0576;//micron. 
				v_th_dram_access_transistor = 1;//V
				width_dram_access_transistor = 0.09;//micron
				I_on_dram_cell = 20e-6;
				I_off_dram_cell_worst_case_length_temp = 1e-15;//A
				Wmemcella_dram = width_dram_access_transistor;
				Wmemcellpmos_dram = 0;
				Wmemcellnmos_dram = 0;
				area_cell_dram = 6*0.09*0.09;//micron2. 
				asp_ratio_cell_dram = 0.667; 
				c_dram_cell = 30e-15;

				//COMM-DRAM wordline transistor technology parameters 
				vpp = 3.7;//vpp. V
				t_ox[3] = 5.5e-3;//micron
				v_th[3] = 1.0;//V
				c_ox[3] = 5.65e-15;//F/micron2
				mobility_eff[3] =  302.2 * (1e-2 * 1e6 * 1e-2 * 1e6);//micron2 / Vs
				Vdsat[3] = 0.32; //V/micron
				c_g_ideal[3] = 5.08e-16;//F/micron
				c_fringe[3] = 0.08e-15;//F/micron
				c_junc[3] = 1e-15;//F/micron2
				I_on_n[3] = 1094.3;//A/micron
				I_on_p[3] = I_on_n[3] / 2;
				nmos_effective_resistance_multiplier = 1.62;
				nmos_to_pmos_effective_current_drive_ratio[3] = 2.05;
				gmp_to_gmn_multiplier[3] = 0.90;
				Rnchannelon[3] = nmos_effective_resistance_multiplier * vpp / I_on_n[3];//ohm-micron
				Rpchannelon[3] = nmos_to_pmos_effective_current_drive_ratio[3] * Rnchannelon[3];//ohm-micron
				I_off_n[3][0] = 1.42e-11; //A/micron
				I_off_n[3][10] = 2.25e-11;
				I_off_n[3][20] = 3.46e-11;
				I_off_n[3][30] = 5.18e-11;
				I_off_n[3][40] = 7.58e-11;
				I_off_n[3][50] = 1.08e-10;
				I_off_n[3][60] = 2.66e-13;
				I_off_n[3][70] = 2.02e-10;
				I_off_n[3][80] = 2.57e-10;
				I_off_n[3][90] = 3.14e-10;
				I_off_n[3][100] = 3.85e-10;;
				for(i = 0; i <= 100; i += 10){
					I_off_p[3][i] = I_off_n[3][i]; 
				}
			}

			//SRAM cell properties
			Wmemcella_sram = 1.31 * FEATURESIZE;
			Wmemcellpmos_sram = 1.23 * FEATURESIZE;
			Wmemcellnmos_sram = 2.08 * FEATURESIZE;
			area_cell_sram = 146 * FEATURESIZE * FEATURESIZE;
			asp_ratio_cell_sram = 1.46;
	
	}

	if(tech < 66 && tech > 64){//65nm technology-node. Corresponds to year 2007 in ITRS
		//ITRS HP device type
		vdd[0] = 1.1;
		Lphy[0] = 0.025;
		Lelec[0] = 0.019;
		t_ox[0] = 1.1e-3;
		v_th[0] = .19491;
		c_ox[0] = 1.88e-14;
		mobility_eff[0] = 436.24 * (1e-2 * 1e6 * 1e-2 * 1e6); 
		Vdsat[0] = 7.71e-2; 
		c_g_ideal[0] = 4.69e-16;
		c_fringe[0] = 0.077e-15;
		c_junc[0] = 1e-15;
		I_on_n[0] = 1197.2e-6;
		I_on_p[0] = 870.8e-6;
		nmos_effective_resistance_multiplier = 1.50;
		nmos_to_pmos_effective_current_drive_ratio[0] = 2.41;
		gmp_to_gmn_multiplier[0] = 1.38;
		Rnchannelon[0] = nmos_effective_resistance_multiplier * vdd[0] / I_on_n[0];
		Rpchannelon[0] = nmos_to_pmos_effective_current_drive_ratio[0] * Rnchannelon[0];
		I_off_n[0][0] = 1.96e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		I_off_n[0][10] = 2.29e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		I_off_n[0][20] = 2.66e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		I_off_n[0][30] = 3.05e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		I_off_n[0][40] = 3.49e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		I_off_n[0][50] = 3.95e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		I_off_n[0][60] = 4.45e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		I_off_n[0][70] = 4.97e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		I_off_n[0][80] = 5.48e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		I_off_n[0][90] = 5.94e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		I_off_n[0][100] = 6.3e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
		for(i = 0; i <= 100; i += 10){
			I_off_p[0][i] = I_off_n[0][i]; 
		}

		//ITRS LSTP device type
		vdd[1] = 1.2;
		Lphy[1] = 0.045;
		Lelec[1] = 0.0298;
		t_ox[1] = 1.9e-3;
		v_th[1] = 0.52354;
		c_ox[1] = 1.36e-14;
		mobility_eff[1] = 341.21 * (1e-2 * 1e6 * 1e-2 * 1e6); 
		Vdsat[1] = 0.128; 
		c_g_ideal[1] = 6.14e-16;
		c_fringe[1] = 0.08e-15;
		c_junc[1] = 1e-15;
		I_on_n[1] = 519.2e-6;
		I_on_p[1] = 266e-6;
		nmos_effective_resistance_multiplier = 1.96;
		nmos_to_pmos_effective_current_drive_ratio[1] = 2.23;
		gmp_to_gmn_multiplier[1] = 0.99;
		Rnchannelon[1] = nmos_effective_resistance_multiplier * vdd[1] / I_on_n[1];
		Rpchannelon[1] = nmos_to_pmos_effective_current_drive_ratio[1] * Rnchannelon[1];
		I_off_n[1][0] = 9.12e-12;
		I_off_n[1][10] = 1.49e-11;
		I_off_n[1][20] = 2.36e-11;
		I_off_n[1][30] = 3.64e-11;
		I_off_n[1][40] = 5.48e-11;
		I_off_n[1][50] = 8.05e-11;
		I_off_n[1][60] = 1.15e-10;
		I_off_n[1][70] = 1.59e-10;
		I_off_n[1][80] = 2.1e-10;
		I_off_n[1][90] = 2.62e-10;
		I_off_n[1][100] = 3.21e-10;
		for(i = 0; i <= 100; i += 10){
			I_off_p[1][i] = I_off_n[1][i]; 
		}

		//ITRS LOP device type
		vdd[2] = 0.8;
		Lphy[2] = 0.032;
		Lelec[2] = 0.0216;
		t_ox[2] = 1.2e-3;
		v_th[2] = 0.28512;
		c_ox[2] = 1.87e-14;
		mobility_eff[2] = 495.19 * (1e-2 * 1e6 * 1e-2 * 1e6); 
		Vdsat[2] = 0.292; 
		c_g_ideal[2] = 6e-16;
		c_fringe[2] = 0.08e-15;
		c_junc[2] = 1e-15;
		I_on_n[2] = 573.1e-6;
		I_on_p[2] = 340.6e-6;
		nmos_effective_resistance_multiplier = 1.82;
		nmos_to_pmos_effective_current_drive_ratio[2] = 2.28;
		gmp_to_gmn_multiplier[2] = 1.11;
		Rnchannelon[2] = nmos_effective_resistance_multiplier * vdd[2] / I_on_n[2];
		Rpchannelon[2] = nmos_to_pmos_effective_current_drive_ratio[2] * Rnchannelon[2];
		I_off_n[2][0] = 4.9e-9;
		I_off_n[2][10] = 6.49e-9;
		I_off_n[2][20] = 8.45e-9;
		I_off_n[2][30] = 1.08e-8;
		I_off_n[2][40] = 1.37e-8;
		I_off_n[2][50] = 1.71e-8;
		I_off_n[2][60] = 2.09e-8;
		I_off_n[2][70] = 2.48e-8;
		I_off_n[2][80] = 2.84e-8;
		I_off_n[2][90] = 3.13e-8;
		I_off_n[2][100] = 3.42e-8;
		for(i = 0; i <= 100; i += 10){
			I_off_p[2][i] = I_off_n[2][i]; 
		}

		if(ram_cell_tech_flavor == 3){
			//LP-DRAM cell access transistor technology parameters
			vdd_dram_cell = 1.2;
			Lphy[3] = 0.12;
			Lelec[3] = 0.756;
			v_th_dram_access_transistor = 0.43806;
			width_dram_access_transistor = 0.09;
			I_on_dram_cell = 36e-6;
			I_off_dram_cell_worst_case_length_temp = 19.6e-12;
			Wmemcella_dram = width_dram_access_transistor;
			Wmemcellpmos_dram = 0;
			Wmemcellnmos_dram = 0;
			area_cell_dram = 0.11;
			asp_ratio_cell_dram = 1.46; 
			c_dram_cell = 20e-15;

			//LP-DRAM wordline transistor parameters
			vpp = 1.6;
			t_ox[3] = 2.2e-3;
			v_th[3] = 0.43806;
			c_ox[3] = 1.22e-14;
			mobility_eff[3] =  328.32 * (1e-2 * 1e6 * 1e-2 * 1e6);
			Vdsat[3] = 0.43806; 
			c_g_ideal[3] = 1.46e-15;
			c_fringe[3] = 0.08e-15;
			c_junc[3] = 1e-15 ;
			I_on_n[3] = 399.8e-6;
			I_on_p[3] = 243.4e-6;
			nmos_effective_resistance_multiplier = 1.65;
			nmos_to_pmos_effective_current_drive_ratio[3] = 2.05;
			gmp_to_gmn_multiplier[3] = 0.90;
			Rnchannelon[3] = nmos_effective_resistance_multiplier * vpp / I_on_n[3];
			Rpchannelon[3] = nmos_to_pmos_effective_current_drive_ratio[3] * Rnchannelon[3];
			I_off_n[3][0] = 2.23e-11; 
			I_off_n[3][10] = 3.46e-11;
			I_off_n[3][20] = 5.24e-11;
			I_off_n[3][30] = 7.75e-11;
			I_off_n[3][40] = 1.12e-10;
			I_off_n[3][50] = 1.58e-10;
			I_off_n[3][60] = 2.18e-10;
			I_off_n[3][70] = 2.88e-10;
			I_off_n[3][80] = 3.63e-10;
			I_off_n[3][90] = 4.41e-10;
			I_off_n[3][100] = 5.36e-10;
			for(i = 0; i <= 100; i += 10){
				I_off_p[3][i] = I_off_n[3][i]; 
			}
		}
		else if(ram_cell_tech_flavor == 4){
			//COMM-DRAM cell access transistor technology parameters
			vdd_dram_cell = 1.3;
			Lphy[3] = 0.065;//micron
			Lelec[3] = 0.0426;//micron. 
			v_th_dram_access_transistor = 1;//V
			width_dram_access_transistor = 0.065;//micron
			I_on_dram_cell = 20e-6;
			I_off_dram_cell_worst_case_length_temp = 1e-15;//A
			Wmemcella_dram = width_dram_access_transistor;
			Wmemcellpmos_dram = 0;
			Wmemcellnmos_dram = 0;
			area_cell_dram = 6*0.065*0.065;//micron2. 
			asp_ratio_cell_dram = 0.667; 
			c_dram_cell = 30e-15;

			//COMM-DRAM cell access transistor technology parameters 
			vpp = 3.3;//vpp. V
			t_ox[3] = 5e-3;//micron
			v_th[3] = 1.0;//V
			c_ox[3] = 6.16e-15;//F/micron2
			mobility_eff[3] =  303.44 * (1e-2 * 1e6 * 1e-2 * 1e6);//micron2 / Vs
			Vdsat[3] = 0.385; //V/micron
			c_g_ideal[3] = 4e-16;//F/micron
			c_fringe[3] = 0.08e-15;//F/micron
			c_junc[3] = 1e-15;//F/micron2
			I_on_n[3] = 1031e-6;//A/micron
			I_on_p[3] = I_on_n[3] / 2;
			nmos_effective_resistance_multiplier = 1.69;
			nmos_to_pmos_effective_current_drive_ratio[3] = 2.39;
			gmp_to_gmn_multiplier[3] = 0.90;
			Rnchannelon[3] = nmos_effective_resistance_multiplier * vpp / I_on_n[3];//ohm-micron
			Rpchannelon[3] = nmos_to_pmos_effective_current_drive_ratio[3] * Rnchannelon[3];//ohm-micron
			I_off_n[3][0] = 1.42e-11; //A/micron
			I_off_n[3][10] = 2.25e-11;
			I_off_n[3][20] = 3.46e-11;
			I_off_n[3][30] = 5.18e-11;
			I_off_n[3][40] = 7.58e-11;
			I_off_n[3][50] = 1.08e-10;
			I_off_n[3][60] = 6.89e-13;
			I_off_n[3][70] = 2.02e-10;
			I_off_n[3][80] = 2.57e-10;
			I_off_n[3][90] = 3.14e-10;
			I_off_n[3][100] = 6.89e-13;
			for(i = 0; i <= 100; i += 10){
				I_off_p[3][i] = I_off_n[3][i]; 
			}
		}

		//SRAM cell properties 
		Wmemcella_sram = 1.31 * FEATURESIZE;
		Wmemcellpmos_sram = 1.23 * FEATURESIZE;
		Wmemcellnmos_sram = 2.08 * FEATURESIZE;
		area_cell_sram = 146 * FEATURESIZE * FEATURESIZE;
		asp_ratio_cell_sram = 1.46;
		}

		if(tech < 46 && tech > 44){//45nm technology-node. Corresponds to year 2010 in ITRS
			//ITRS HP device type
			vdd[0] = 1.0;
			Lphy[0] = 0.018;
			Lelec[0] = 0.01345;
			t_ox[0] = 0.65e-3;
			v_th[0] = .18035;
			c_ox[0] = 3.77e-14;
			mobility_eff[0] = 266.68 * (1e-2 * 1e6 * 1e-2 * 1e6); 
			Vdsat[0] = 9.38E-2; 
			c_g_ideal[0] = 6.78e-16;
			c_fringe[0] = 0.05e-15;
			c_junc[0] = 1e-15;
			I_on_n[0] = 2046.6e-6;
			//There are certain problems with the ITRS PMOS numbers in MASTAR for 45nm. So we are using 65nm values of
			//nmos_to_pmos_effective_current_drive_ratio and gmp_to_gmn_multiplier for 45nm
			I_on_p[0] = I_on_n[0] / 2;//This value is fixed arbitrarily but I_on_p is not being used in CACTI
			nmos_effective_resistance_multiplier = 1.51;
			nmos_to_pmos_effective_current_drive_ratio[0] = 2.41;
			gmp_to_gmn_multiplier[0] = 1.38;
			Rnchannelon[0] = nmos_effective_resistance_multiplier * vdd[0] / I_on_n[0];
			Rpchannelon[0] = nmos_to_pmos_effective_current_drive_ratio[0] * Rnchannelon[0];
			I_off_n[0][0] = 2.8e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][10] = 3.28e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][20] = 3.81e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][30] = 4.39e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][40] = 5.02e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][50] = 5.69e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][60] = 6.42e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][70] = 7.2e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][80] = 8.03e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][90] = 8.91e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			I_off_n[0][100] = 9.84e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
			for(i = 0; i <= 100; i += 10){
				I_off_p[0][i] = I_off_n[0][i]; 
			}

			//ITRS LSTP device type
			vdd[1] = 1.1;
			Lphy[1] =  0.028;
			Lelec[1] = 0.0212;
			t_ox[1] = 1.4e-3;
			v_th[1] = 0.50245;
			c_ox[1] = 2.01e-14;
			mobility_eff[1] =  363.96 * (1e-2 * 1e6 * 1e-2 * 1e6); 
			Vdsat[1] = 9.12e-2; 
			c_g_ideal[1] = 5.18e-16;
			c_fringe[1] = 0.08e-15;
			c_junc[1] = 1e-15;
			I_on_n[1] = 666.2e-6;
			I_on_p[1] = I_on_n[1] / 2;
			nmos_effective_resistance_multiplier = 1.99;
			nmos_to_pmos_effective_current_drive_ratio[1] = 2.23;
			gmp_to_gmn_multiplier[1] = 0.99;
			Rnchannelon[1] = nmos_effective_resistance_multiplier * vdd[1] / I_on_n[1];
			Rpchannelon[1] = nmos_to_pmos_effective_current_drive_ratio[1] * Rnchannelon[1];
			I_off_n[1][0] = 1.01e-11;
			I_off_n[1][10] = 1.65e-11;
			I_off_n[1][20] = 2.62e-11;
			I_off_n[1][30] = 4.06e-11;
			I_off_n[1][40] = 6.12e-11;
			I_off_n[1][50] = 9.02e-11;
			I_off_n[1][60] = 1.3e-10;
			I_off_n[1][70] = 1.83e-10;
			I_off_n[1][80] = 2.51e-10;
			I_off_n[1][90] = 3.29e-10;
			I_off_n[1][100] = 4.1e-10;
			for(i = 0; i <= 100; i += 10){
				I_off_p[1][i] = I_off_n[1][i]; 
			}

			//ITRS LOP device type
			vdd[2] = 0.7;
			Lphy[2] = 0.022;
			Lelec[2] = 0.016;
			t_ox[2] = 0.9e-3;
			v_th[2] = 0.22599;
			c_ox[2] = 2.82e-14;//F/micron2
			mobility_eff[2] = 508.9 * (1e-2 * 1e6 * 1e-2 * 1e6); 
			Vdsat[2] = 5.71e-2; 
			c_g_ideal[2] = 6.2e-16;
			c_fringe[2] = 0.073e-15;
			c_junc[2] = 1e-15;
			I_on_n[2] = 748.9e-6;
			I_on_p[2] = I_on_n[2] / 2;
			nmos_effective_resistance_multiplier = 1.76;
			nmos_to_pmos_effective_current_drive_ratio[2] = 2.28;
			gmp_to_gmn_multiplier[2] = 1.11;
			Rnchannelon[2] = nmos_effective_resistance_multiplier * vdd[2] / I_on_n[2];
			Rpchannelon[2] = nmos_to_pmos_effective_current_drive_ratio[2] * Rnchannelon[2];
			I_off_n[2][0] = 4.03e-9;
			I_off_n[2][10] = 5.02e-9;
			I_off_n[2][20] = 6.18e-9;
			I_off_n[2][30] = 7.51e-9;
			I_off_n[2][40] = 9.04e-9;
			I_off_n[2][50] = 1.08e-8;
			I_off_n[2][60] = 1.27e-8;
			I_off_n[2][70] = 1.47e-8;
			I_off_n[2][80] = 1.66e-8;
			I_off_n[2][90] = 1.84e-8;
			I_off_n[2][100] = 2.03e-8;
			for(i = 0; i <= 100; i += 10){
				I_off_p[2][i] = I_off_n[2][i]; 
			}

			if(ram_cell_tech_flavor == 3){
			//LP-DRAM cell access transistor technology parameters
			vdd_dram_cell = 1.1;
			Lphy[3] = 0.078;
			Lelec[3] = 0.0504;// Assume Lelec is 30% lesser than Lphy for DRAM access and wordline transistors.
			v_th_dram_access_transistor = 0.44559;
			width_dram_access_transistor = 0.079;
			I_on_dram_cell = 36e-6;//A
			I_off_dram_cell_worst_case_length_temp = 19.5e-12;
			Wmemcella_dram = width_dram_access_transistor;
			Wmemcellpmos_dram = 0;
			Wmemcellnmos_dram  = 0;
			area_cell_dram = width_dram_access_transistor * Lphy[3] * 10.0;
			asp_ratio_cell_dram = 1.46; 
			c_dram_cell = 20e-15;

			//LP-DRAM wordline transistor parameters
			vpp = 1.5;
			t_ox[3] = 2.1e-3;
			v_th[3] = 0.44559;
			c_ox[3] = 1.41e-14;
			mobility_eff[3] =   426.30 * (1e-2 * 1e6 * 1e-2 * 1e6);
			Vdsat[3] = 0.181; 
			c_g_ideal[3] = 1.10e-15;
			c_fringe[3] = 0.08e-15;
			c_junc[3] = 1e-15;
			I_on_n[3] = 456e-6;
			I_on_p[3] = I_on_n[3] / 2;
			nmos_effective_resistance_multiplier = 1.65;
			nmos_to_pmos_effective_current_drive_ratio[3] = 2.05;
			gmp_to_gmn_multiplier[3] = 0.90;
			Rnchannelon[3] = nmos_effective_resistance_multiplier * vpp / I_on_n[3];
			Rpchannelon[3] = nmos_to_pmos_effective_current_drive_ratio[3] * Rnchannelon[3];
			I_off_n[3][0] = 2.54e-11; 
			I_off_n[3][10] = 3.94e-11;
			I_off_n[3][20] = 5.95e-11;
			I_off_n[3][30] = 8.79e-11;
			I_off_n[3][40] = 1.27e-10;
			I_off_n[3][50] = 1.79e-10;
			I_off_n[3][60] = 2.47e-10;
			I_off_n[3][70] = 3.31e-10;
			I_off_n[3][80] = 4.26e-10;
			I_off_n[3][90] = 5.27e-10;
			I_off_n[3][100] = 6.46e-10;
			for(i = 0; i <= 100; i += 10){
				I_off_p[3][i] = I_off_n[3][i]; 
			}
			}

			else if(ram_cell_tech_flavor == 4){
			//COMM-DRAM cell access transistor technology parameters
			vdd_dram_cell = 1.1;
			Lphy[3] = 0.045;//micron
			Lelec[3] = 0.0298;//micron. 
			v_th_dram_access_transistor = 1;//V
			width_dram_access_transistor = 0.045;//micron
			I_on_dram_cell = 20e-6;
			I_off_dram_cell_worst_case_length_temp = 1e-15;//A
			Wmemcella_dram = width_dram_access_transistor;
			Wmemcellpmos_dram = 0;
			Wmemcellnmos_dram = 0;
			area_cell_dram = 6*0.045*0.045;//micron2. 
			asp_ratio_cell_dram = 0.667; 
			c_dram_cell = 30e-15;

			//COMM-DRAM wordline transistor technology parameters
			vpp = 2.7;//vpp. V
			t_ox[3] = 4e-3;//micron
			v_th[3] = 1.0;//V
			c_ox[3] = 7.98e-15;//F/micron2
			mobility_eff[3] =  368.58 * (1e-2 * 1e6 * 1e-2 * 1e6);//micron2 / Vs
			Vdsat[3] = 0.147; //V/micron
			c_g_ideal[3] = 3.59e-16;//F/micron
			c_fringe[3] = 0.08e-15;//F/micron
			c_junc[3] = 1e-15;//F/micron2
			I_on_n[3] = 999.4e-6;//A/micron
			I_on_p[3] = I_on_n[3] / 2;
			nmos_effective_resistance_multiplier = 1.69;
			nmos_to_pmos_effective_current_drive_ratio[3] = 1.95;
			gmp_to_gmn_multiplier[3] = 0.90;
			Rnchannelon[3] = nmos_effective_resistance_multiplier * vpp / I_on_n[3];//ohm-micron
			Rpchannelon[3] = nmos_to_pmos_effective_current_drive_ratio[3] * Rnchannelon[3];//ohm-micron
			I_off_n[3][0] = 1.42e-11; //A/micron
			I_off_n[3][10] = 2.25e-11;
			I_off_n[3][20] = 3.46e-11;
			I_off_n[3][30] = 5.18e-11;
			I_off_n[3][40] = 7.58e-11;
			I_off_n[3][50] = 1.08e-10;
			I_off_n[3][60] = 6.89e-13;
			I_off_n[3][70] = 2.02e-10;
			I_off_n[3][80] = 2.57e-10;
			I_off_n[3][90] = 3.14e-10;
			I_off_n[3][100] = 6.89e-13;
			for(i = 0; i <= 100; i += 10){
				I_off_p[3][i] = I_off_n[3][i]; 
			}
		}


			//SRAM cell properties 
			Wmemcella_sram = 1.31 * FEATURESIZE;
			Wmemcellpmos_sram = 1.23 * FEATURESIZE;
			Wmemcellnmos_sram = 2.08 * FEATURESIZE;
			area_cell_sram = 146 * FEATURESIZE * FEATURESIZE;
			asp_ratio_cell_sram = 1.46; 
			}

			if(tech < 33 && tech > 31){
				//For 2013, MPU/ASIC stagger-contacted M1 half-pitch is 32 nm (so this is 32 nm
				//technology i.e. FEATURESIZE = 0.032). Using the SOI process numbers for 
				//HP and LSTP.
				//32 nm HP
				vdd[0] = 0.9;
				Lphy[0] = 0.013;//Lphy is the physical gate-length.
				Lelec[0] = 0.01013;//Lelec is the electrical gate-length.
				t_ox[0] = 0.5e-3;//micron
				v_th[0] = 0.21835;//V
				c_ox[0] = 4.11e-14;//F/micron2
				mobility_eff[0] = 361.84 * (1e-2 * 1e6 * 1e-2 * 1e6); //micron2 / Vs
				Vdsat[0] = 5.09E-2; //V/micron
				c_g_ideal[0] = 5.34e-16;//F/micron
				c_fringe[0] = 0.04e-15;//F/micron
				c_junc[0] = 0;//F/micron2
				I_on_n[0] =  2211.7e-6;//A/micron
				I_on_p[0] = I_on_n[0] / 2;//A/micron
			    nmos_effective_resistance_multiplier = 1.49;
			    nmos_to_pmos_effective_current_drive_ratio[0] = 2.41;
			    gmp_to_gmn_multiplier[0] = 1.38;
			    Rnchannelon[0] = nmos_effective_resistance_multiplier * vdd[0] / I_on_n[0];//ohm-micron
			    Rpchannelon[0] = nmos_to_pmos_effective_current_drive_ratio[0] * Rnchannelon[0];//ohm-micron
				I_off_n[0][0] = 1.52e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				I_off_n[0][10] = 1.55e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				I_off_n[0][20] = 1.59e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				I_off_n[0][30] = 1.68e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				I_off_n[0][40] = 1.90e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				I_off_n[0][50] = 2.69e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				I_off_n[0][60] = 5.32e-7 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				I_off_n[0][70] = 1.02e-6 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				I_off_n[0][80] = 1.62e-6 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				I_off_n[0][90] = 2.73e-6 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				I_off_n[0][100] = 6.1e-6 / LEAKAGE_REDUCTION_DUE_TO_LONG_CHANNEL_HP_TRANSISTORS_FACTOR;
				for(i = 0; i <= 100; i += 10){
					I_off_p[0][i] = I_off_n[0][i]; 
				}

				//32 nm LSTP
				vdd[1] = 1;
				Lphy[1] = 0.020;
				Lelec[1] = 0.0173;//Lelec is the electrical gate-length.
				t_ox[1] = 1.2e-3;//micron
				v_th[1] = 0.513;//V
				c_ox[1] = 2.29e-14;//F/micron2
				mobility_eff[1] =  347.46 * (1e-2 * 1e6 * 1e-2 * 1e6); //micron2 / Vs
				Vdsat[1] = 8.64e-2; //V/micron
				c_g_ideal[1] = 4.58e-16;//F/micron
				c_fringe[1] = 0.053e-15;
				c_junc[1] = 1e-15;//F/micron2
				I_on_n[1] = 683.6e-6;//A/micron
				I_on_p[1] = I_on_n[1] / 2;
				nmos_effective_resistance_multiplier = 1.99;
				nmos_to_pmos_effective_current_drive_ratio[1] = 2.23;
				gmp_to_gmn_multiplier[1] = 0.99;
				Rnchannelon[1] = nmos_effective_resistance_multiplier * vdd[1] / I_on_n[1];//ohm-micron
				Rpchannelon[1] = nmos_to_pmos_effective_current_drive_ratio[1] * Rnchannelon[1];//ohm-micron
				I_off_n[1][0] = 2.06e-11;
				I_off_n[1][10] = 3.30e-11;
				I_off_n[1][20] = 5.15e-11;
				I_off_n[1][30] = 7.83e-11;
				I_off_n[1][40] = 1.16e-10;
				I_off_n[1][50] = 1.69e-10;
				I_off_n[1][60] = 2.40e-10;
				I_off_n[1][70] = 3.34e-10;
				I_off_n[1][80] = 4.54e-10;
				I_off_n[1][90] = 5.96e-10;
				I_off_n[1][100] = 7.44e-10;
				for(i = 0; i <= 100; i += 10){
					I_off_p[1][i] = I_off_n[1][i]; 
				}

				//32 nm LOP
				vdd[2] = 0.6;
				Lphy[2] = 0.016;
				Lelec[2] = 0.01232;//Lelec is the electrical gate-length.	
				t_ox[2] = 0.9e-3;//micron
				v_th[2] = 0.24227;//V
				c_ox[2] = 2.84e-14;//F/micron2
				mobility_eff[2] =  513.52 * (1e-2 * 1e6 * 1e-2 * 1e6); //micron2 / Vs
				Vdsat[2] = 4.64e-2; //V/micron
				c_g_ideal[2] = 4.54e-16;//F/micron
				c_fringe[2] = 0.057e-15;
				c_junc[2] = 1e-15;//F/micron2
				I_on_n[2] = 827.8e-6;//A/micron
				I_on_p[2] = I_on_n[2] / 2;
				nmos_effective_resistance_multiplier = 1.73;
				nmos_to_pmos_effective_current_drive_ratio[2] = 2.28;
				gmp_to_gmn_multiplier[2] = 1.11;
				Rnchannelon[2] = nmos_effective_resistance_multiplier * vdd[2] / I_on_n[2];//ohm-micron
				Rpchannelon[2] = nmos_to_pmos_effective_current_drive_ratio[2] * Rnchannelon[2];//ohm-micron
				I_off_n[2][0] = 5.94e-8;
				I_off_n[2][10] = 7.23e-8;
				I_off_n[2][20] = 8.7e-8;
				I_off_n[2][30] = 1.04e-7;
				I_off_n[2][40] = 1.22e-7;
				I_off_n[2][50] = 1.43e-7;
				I_off_n[2][60] = 1.65e-7;
				I_off_n[2][70] = 1.90e-7;
				I_off_n[2][80] = 2.15e-7;
				I_off_n[2][90] = 2.39e-7;
				I_off_n[2][100] = 2.63e-7;
				for(i = 0; i <= 100; i += 10){
					I_off_p[2][i] = I_off_n[2][i]; 
				}

				if(ram_cell_tech_flavor == 3){
				//32 nm DRAM cell access transistor technology parameters. Obtained using MASTAR. Based off scaling 
				//IBM eDRAM parameters. Using an SOI process.
				vdd_dram_cell = 1.0;
				Lphy[3] = 0.056;//micron
				Lelec[3] = 0.0419;//micron. For now, assume Lelec is 30% lesser than Lphy for DRAM access and wordline transistors.
				v_th_dram_access_transistor = 0.44129;//V
				width_dram_access_transistor = 0.056;//micron
				I_on_dram_cell = 36e-6;//A
				I_off_dram_cell_worst_case_length_temp = 18.9e-12;//A
				Wmemcella_dram = width_dram_access_transistor;
				Wmemcellpmos_dram = 0;
				Wmemcellnmos_dram = 0;
				area_cell_dram = width_dram_access_transistor * Lphy[3] * 10.0;//micron2. //Based on fitted area model for
				//IBM eDRAM cell
				asp_ratio_cell_dram = 1.46; //Fixing this to the SRAM cell aspect ratio
				c_dram_cell = 20e-15;

				//32 nm DRAM wordline parameters obtained using MASTAR. 
				vpp = 1.5;//vpp. V
				t_ox[3] = 2e-3;//micron
				v_th[3] = 0.44467;//V
				c_ox[3] = 1.48e-14;//F/micron2
				mobility_eff[3] =  408.12 * (1e-2 * 1e6 * 1e-2 * 1e6);//micron2 / Vs
				Vdsat[3] = 0.174; //V/micron
				c_g_ideal[3] = 7.45e-16;//F/micron
				c_fringe[3] = 0.053e-15;//F/micron
				c_junc[3] = 1e-15;//F/micron2 
				I_on_n[3] =1055.4e-6;//A/micron
				I_on_p[3] = I_on_n[3] / 2;
				nmos_effective_resistance_multiplier = 1.65;
				nmos_to_pmos_effective_current_drive_ratio[3] = 2.05;
				gmp_to_gmn_multiplier[3] = 0.90;
				Rnchannelon[3] = nmos_effective_resistance_multiplier * vpp / I_on_n[3];//ohm-micron
				Rpchannelon[3] = nmos_to_pmos_effective_current_drive_ratio[3] * Rnchannelon[3];//ohm-micron
				I_off_n[3][0] = 3.57e-11; //A/micron
				I_off_n[3][10] = 5.51e-11;
				I_off_n[3][20] = 8.27e-11;
				I_off_n[3][30] = 1.21e-10;
				I_off_n[3][40] = 1.74e-10;
				I_off_n[3][50] = 2.45e-10;
				I_off_n[3][60] = 3.38e-10;
				I_off_n[3][70] = 4.53e-10;
				I_off_n[3][80] = 5.87e-10;
				I_off_n[3][90] = 7.29e-10;
				I_off_n[3][100] = 8.87e-10;
				for(i = 0; i <= 100; i += 10){
					I_off_p[3][i] = I_off_n[3][i]; 
				}
				}

				else if(ram_cell_tech_flavor == 4){

		//32 nm commodity DRAM cell access transistor technology parameters. 
			//parameters
			vdd_dram_cell = 1.0;
			Lphy[3] = 0.032;//micron
			Lelec[3] = 0.0205;//micron. 
			v_th_dram_access_transistor = 1;//V
			width_dram_access_transistor = 0.032;//micron
			I_on_dram_cell = 20e-6;
			I_off_dram_cell_worst_case_length_temp = 1e-15;//A
			Wmemcella_dram = width_dram_access_transistor;
			Wmemcellpmos_dram = 0;
			Wmemcellnmos_dram = 0;
			area_cell_dram = 6*0.032*0.032;//micron2. 
			asp_ratio_cell_dram = 0.667; 
			c_dram_cell = 30e-15;

			//32 nm commodity DRAM wordline transistor parameters obtained using MASTAR. 
			vpp = 2.6;//vpp. V
			t_ox[3] = 5e-3;//micron
			v_th[3] = 1.0;//V
			c_ox[3] = 6.16e-15;//F/micron2
			mobility_eff[3] =  303.44 * (1e-2 * 1e6 * 1e-2 * 1e6);//micron2 / Vs
			Vdsat[3] = 0.385; //V/micron
			c_g_ideal[3] = 4e-16;//F/micron
			c_fringe[3] = 0.08e-15;//F/micron
			c_junc[3] = 1e-15;//F/micron2
			I_on_n[3] = 1040.9e-6;//A/micron
			I_on_p[3] = I_on_n[3] / 2;
			nmos_effective_resistance_multiplier = 1.69;
			nmos_to_pmos_effective_current_drive_ratio[3] = 1.95;
			gmp_to_gmn_multiplier[3] = 0.90;
			Rnchannelon[3] = nmos_effective_resistance_multiplier * vpp / I_on_n[3];//ohm-micron
			Rpchannelon[3] = nmos_to_pmos_effective_current_drive_ratio[3] * Rnchannelon[3];//ohm-micron
			I_off_n[3][0] = 1.42e-11; //A/micron
			I_off_n[3][10] = 2.25e-11;
			I_off_n[3][20] = 3.46e-11;
			I_off_n[3][30] = 5.18e-11;
			I_off_n[3][40] = 7.58e-11;
			I_off_n[3][50] = 1.08e-10;
			I_off_n[3][60] = 6.89e-13;
			I_off_n[3][70] = 2.02e-10;
			I_off_n[3][80] = 2.57e-10;
			I_off_n[3][90] = 3.14e-10;
			I_off_n[3][100] = 6.89e-13;
			for(i = 0; i <= 100; i += 10){
				I_off_p[3][i] = I_off_n[3][i]; 
			}
		}

				//SRAM cell properties 
				Wmemcella_sram = 1.31 * FEATURESIZE;
				Wmemcellpmos_sram = 1.23 * FEATURESIZE;
				Wmemcellnmos_sram = 2.08 * FEATURESIZE;
				area_cell_sram = 146 * FEATURESIZE * FEATURESIZE;
				asp_ratio_cell_sram = 1.46;
				}

				dram_cell_tech_flavor = 3;
				
				vdd_periph_global_tech_node[iter] = vdd[periph_global_tech_flavor];
				t_ox_periph_global_tech_node[iter] = t_ox[periph_global_tech_flavor];
				v_th_periph_global_tech_node[iter] = v_th[periph_global_tech_flavor];
				c_ox_periph_global_tech_node[iter] = c_ox[periph_global_tech_flavor];
				c_g_ideal_itrs_periph_global_tech_node[iter] = c_g_ideal[periph_global_tech_flavor];
				c_fringe_itrs_periph_global_tech_node[iter] = c_fringe[periph_global_tech_flavor];
				c_junc_itrs_periph_global_tech_node[iter] = c_junc[periph_global_tech_flavor];
				Lphy_periph_global_tech_node[iter] = Lphy[periph_global_tech_flavor];
				Lelec_periph_global_tech_node[iter] = Lelec[periph_global_tech_flavor];
				I_on_n_periph_global_tech_node[iter] = I_on_n[periph_global_tech_flavor];
				Rnchannelon_itrs_periph_global_tech_node[iter] = Rnchannelon[periph_global_tech_flavor];
				Rpchannelon_itrs_periph_global_tech_node[iter] = Rpchannelon[periph_global_tech_flavor];
				nmos_to_pmos_effective_current_drive_ratio_periph_global_tech_node[iter] = nmos_to_pmos_effective_current_drive_ratio[periph_global_tech_flavor];
				for(i = 0; i <= 100; i += 10){
					I_off_n_periph_global_tech_node[iter][i] = I_off_n[periph_global_tech_flavor][i];
					I_off_p_periph_global_tech_node[iter][i] = I_off_p[periph_global_tech_flavor][i]; 
				}
				gmp_to_gmn_multiplier_periph_global_tech_node[iter] = gmp_to_gmn_multiplier[periph_global_tech_flavor];
				
				vdd_sram_cell_tech_node[iter] = vdd[ram_cell_tech_flavor];
				Lphy_sram_cell_transistor_tech_node[iter] = Lphy[ram_cell_tech_flavor];
				Lelec_sram_cell_transistor_tech_node[iter] = Lelec[ram_cell_tech_flavor];
				t_ox_sram_cell_transistor_tech_node[iter] = t_ox[ram_cell_tech_flavor];
				v_th_sram_cell_transistor_tech_node[iter] = v_th[ram_cell_tech_flavor];
				c_g_ideal_itrs_sram_cell_transistor_tech_node[iter] = c_g_ideal[ram_cell_tech_flavor];
				c_fringe_itrs_sram_cell_transistor_tech_node[iter] = c_fringe[ram_cell_tech_flavor];
				c_junc_itrs_sram_cell_transistor_tech_node[iter] = c_junc[ram_cell_tech_flavor];
				I_on_n_sram_cell_transistor_tech_node[iter] = I_on_n[ram_cell_tech_flavor];
				Rnchannelon_itrs_sram_cell_tech_node[iter] = Rnchannelon[ram_cell_tech_flavor];
				Rpchannelon_itrs_sram_cell_tech_node[iter] = Rpchannelon[ram_cell_tech_flavor];
				nmos_to_pmos_effective_current_drive_ratio_sram_cell_tech_node[iter] = nmos_to_pmos_effective_current_drive_ratio[ram_cell_tech_flavor];
				for(i = 0; i <= 100; i += 10){
					I_off_n_sram_cell_transistor_tech_node[iter][i] = I_off_n[ram_cell_tech_flavor][i];
					I_off_p_sram_cell_transistor_tech_node[iter][i] = I_off_n_sram_cell_transistor[i]; 
				}

				vdd_dram_cell_tech_node[iter] = vdd_dram_cell;
				v_th_dram_access_transistor_tech_node[iter] = v_th_dram_access_transistor;
				Lphy_dram_access_transistor_tech_node[iter] = Lphy[dram_cell_tech_flavor];
				Lelec_dram_access_transistor_tech_node[iter] = Lelec[dram_cell_tech_flavor];
				c_g_ideal_itrs_dram_access_transistor_tech_node[iter] = c_g_ideal[dram_cell_tech_flavor];
				c_fringe_itrs_dram_access_transistor_tech_node[iter]  = c_fringe[dram_cell_tech_flavor];
				c_junc_itrs_dram_access_transistor_tech_node[iter] = c_junc[dram_cell_tech_flavor];
				I_on_dram_cell_tech_node[iter] = I_on_dram_cell;
				I_on_n_dram_access_transistor_tech_node[iter] = I_on_n[dram_cell_tech_flavor];
				c_dram_cell_tech_node[iter] = c_dram_cell;

				vpp_tech_node[iter] = vpp;
				Lphy_dram_wordline_transistor_tech_node[iter] = Lphy[dram_cell_tech_flavor];
				Lelec_dram_wordline_transistor_tech_node[iter] = Lelec[dram_cell_tech_flavor];
				c_g_ideal_itrs_dram_wordline_transistor_tech_node[iter] = c_g_ideal[dram_cell_tech_flavor];
				c_fringe_itrs_dram_wordline_transistor_tech_node[iter]  = c_fringe[dram_cell_tech_flavor];
				c_junc_itrs_dram_wordline_transistor_tech_node[iter] = c_junc[dram_cell_tech_flavor];
				I_on_n_dram_wordline_transistor_tech_node[iter] = I_on_n[dram_cell_tech_flavor];
				Rnchannelon_itrs_dram_wordline_transistor_tech_node[iter] = Rnchannelon[dram_cell_tech_flavor];
				Rpchannelon_itrs_dram_wordline_transistor_tech_node[iter] = Rpchannelon[dram_cell_tech_flavor];
				nmos_to_pmos_effective_current_drive_ratio_dram_wordline_transistor_tech_node[iter] = nmos_to_pmos_effective_current_drive_ratio[dram_cell_tech_flavor];
				for(i = 0; i <= 100; i += 10){
					I_off_n_dram_wordline_transistor_tech_node[iter][i] = I_off_n[dram_cell_tech_flavor][i]; 
					I_off_p_dram_wordline_transistor_tech_node[iter][i] = I_off_p[dram_cell_tech_flavor][i];
				}

				Wmemcella_dram_tech_node[iter] = Wmemcella_dram;
				Wmemcellpmos_dram_tech_node[iter] = Wmemcellpmos_dram;
				Wmemcellnmos_dram_tech_node[iter] = Wmemcellnmos_dram;
				area_cell_dram_tech_node[iter] = area_cell_dram;
				asp_ratio_cell_dram_tech_node[iter] = asp_ratio_cell_dram;
				Wmemcella_sram_tech_node[iter] = Wmemcella_sram;
				Wmemcellpmos_sram_tech_node[iter] = Wmemcellpmos_sram;
				Wmemcellnmos_sram_tech_node[iter] = Wmemcellnmos_sram;
				area_cell_sram_tech_node[iter] = area_cell_sram;
				asp_ratio_cell_sram_tech_node[iter] = asp_ratio_cell_sram;

				//Sense amplifier latch Gm calculation
				mobility_eff_periph_global_tech_node[iter] = mobility_eff[periph_global_tech_flavor]; 
				Vdsat_periph_global_tech_node[iter] = Vdsat[periph_global_tech_flavor]; 
				}

				//Currently we are not modeling the resistance/capacitance of poly anywhere. 

				Cpolywire = 0;
				Wcompinvp1 = 12.5 * FEATURESIZE;//this was 10 micron for the 0.8 micron process
				Wcompinvn1 = 7.5 * FEATURESIZE;//this was 6 micron for the 0.8 micron process
				Wcompinvp2 = 25 * FEATURESIZE;//this was 20 micron for the 0.8 micron process
				Wcompinvn2 = 15 * FEATURESIZE;//this was 12 micron for the 0.8 micron process
				Wcompinvp3 = 50 * FEATURESIZE;//this was 40 micron for the 0.8 micron process
				Wcompinvn3 = 30 * FEATURESIZE;//this was 24 micron for the 0.8 micron process
				Wevalinvp =  100 * FEATURESIZE;//this was 80 micron for the 0.8 micron process
				Wevalinvn = 50 * FEATURESIZE;//this was 40 micron for the 0.8 micron process
				Wcompn =  12.5 * FEATURESIZE;//this was 10 micron for the 0.8 micron process
				Wcompp =  37.5 * FEATURESIZE;//this was 30 micron for the 0.8 micron process
				//WmuxdrvNANDn and WmuxdrvNANDp are no longer being used but it's part of the old
				//delay_comparator function which we are using exactly as it used to be, so just setting these
				//to 0
				WmuxdrvNANDn = 0;
				WmuxdrvNANDp = 0;

				MIN_GAP_BET_P_AND_N_DIFFS = 5 * FEATURESIZE;
				MIN_GAP_BET_SAME_TYPE_DIFFS = 1.5 * FEATURESIZE;
				HPOWERRAIL = 2 * FEATURESIZE;
				DEFAULTHEIGHTCELL = 50 * FEATURESIZE; 
				WIDTHPOLYCONTACT = FEATURESIZE;
				SPACINGPOLYTOCONTACT = FEATURESIZE;
				SPACINGPOLYTOPOLY = 1.5 * FEATURESIZE;
				RAM_WORDLINE_STITCHING_OVERHEAD = 7.5 * FEATURESIZE;

				
				gnand2 = 4.0 / 3.0;
				gnand3 = 6.0 / 3.0;
				gnor2 = 5.0 / 3.0;
				gpmos = 2.0 / 3.0;
				gnmos = 1.0 / 3.0;
				minimum_width_nmos = 3 * FEATURESIZE / 2;
				MAX_NMOS_WIDTH = 100 * FEATURESIZE;
				Wiso = 12.5*FEATURESIZE;//was 10 micron for the 0.8 micron process
				WsenseN = 3.75*FEATURESIZE; // sense amplifier N-trans; was 3 micron for the 0.8 micron process
				WsenseP = 7.5*FEATURESIZE; // sense amplifier P-trans; was 6 micron for the 0.8 micron process
				WsenseEn = 5*FEATURESIZE; // Sense enable transistor of the sense amplifier; was 4 micron for the 0.8 micron process
				width_nmos_bit_mux = 6 * minimum_width_nmos;
				width_nmos_sense_amp_mux = 6 * minimum_width_nmos;
								
				int_tech_low = (int) (floor(tech_low + 0.5));
				int_tech_high = (int) (floor(tech_high+ 0.5));
				if(int_tech_low != int_tech_high){
					alpha = (technology - tech_low) / (tech_high - tech_low);
				}
				else{
					alpha =0;
				}

				vdd_periph_global = vdd_periph_global_tech_node[0] + alpha * (vdd_periph_global_tech_node[1] - 
					vdd_periph_global_tech_node[0]);
				Lphy_periph_global = Lphy_periph_global_tech_node[0] + 
					alpha * (Lphy_periph_global_tech_node[1] - Lphy_periph_global_tech_node[0]);
				Lelec_periph_global = Lelec_periph_global_tech_node[0] + 
					alpha * (Lelec_periph_global_tech_node[1] - Lelec_periph_global_tech_node[0]);
				t_ox_periph_global = t_ox_periph_global_tech_node[0] + 
					alpha * (t_ox_periph_global_tech_node[1] - t_ox_periph_global_tech_node[0]);
				v_th_periph_global = v_th_periph_global_tech_node[0] + 
					alpha * (v_th_periph_global_tech_node[1] - v_th_periph_global_tech_node[0]);
				c_ox_periph_global = c_ox_periph_global_tech_node[0] + 
					alpha * (c_ox_periph_global_tech_node[1] - c_ox_periph_global_tech_node[0]);
				c_g_ideal_itrs_periph_global = c_g_ideal_itrs_periph_global_tech_node[0] + 
					alpha * (c_g_ideal_itrs_periph_global_tech_node[1] - c_g_ideal_itrs_periph_global_tech_node[0]);
				c_fringe_itrs_periph_global = c_fringe_itrs_periph_global_tech_node[0] + 
					alpha * (c_fringe_itrs_periph_global_tech_node[1] - c_fringe_itrs_periph_global_tech_node[0]);
				c_junc_itrs_periph_global = c_junc_itrs_periph_global_tech_node[0] + 
					alpha * (c_junc_itrs_periph_global_tech_node[1] - c_junc_itrs_periph_global_tech_node[0]);
				c_overlap_itrs_periph_global = (((Lphy_periph_global - Lelec_periph_global) / Lphy_periph_global) / 2) * c_g_ideal_itrs_periph_global;
				c_overlap_itrs_periph_global = 0.2 * c_g_ideal_itrs_periph_global;
				
				I_on_n_periph_global = I_on_n_periph_global_tech_node[0] + 
					alpha * (I_on_n_periph_global_tech_node[1] - I_on_n_periph_global_tech_node[0]);
				Rnchannelon_itrs_periph_global = Rnchannelon_itrs_periph_global_tech_node[0] + 
					alpha * (Rnchannelon_itrs_periph_global_tech_node[1] - Rnchannelon_itrs_periph_global_tech_node[0]);
				Rpchannelon_itrs_periph_global = Rpchannelon_itrs_periph_global_tech_node[0] + 
					alpha * (Rpchannelon_itrs_periph_global_tech_node[1] - Rpchannelon_itrs_periph_global_tech_node[0]);
				nmos_to_pmos_effective_current_drive_ratio_periph_global = nmos_to_pmos_effective_current_drive_ratio_periph_global_tech_node[0] +
					alpha * (nmos_to_pmos_effective_current_drive_ratio_periph_global_tech_node[1] - nmos_to_pmos_effective_current_drive_ratio_periph_global_tech_node[0]);
				
				for(i = 0; i <= 100; i += 10){
					I_off_n_periph_global[i] = I_off_n_periph_global_tech_node[0][i] + 
						alpha * (I_off_n_periph_global_tech_node[1][i] - I_off_n_periph_global_tech_node[0][i] );//A/micron
					I_off_p_periph_global[i] = I_off_n_periph_global[i]; 
				}
				gmp_to_gmn_multiplier_periph_global = gmp_to_gmn_multiplier_periph_global_tech_node[0] + 
					alpha * (gmp_to_gmn_multiplier_periph_global_tech_node[1] - gmp_to_gmn_multiplier_periph_global_tech_node[0]);//A/micron
				
				vdd_sram_cell = vdd_sram_cell_tech_node[0] + alpha * (vdd_sram_cell_tech_node[1] - vdd_sram_cell_tech_node[0]);
				Lphy_sram_cell_transistor = Lphy_sram_cell_transistor_tech_node[0] + 
					alpha * (Lphy_sram_cell_transistor_tech_node[1] - Lphy_sram_cell_transistor_tech_node[0]);
				Lelec_sram_cell_transistor = Lelec_sram_cell_transistor_tech_node[0] + 
					alpha * (Lelec_sram_cell_transistor_tech_node[1] - Lelec_sram_cell_transistor_tech_node[0]);
				t_ox_sram_cell_transistor = t_ox_sram_cell_transistor_tech_node[0] + 
					alpha * (t_ox_sram_cell_transistor_tech_node[1] - t_ox_sram_cell_transistor_tech_node[0]);
				v_th_sram_cell_transistor = v_th_sram_cell_transistor_tech_node[0] + 
					alpha * (v_th_sram_cell_transistor_tech_node[1] - v_th_sram_cell_transistor_tech_node[0]);
				c_g_ideal_itrs_sram_cell_transistor = c_g_ideal_itrs_sram_cell_transistor_tech_node[0] + 
					alpha * (c_g_ideal_itrs_sram_cell_transistor_tech_node[1] - c_g_ideal_itrs_sram_cell_transistor_tech_node[0]);
				c_fringe_itrs_sram_cell_transistor = c_fringe_itrs_sram_cell_transistor_tech_node[0] + 
					alpha * (c_fringe_itrs_sram_cell_transistor_tech_node[1] - c_fringe_itrs_sram_cell_transistor_tech_node[0]);
				c_junc_itrs_sram_cell_transistor = c_junc_itrs_sram_cell_transistor_tech_node[0] + 
					alpha * (c_junc_itrs_sram_cell_transistor_tech_node[1] - c_junc_itrs_sram_cell_transistor_tech_node[0]);
				c_overlap_itrs_sram_cell_transistor = (((Lphy_sram_cell_transistor - Lelec_sram_cell_transistor) / Lphy_sram_cell_transistor) / 2) * c_g_ideal_itrs_sram_cell_transistor;
				c_overlap_itrs_sram_cell_transistor = 0.2 * c_g_ideal_itrs_sram_cell_transistor;
				I_on_n_sram_cell_transistor = I_on_n_sram_cell_transistor_tech_node[0] + 
					alpha * (I_on_n_sram_cell_transistor_tech_node[1] - I_on_n_sram_cell_transistor_tech_node[0]);
				Rnchannelon_itrs_sram_cell_transistor = Rnchannelon_itrs_sram_cell_tech_node[0] + 
					alpha * (Rnchannelon_itrs_sram_cell_tech_node[1] - Rnchannelon_itrs_sram_cell_tech_node[0]);
				Rpchannelon_itrs_sram_cell_transistor = Rpchannelon_itrs_sram_cell_tech_node[0] + 
					alpha * (Rpchannelon_itrs_sram_cell_tech_node[1] - Rpchannelon_itrs_sram_cell_tech_node[0]);
				nmos_to_pmos_effective_current_drive_ratio_sram_cell_transistor = nmos_to_pmos_effective_current_drive_ratio_sram_cell_tech_node[0] +
					alpha * (nmos_to_pmos_effective_current_drive_ratio_sram_cell_tech_node[1] - nmos_to_pmos_effective_current_drive_ratio_sram_cell_tech_node[0]);
				for(i = 0; i <= 100; i += 10){
					I_off_n_sram_cell_transistor[i] = I_off_n_sram_cell_transistor_tech_node[0][i] + 
						alpha * (I_off_n_sram_cell_transistor_tech_node[1][i] - I_off_n_sram_cell_transistor_tech_node[0][i] );
					I_off_p_sram_cell_transistor[i] = I_off_n_sram_cell_transistor[i]; 
				}
				Wmemcella_sram = Wmemcella_sram_tech_node[0] + alpha * (Wmemcella_sram_tech_node[1] - Wmemcella_sram_tech_node[0]);
				Wmemcellpmos_sram = Wmemcellpmos_sram_tech_node[0] + alpha * (Wmemcellpmos_sram_tech_node[1] - Wmemcellpmos_sram_tech_node[0]);
				Wmemcellnmos_sram = Wmemcellnmos_sram_tech_node[0] + alpha * (Wmemcellnmos_sram_tech_node[1] - Wmemcellnmos_sram_tech_node[0]);
				area_cell_sram = area_cell_sram_tech_node[0] + alpha * (area_cell_sram_tech_node[1] - area_cell_sram_tech_node[0]);
				asp_ratio_cell_sram = asp_ratio_cell_sram_tech_node[0] + alpha * (asp_ratio_cell_sram_tech_node[1] - 
					asp_ratio_cell_sram_tech_node[0]);

			   
				vdd_dram_cell = vdd_dram_cell_tech_node[0] + 
					alpha * (vdd_dram_cell_tech_node[1] - vdd_dram_cell_tech_node[0]);
				v_th_dram_access_transistor = v_th_dram_access_transistor_tech_node[0] + 
					alpha * (v_th_dram_access_transistor_tech_node[1] - v_th_dram_access_transistor_tech_node[0]);
				Lphy_dram_access_transistor = Lphy_dram_access_transistor_tech_node[0] + 
					alpha * (Lphy_dram_access_transistor_tech_node[1] - Lphy_dram_access_transistor_tech_node[0]);
				Lelec_dram_access_transistor = Lelec_dram_access_transistor_tech_node[0] + 
					alpha * (Lelec_dram_access_transistor_tech_node[1] - Lelec_dram_access_transistor_tech_node[0]);
				c_g_ideal_itrs_dram_access_transistor = c_g_ideal_itrs_dram_access_transistor_tech_node[0] + 
					alpha * (c_g_ideal_itrs_dram_access_transistor_tech_node[1] - c_g_ideal_itrs_dram_access_transistor_tech_node[0]);
				c_fringe_itrs_dram_access_transistor = c_fringe_itrs_dram_access_transistor_tech_node[0] + 
					alpha * (c_fringe_itrs_dram_access_transistor_tech_node[1] - c_fringe_itrs_dram_access_transistor_tech_node[0]);
				c_junc_itrs_dram_access_transistor = c_junc_itrs_dram_access_transistor_tech_node[0] + 
					alpha * (c_junc_itrs_dram_access_transistor_tech_node[1] - c_junc_itrs_dram_access_transistor_tech_node[0]);
				c_overlap_itrs_dram_access_transistor = (((Lphy_dram_access_transistor - Lelec_dram_access_transistor) / Lphy_dram_access_transistor) / 2) * c_g_ideal_itrs_dram_access_transistor;
				c_overlap_itrs_dram_access_transistor = 0.2 * c_g_ideal_itrs_dram_access_transistor;
				I_on_dram_cell = I_on_dram_cell_tech_node[0] + 	alpha * (I_on_dram_cell_tech_node[1] - I_on_dram_cell_tech_node[0]);
				I_on_n_dram_access_transistor = I_on_n_dram_access_transistor_tech_node[0] + 
					alpha * (I_on_n_dram_access_transistor_tech_node[1] - I_on_n_dram_access_transistor_tech_node[0]);
				Rnchannelon_itrs_dram_access_transistor = vdd_dram_cell / I_on_n_dram_access_transistor;
				Rpchannelon_itrs_dram_access_transistor = vdd_dram_cell / I_on_p_dram_access_transistor;
				Wmemcella_dram = Wmemcella_dram_tech_node[0] + alpha * (Wmemcella_dram_tech_node[1] - Wmemcella_dram_tech_node[0]);
				Wmemcellpmos_dram = Wmemcellpmos_dram_tech_node[0] + alpha * (Wmemcellpmos_dram_tech_node[1] - Wmemcellpmos_dram_tech_node[0]);
				Wmemcellnmos_dram = Wmemcellnmos_dram_tech_node[0] + alpha * (Wmemcellnmos_dram_tech_node[1] - Wmemcellnmos_dram_tech_node[0]);
				area_cell_dram = area_cell_dram_tech_node[0] + alpha * (area_cell_dram_tech_node[1] - area_cell_dram_tech_node[0]);
				asp_ratio_cell_dram = asp_ratio_cell_dram_tech_node[0] + alpha * (asp_ratio_cell_dram_tech_node[1] - 
					asp_ratio_cell_dram_tech_node[0]);
				c_dram_cell = c_dram_cell_tech_node[0] +  alpha * (c_dram_cell_tech_node[1] - c_dram_cell_tech_node[0]);
  
 
				vpp = vpp_tech_node[0] +  alpha * (vpp_tech_node[1] - vpp_tech_node[0]);
				Lphy_dram_wordline_transistor = Lphy_dram_wordline_transistor_tech_node[0] + 
					alpha * (Lphy_dram_wordline_transistor_tech_node[1] - Lphy_dram_wordline_transistor_tech_node[0]);
				Lelec_dram_wordline_transistor = Lelec_dram_wordline_transistor_tech_node[0] + 
					alpha * (Lelec_dram_wordline_transistor_tech_node[1] - Lelec_dram_wordline_transistor_tech_node[0]);
				c_g_ideal_itrs_dram_wordline_transistor = c_g_ideal_itrs_dram_wordline_transistor_tech_node[0] + 
					 alpha * (c_g_ideal_itrs_dram_wordline_transistor_tech_node[1] - c_g_ideal_itrs_dram_wordline_transistor_tech_node[0]);
				c_fringe_itrs_dram_wordline_transistor = c_fringe_itrs_dram_wordline_transistor_tech_node[0] + 
					alpha * (c_fringe_itrs_dram_wordline_transistor_tech_node[1] - c_fringe_itrs_dram_wordline_transistor_tech_node[0]);
				c_junc_itrs_dram_wordline_transistor = c_junc_itrs_dram_wordline_transistor_tech_node[0] + 
					alpha * (c_junc_itrs_dram_wordline_transistor_tech_node[1] - c_junc_itrs_dram_wordline_transistor_tech_node[0]);
				c_overlap_itrs_dram_wordline_transistor = (((Lphy_dram_wordline_transistor - Lelec_dram_wordline_transistor) / Lphy_dram_wordline_transistor) / 2) * c_g_ideal_itrs_dram_wordline_transistor;
				c_overlap_itrs_dram_wordline_transistor = 0.2 * c_g_ideal_itrs_dram_wordline_transistor;
				I_on_n_dram_wordline_transistor = I_on_n_dram_wordline_transistor_tech_node[0] + 
					alpha * (I_on_n_dram_wordline_transistor_tech_node[1] - I_on_n_dram_wordline_transistor_tech_node[0]);
				Rnchannelon_itrs_dram_wordline_transistor = Rnchannelon_itrs_dram_wordline_transistor_tech_node[0] + 
					alpha * (Rnchannelon_itrs_dram_wordline_transistor_tech_node[1] - Rnchannelon_itrs_dram_wordline_transistor_tech_node[0]);
				Rpchannelon_itrs_dram_wordline_transistor = Rpchannelon_itrs_dram_wordline_transistor_tech_node[0] + 
					alpha * (Rpchannelon_itrs_dram_wordline_transistor_tech_node[1] - Rpchannelon_itrs_dram_wordline_transistor_tech_node[0]);
				nmos_to_pmos_effective_current_drive_ratio_dram_wordline_transistor = nmos_to_pmos_effective_current_drive_ratio_dram_wordline_transistor_tech_node[0] +
					alpha * (nmos_to_pmos_effective_current_drive_ratio_dram_wordline_transistor_tech_node[1] - nmos_to_pmos_effective_current_drive_ratio_dram_wordline_transistor_tech_node[0]);
			    for(i = 0; i <= 100; i += 10){
					I_off_n_dram_wordline_transistor[i] = I_off_n_dram_wordline_transistor_tech_node[0][i] + 
						alpha * (I_off_n_dram_wordline_transistor_tech_node[1][i] - I_off_n_dram_wordline_transistor_tech_node[0][i] );
					I_off_p_dram_wordline_transistor[i] = I_off_n_dram_wordline_transistor[i]; 
				}

				mobility_eff_periph_global = mobility_eff_periph_global_tech_node[0] + 
					alpha * (mobility_eff_periph_global_tech_node[1] - mobility_eff_periph_global_tech_node[0]);
				Vdsat_periph_global = Vdsat_periph_global_tech_node[0] + 
					alpha * (Vdsat_periph_global_tech_node[1] - Vdsat_periph_global_tech_node[0]);
				gmn_sense_amp_latch = (mobility_eff_periph_global / 2) * c_ox_periph_global * (WsenseN / Lelec_periph_global) * Vdsat_periph_global; 
				gmp_sense_amp_latch = gmp_to_gmn_multiplier_periph_global * gmn_sense_amp_latch;
				Gm_sense_amp_latch = gmn_sense_amp_latch + gmp_sense_amp_latch;

				BitWidth_dram = sqrt(area_cell_dram / (asp_ratio_cell_dram));
				BitHeight_dram = asp_ratio_cell_dram * BitWidth_dram;
				BitWidth_sram = sqrt(area_cell_sram / (asp_ratio_cell_sram));
				BitHeight_sram = asp_ratio_cell_sram * BitWidth_sram;

				
				Vt_dram = v_th_dram_access_transistor;
				Vbitpre_dram = vdd_dram_cell; 
				Vt_sram = v_th[ram_cell_tech_flavor];
				Vbitpre_sram = vdd[ram_cell_tech_flavor];
				pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
				width_pmos_bitline_precharge = 6 * pmos_to_nmos_sizing_r * minimum_width_nmos;
				width_pmos_bitline_equalization = pmos_to_nmos_sizing_r * minimum_width_nmos;
  
		  
				//Interconnect parameters
				if(technology < 91 && technology > 89){
					tech_low = 90;
					tech_high = 90;
				}
				else if(technology < 66 && technology > 64){
					tech_low = 65;
					tech_high = 65;
				}
				else if(technology < 46 && technology > 44){
					tech_low = 45;
					tech_high = 45;
				}
				else if(technology < 33 && technology > 31){
					tech_low = 32;
					tech_high = 32;
				}
				else if(technology < 23 && technology > 21){
					tech_low = 25;
					tech_high = 25;
				}
				else if(technology < 90 && technology > 65){
					tech_low = 90;
					tech_high = 65;
				}
				else if(technology < 65 && technology > 45){
					tech_low = 65;
					tech_high = 45;
				}
				else if(technology < 45 && technology > 32){
					tech_low = 45;
					tech_high = 32;
				}
				else if(technology < 32 && technology > 22){
					tech_low = 32;
					tech_high = 22;
				}
				
				for(iter=0; iter<=1; ++iter){
					if(iter==0){
						tech = tech_low;
					}
					else{
						tech = tech_high;
					}

					if(tech < 111 && tech > 109){
					  //Aggressive projections
						wire_pitch[0][0] = 2.5 * FEATURESIZE;//micron
						aspect_ratio = 2.4;
						wire_width = wire_pitch[0][0] / 2; //micron
						wire_thickness = aspect_ratio * wire_width;//micron
						wire_spacing = wire_pitch[0][0] - wire_width;//micron
						barrier_thickness = 0.01;//micron
						dishing_thickness = 0;//micron
						alpha_scatter = 1;
						wire_r_per_micron[0][0] = wire_resistance(CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);//ohm/micron
						ild_thickness = 0.48;//micron
						miller_value = 1.5;
						horiz_dielectric_constant = 2.709;
						vert_dielectric_constant = 3.9;
						fringe_cap = 0.115e-15; //F/micron
						wire_c_per_micron[0][0] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);//F/micron.

						wire_pitch[0][1] = 4 * FEATURESIZE;
						  wire_width = wire_pitch[0][1] / 2;
						  wire_thickness = aspect_ratio * wire_width;
						  wire_spacing = wire_pitch[0][1] - wire_width;
						  wire_r_per_micron[0][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
    					  wire_c_per_micron[0][1] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							  fringe_cap);

						  wire_pitch[0][2] = 8 * FEATURESIZE;
						  aspect_ratio = 2.7;
						  wire_width = wire_pitch[0][2] / 2;
						  wire_thickness = aspect_ratio * wire_width;
						  wire_spacing = wire_pitch[0][2] - wire_width;
						  wire_r_per_micron[0][2] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						  ild_thickness = 0.96;
	    				  wire_c_per_micron[0][2] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							  fringe_cap);

						//Conservative projections
						  wire_pitch[1][0] = 2.5 * FEATURESIZE;
						  aspect_ratio = 2.0;
						  wire_width = wire_pitch[1][0] / 2;
						  wire_thickness = aspect_ratio * wire_width;
						  wire_spacing = wire_pitch[1][0] - wire_width;
						  barrier_thickness = 0.008;
						  dishing_thickness = 0;
						  alpha_scatter = 1;
						  wire_r_per_micron[1][0] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						  ild_thickness = 0.48;
						  miller_value = 1.5;
						  horiz_dielectric_constant = 3.038;
						  vert_dielectric_constant = 3.9;
						  fringe_cap = 0.115e-15; 
						  wire_c_per_micron[1][0] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							  fringe_cap);
					 
					  wire_pitch[1][1] = 4 * FEATURESIZE;
					  wire_width = wire_pitch[1][1] / 2;
					  aspect_ratio = 2.0;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][1] - wire_width;
					  if(ram_cell_tech_flavor == 4){
						  wire_r_per_micron[1][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);//ohm/micron
					  }
					  else{
						  wire_r_per_micron[1][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);//ohm/micron
					  }
    				  wire_c_per_micron[1][1] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);//F/micron.

					  wire_pitch[1][2] = 8 * FEATURESIZE;
					  aspect_ratio = 2.2;
					  wire_width = wire_pitch[1][2] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][2] - wire_width;
					  dishing_thickness = 0.1 *  wire_thickness; 
				      wire_r_per_micron[1][2] = wire_resistance(CU_RESISTIVITY, wire_width,
						  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  ild_thickness = 1.1;
	    			  wire_c_per_micron[1][2] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);

					  //Nominal projections for commodity DRAM wordline/bitline
					  wire_pitch[1][3] = 2 * 0.11;
					  wire_c_per_micron[1][3] = 70e-15 / (256 * 2 * 0.11);
					  wire_r_per_micron[1][3] = 12 / 0.11;
					}

					else if(tech < 91 && tech > 89){
					  //Aggressive projections
						wire_pitch[0][0] = 2.5 * FEATURESIZE;//micron
						aspect_ratio = 2.4;
						wire_width = wire_pitch[0][0] / 2; //micron
						wire_thickness = aspect_ratio * wire_width;//micron
						wire_spacing = wire_pitch[0][0] - wire_width;//micron
						barrier_thickness = 0.01;//micron
						dishing_thickness = 0;//micron
						alpha_scatter = 1;
						wire_r_per_micron[0][0] = wire_resistance(CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);//ohm/micron
						ild_thickness = 0.48;//micron
						miller_value = 1.5;
						horiz_dielectric_constant = 2.709;
						vert_dielectric_constant = 3.9;
						fringe_cap = 0.115e-15; //F/micron
						wire_c_per_micron[0][0] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);//F/micron.

						wire_pitch[0][1] = 4 * FEATURESIZE;
						  wire_width = wire_pitch[0][1] / 2;
						  wire_thickness = aspect_ratio * wire_width;
						  wire_spacing = wire_pitch[0][1] - wire_width;
						  wire_r_per_micron[0][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
    					  wire_c_per_micron[0][1] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							  fringe_cap);

						  wire_pitch[0][2] = 8 * FEATURESIZE;
						  aspect_ratio = 2.7;
						  wire_width = wire_pitch[0][2] / 2;
						  wire_thickness = aspect_ratio * wire_width;
						  wire_spacing = wire_pitch[0][2] - wire_width;
						  wire_r_per_micron[0][2] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						  ild_thickness = 0.96;
	    				  wire_c_per_micron[0][2] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							  fringe_cap);

						//Conservative projections
						  wire_pitch[1][0] = 2.5 * FEATURESIZE;
						  aspect_ratio = 2.0;
						  wire_width = wire_pitch[1][0] / 2;
						  wire_thickness = aspect_ratio * wire_width;
						  wire_spacing = wire_pitch[1][0] - wire_width;
						  barrier_thickness = 0.008;
						  dishing_thickness = 0;
						  alpha_scatter = 1;
						  wire_r_per_micron[1][0] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						  ild_thickness = 0.48;
						  miller_value = 1.5;
						  horiz_dielectric_constant = 3.038;
						  vert_dielectric_constant = 3.9;
						  fringe_cap = 0.115e-15; 
						  wire_c_per_micron[1][0] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							  fringe_cap);
					 
					  wire_pitch[1][1] = 4 * FEATURESIZE;
					  wire_width = wire_pitch[1][1] / 2;
					  aspect_ratio = 2.0;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][1] - wire_width;
					  if(ram_cell_tech_flavor == 4){
						  wire_r_per_micron[1][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);//ohm/micron
					  }
					  else{
						  wire_r_per_micron[1][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);//ohm/micron
					  }
    				  wire_c_per_micron[1][1] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);//F/micron.

					  wire_pitch[1][2] = 8 * FEATURESIZE;
					  aspect_ratio = 2.2;
					  wire_width = wire_pitch[1][2] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][2] - wire_width;
					  dishing_thickness = 0.1 *  wire_thickness; 
				      wire_r_per_micron[1][2] = wire_resistance(CU_RESISTIVITY, wire_width,
						  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  ild_thickness = 1.1;
	    			  wire_c_per_micron[1][2] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);

					  //Nominal projections for commodity DRAM wordline/bitline
					  wire_pitch[1][3] = 2 * 0.09;
					  wire_c_per_micron[1][3] = 60e-15 / (256 * 2 * 0.09);
					  wire_r_per_micron[1][3] = 12 / 0.09;
					}
					else if(tech < 66 && tech > 64){
					 //Aggressive projections
						wire_pitch[0][0] = 2.5 * FEATURESIZE;
						aspect_ratio = 2.7;
						wire_width = wire_pitch[0][0] / 2;
						wire_thickness = aspect_ratio * wire_width;
						wire_spacing = wire_pitch[0][0] - wire_width;
						barrier_thickness = 0;
						dishing_thickness = 0;
						alpha_scatter = 1;
						wire_r_per_micron[0][0] = wire_resistance(BULK_CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						ild_thickness = 0.405;
						miller_value = 1.5;
						horiz_dielectric_constant = 2.303;
						vert_dielectric_constant = 3.9;
						fringe_cap = 0.115e-15; 
						wire_c_per_micron[0][0] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);
						
						wire_pitch[0][1] = 4 * FEATURESIZE;
						wire_width = wire_pitch[0][1] / 2;
						wire_thickness = aspect_ratio * wire_width;
						wire_spacing = wire_pitch[0][1] - wire_width;
						wire_r_per_micron[0][1] = wire_resistance(BULK_CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
    					wire_c_per_micron[0][1] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);

						wire_pitch[0][2] = 8 * FEATURESIZE;
						aspect_ratio = 2.8;
						wire_width = wire_pitch[0][2] / 2;
						wire_thickness = aspect_ratio * wire_width;
						wire_spacing = wire_pitch[0][2] - wire_width;
						wire_r_per_micron[0][2] = wire_resistance(BULK_CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						ild_thickness = 0.81;
						wire_c_per_micron[0][2] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);

					 //Conservative projections
						wire_pitch[1][0] = 2.5 * FEATURESIZE;
						aspect_ratio = 2.0;
						wire_width = wire_pitch[1][0] / 2;
						wire_thickness = aspect_ratio * wire_width;
						wire_spacing = wire_pitch[1][0] - wire_width;
						barrier_thickness = 0.006;
						dishing_thickness = 0;
						alpha_scatter = 1;
						wire_r_per_micron[1][0] = wire_resistance(CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						ild_thickness = 0.405;
						miller_value = 1.5;
						horiz_dielectric_constant = 2.734;
						vert_dielectric_constant = 3.9;
						fringe_cap = 0.115e-15; 
						wire_c_per_micron[1][0] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);

					  wire_pitch[1][1] = 4 * FEATURESIZE;
					  wire_width = wire_pitch[1][1] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][1] - wire_width;
					  if(ram_cell_tech_flavor == 4){
						  wire_r_per_micron[1][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  }
					  else{
						   wire_r_per_micron[1][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							   wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  }
					  wire_c_per_micron[1][1] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							  fringe_cap);//F/micron.

					  wire_pitch[1][2] = 8 * FEATURESIZE;
					  aspect_ratio = 2.2;
					  wire_width = wire_pitch[1][2] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][2] - wire_width;
					  dishing_thickness = 0.1 *  wire_thickness; 
					  if(ram_cell_tech_flavor == 4){
						  wire_r_per_micron[1][2] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  }
					  else{
						  wire_r_per_micron[1][2] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  }
					  ild_thickness = 0.77;
	    			  wire_c_per_micron[1][2] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);
					  //Nominal projections for commodity DRAM wordline/bitline
					  wire_pitch[1][3] = 2 * 0.065;
					  wire_c_per_micron[1][3] = 52.5e-15 / (256 * 2 * 0.065);
					  wire_r_per_micron[1][3] = 12 / 0.065;
					
					}
					else if(tech < 46 && tech > 44){
					  //Aggressive projections.
						wire_pitch[0][0] = 2.5 * FEATURESIZE;
						aspect_ratio = 3.0;
						wire_width = wire_pitch[0][0] / 2;
						wire_thickness = aspect_ratio * wire_width;
						wire_spacing = wire_pitch[0][0] - wire_width;
						barrier_thickness = 0;
						dishing_thickness = 0;
						alpha_scatter = 1;
						wire_r_per_micron[0][0] = wire_resistance(BULK_CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						ild_thickness = 0.315;
						miller_value = 1.5;
						horiz_dielectric_constant = 1.958;
						vert_dielectric_constant = 3.9;
						fringe_cap = 0.115e-15; 
						wire_c_per_micron[0][0] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);

					  wire_pitch[0][1] = 4 * FEATURESIZE;
					  wire_width = wire_pitch[0][1] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[0][1] - wire_width;
					  wire_r_per_micron[0][1] = wire_resistance(BULK_CU_RESISTIVITY, wire_width,
						  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  wire_c_per_micron[0][1] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);

					  wire_pitch[0][2] = 8 * FEATURESIZE;
					  aspect_ratio = 3.0;
					  wire_width = wire_pitch[0][2] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[0][2] - wire_width;
				      wire_r_per_micron[0][2] = wire_resistance(BULK_CU_RESISTIVITY, wire_width,
						  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  ild_thickness = 0.63;
	    			  wire_c_per_micron[0][2] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);

					   //Conservative projections
					  wire_pitch[1][0] = 2.5 * FEATURESIZE;
					  aspect_ratio = 2.0;
					  wire_width = wire_pitch[1][0] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][0] - wire_width;
					  barrier_thickness = 0.004;
					  dishing_thickness = 0;
					  alpha_scatter = 1;
					  wire_r_per_micron[1][0] = wire_resistance(CU_RESISTIVITY, wire_width,
						  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  ild_thickness = 0.315;
					  miller_value = 1.5;
					  horiz_dielectric_constant = 2.46;
					  vert_dielectric_constant = 3.9;
					  fringe_cap = 0.115e-15; 
					  wire_c_per_micron[1][0] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);


					  wire_pitch[1][1] = 4 * FEATURESIZE;
					  wire_width = wire_pitch[1][1] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][1] - wire_width;
					   if(ram_cell_tech_flavor == 4){
						  wire_r_per_micron[1][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  }
					  else{
						  wire_r_per_micron[1][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  }
    				  wire_c_per_micron[1][1] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);

					  wire_pitch[1][2] = 8 * FEATURESIZE;
					  aspect_ratio = 2.2;
					  wire_width = wire_pitch[1][2] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][2] - wire_width;
					  dishing_thickness = 0.1 * wire_thickness; 
					  wire_r_per_micron[1][2] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  ild_thickness = 0.55;
	    			  wire_c_per_micron[1][2] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);
					   //Nominal projections for commodity DRAM wordline/bitline
					  wire_pitch[1][3] = 2 * 0.045;
					  wire_c_per_micron[1][3] = 37.5e-15 / (256 * 2 * 0.045);
					  wire_r_per_micron[1][3] = 12 / 0.045;
					}
					else if(tech < 33 && tech > 31){
					  //Aggressive projections.
						wire_pitch[0][0] = 2.5 * FEATURESIZE;
						aspect_ratio = 3.0;
						wire_width = wire_pitch[0][0] / 2;
						wire_thickness = aspect_ratio * wire_width;
						wire_spacing = wire_pitch[0][0] - wire_width;
						barrier_thickness = 0;
						dishing_thickness = 0;
						alpha_scatter = 1;
						wire_r_per_micron[0][0] = wire_resistance(BULK_CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						ild_thickness = 0.21;
						miller_value = 1.5;
						horiz_dielectric_constant = 1.664;
						vert_dielectric_constant = 3.9;
						fringe_cap = 0.115e-15; 
						wire_c_per_micron[0][0] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);

						wire_pitch[0][1] = 4 * FEATURESIZE;
						wire_width = wire_pitch[0][1] / 2;
						wire_thickness = aspect_ratio * wire_width;
						wire_spacing = wire_pitch[0][1] - wire_width;
						wire_r_per_micron[0][1] = wire_resistance(BULK_CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						wire_c_per_micron[0][1] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);

						wire_pitch[0][2] = 8 * FEATURESIZE;
						aspect_ratio = 3.0;
						wire_width = wire_pitch[0][2] / 2;
						wire_thickness = aspect_ratio * wire_width;
						wire_spacing = wire_pitch[0][2] - wire_width;
						wire_r_per_micron[0][2] = wire_resistance(BULK_CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						ild_thickness = 0.42;
	    				wire_c_per_micron[0][2] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);


					  //Conservative projections
						wire_pitch[1][0] = 2.5 * FEATURESIZE;
						aspect_ratio = 2.0;
						wire_width = wire_pitch[1][0] / 2;
						wire_thickness = aspect_ratio * wire_width;
						wire_spacing = wire_pitch[1][0] - wire_width;
						barrier_thickness = 0.003;
						dishing_thickness = 0;
						alpha_scatter = 1;
						wire_r_per_micron[1][0] = wire_resistance(CU_RESISTIVITY, wire_width,
							wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
						ild_thickness = 0.21;
						miller_value = 1.5;
						horiz_dielectric_constant = 2.214;
						vert_dielectric_constant = 3.9;
						fringe_cap = 0.115e-15; 
						wire_c_per_micron[1][0] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
							ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
							fringe_cap);

					  wire_pitch[1][1] = 4 * FEATURESIZE;
					  wire_width = wire_pitch[1][1] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][1] - wire_width;
					  if(ram_cell_tech_flavor == 4){
						  wire_r_per_micron[1][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  }
					   else{
						  wire_r_per_micron[1][1] = wire_resistance(CU_RESISTIVITY, wire_width,
							  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  }
    				  wire_c_per_micron[1][1] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);//F/micron.

					  wire_pitch[1][2] = 8 * FEATURESIZE;
					  aspect_ratio = 2.2;
					  wire_width = wire_pitch[1][2] / 2;
					  wire_thickness = aspect_ratio * wire_width;
					  wire_spacing = wire_pitch[1][2] - wire_width;
					  dishing_thickness = 0.1 *  wire_thickness; 
				      wire_r_per_micron[1][2] = wire_resistance(CU_RESISTIVITY, wire_width,
						  wire_thickness, barrier_thickness, dishing_thickness, alpha_scatter);
					  ild_thickness = 0.385;
	    			  wire_c_per_micron[1][2] = wire_capacitance(wire_width, wire_thickness, wire_spacing, 
						  ild_thickness, miller_value, horiz_dielectric_constant, vert_dielectric_constant,
						  fringe_cap);
					  //Nominal projections for commodity DRAM wordline/bitline
					  wire_pitch[1][3] = 2 * 0.032;//micron
					  wire_c_per_micron[1][3] = 31e-15 / (256 * 2 * 0.032);//F/micron
					  wire_r_per_micron[1][3] = 12 / 0.032;//ohm/micron
					 
					 
					}
				  
					if(ram_cell_tech_flavor == 4){
						wire_local_pitch_tech_node[iter] = wire_pitch[interconnect_projection_type][3];
						wire_local_r_per_micron_tech_node[iter] = wire_r_per_micron[interconnect_projection_type][3];
						wire_local_c_per_micron_tech_node[iter] = wire_c_per_micron[interconnect_projection_type][3];
					}
					else{
						wire_local_pitch_tech_node[iter] = wire_pitch[interconnect_projection_type][0];
						wire_local_r_per_micron_tech_node[iter] = wire_r_per_micron[interconnect_projection_type][0];
						wire_local_c_per_micron_tech_node[iter] = wire_c_per_micron[interconnect_projection_type][0];
					}
				  wire_inside_mat_pitch_tech_node[iter] = wire_pitch[interconnect_projection_type][wire_inside_mat_type];
				  wire_inside_mat_r_per_micron_tech_node[iter] = wire_r_per_micron[interconnect_projection_type][wire_inside_mat_type];
				  wire_inside_mat_c_per_micron_tech_node[iter] = wire_c_per_micron[interconnect_projection_type][wire_inside_mat_type];
				  wire_outside_mat_pitch_tech_node[iter] = wire_pitch[interconnect_projection_type][wire_outside_mat_type];
				  wire_outside_mat_r_per_micron_tech_node[iter] = wire_r_per_micron[interconnect_projection_type][wire_outside_mat_type];
				  wire_outside_mat_c_per_micron_tech_node[iter] = wire_c_per_micron[interconnect_projection_type][wire_outside_mat_type];
				  }

				 
				  int_tech_low = (int) (floor(tech_low + 0.5));
				  int_tech_high = (int) (floor(tech_high+ 0.5));
				  if(int_tech_low != int_tech_high){
					  alpha = (technology - tech_low) / (tech_high - tech_low);
				  }
				  else{
					  alpha =0;
				  }
				  
				  wire_local_pitch = wire_local_pitch_tech_node[0] +  alpha * (wire_local_pitch_tech_node[1] - 
					  wire_local_pitch_tech_node[0]);
				  wire_local_r_per_micron = wire_r_per_micron[interconnect_projection_type][1];
				  wire_local_r_per_micron = wire_local_r_per_micron_tech_node[0] +  alpha * 
					  (wire_local_r_per_micron_tech_node[1] - wire_local_r_per_micron_tech_node[0]);
				  wire_local_c_per_micron = wire_c_per_micron[interconnect_projection_type][1];
				  wire_local_c_per_micron = wire_local_c_per_micron_tech_node[0] +  alpha * 
					  (wire_local_c_per_micron_tech_node[1] - wire_local_c_per_micron_tech_node[0]);
				  wire_inside_mat_pitch = wire_inside_mat_pitch_tech_node[0] +  alpha * (wire_inside_mat_pitch_tech_node[1] - 
					  wire_inside_mat_pitch_tech_node[0]);
				  wire_inside_mat_r_per_micron = wire_inside_mat_r_per_micron_tech_node[0] +  alpha * 
					  (wire_inside_mat_r_per_micron_tech_node[1] - wire_inside_mat_r_per_micron_tech_node[0]);
				  wire_inside_mat_c_per_micron = wire_inside_mat_c_per_micron_tech_node[0] +  alpha * 
					  (wire_inside_mat_c_per_micron_tech_node[1] - wire_inside_mat_c_per_micron_tech_node[0]);
				  wire_outside_mat_pitch = wire_outside_mat_pitch_tech_node[0] +  alpha * (wire_outside_mat_pitch_tech_node[1] - 
					  wire_outside_mat_pitch_tech_node[0]);
				  wire_outside_mat_r_per_micron = wire_outside_mat_r_per_micron_tech_node[0] +  alpha * 
					  (wire_outside_mat_r_per_micron_tech_node[1] - wire_outside_mat_r_per_micron_tech_node[0]);
				  wire_outside_mat_c_per_micron = wire_outside_mat_c_per_micron_tech_node[0] +  alpha * 
					  (wire_outside_mat_c_per_micron_tech_node[1] - wire_outside_mat_c_per_micron_tech_node[0]);

				  }
 
