/*------------------------------------------------------------
 *                              CACTI 5.2
 *         Copyright 2008 Hewlett-Packard Development Corporation
 *                         All Rights Reserved
 *
 * Permission to use, copy, and modify this software and its documentation is
 * hereby granted only under the following terms and conditions.  Both the
 * above copyright notice and this permission notice must appear in all copies
 * of the software, derivative works or modified versions, and any portions
 * thereof, and both notices must appear in supporting documentation.
 *
 * Users of this software agree to the terms and conditions set forth herein, and
 * hereby grant back to Hewlett-Packard Company and its affiliated companies ("HP")
 * a non-exclusive, unrestricted, royalty-free right and license under any changes, 
 * enhancements or extensions  made to the core functions of the software, including 
 * but not limited to those affording compatibility with other hardware or software
 * environments, but excluding applications which incorporate this software.
 * Users further agree to use their best efforts to return to HP any such changes,
 * enhancements or extensions that they make and inform HP of noteworthy uses of
 * this software.  Correspondence should be provided to HP at:
 *
 *                       Director of Intellectual Property Licensing
 *                       Office of Strategy and Technology
 *                       Hewlett-Packard Company
 *                       1501 Page Mill Road
 *                       Palo Alto, California  94304
 *
 * This software may be distributed (but not offered for sale or transferred
 * for compensation) to third parties, provided such third parties agree to
 * abide by the terms and conditions of this notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND HP DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS.   IN NO EVENT SHALL HP 
 * CORPORATION BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 *------------------------------------------------------------*/

#ifndef _time
#define _time

#include "areadef.h"
//long double B = 8; //Number of entries in the buffer
//long double F = 72; //Flit or word size that is equal to the bandwidth of the interconnect (change W along with this)
//long double Pr = 1; //Number of read port
//long double Pw = 1; //Number of write port
//long double  L = 65e-9; //Process technology
////long double Vdd = 0.9; //for 65nm tech
//long double vc_count = 4;
//
///* Technology independent parameters */
///*Buffer parameters*/
//long double Cpoly = 1.95e-3; //poly capacitance per unit area
//long double NCdiff_area = 1.37e-4; //diffusion area capacitance per unit area for p-mos 
//long double PCdiff_area = 3.43e-4; //cap for n-mos
//long double NCdiff_side = 2.75e-10; //diffusion side capacitance per unit length for p-mos
//long double PCdiff_side = 2.75e-10; //cap for n-mos
//long double NCdiff_ovlp = 4.01e-10; //diffusion overlap capacitance per unit width for p-mos
//long double PCdiff_ovlp = 4.76e-10; //cap for p-mos F/m
//
//long double NTm = 12*65e-9/2; //(m)
//long double PTm = 6*65e-9/2; //(m)
//long double Tpw = 5*65e-9/2; //(m)
//long double Tpr = 10*65e-9/2; //(m)
//long double dw = 15*65e-9/2; //(m)
//long double hcell = 40*65e-9/2; //(m)
//long double wcell = 20*65e-9/2; //(m)
//
//long double c_w3 = 0.10775e-9; // Capacitance of a wire with thrice the minimal spacing (F/m)
//long double NTwd = 60*65e-9/2; // should be modified later (m)
//long double PTwd = 120*65e-9/2; // should be modified later (m)
//long double NTbd = 60*65e-9/2; // should be modified later0 (m)
//long double PTbd = 120*65e-9/2; // should be modified later0 (m)
//long double Tc = 60*65e-9/2; // should be modified later (m)
//
///*Crossbar parameters. Transmisson gate is employed for connector*/
//long double NTtr = 10*65e-9/2; /*Transmission gate's nmos tr. length*/
//long double PTtr = 20*65e-9/2; /* pmos tr. length*/
//long double wt = 15*65e-9/2; /*track width*/
//long double ht = 15*65e-9/2; /*track height*/
//long double I = 5; /*Number of crossbar input ports*/
//long double O = 5; /*Number of crossbar output ports*/
//long double W = 72; /*Crossbar port width in bits*/
//long double NTi = 12.5*65e-9/2;
//long double PTi = 25*65e-9/2;
//
//long double NTid = 60*65e-9/2; // should be modified later (m)
//long double PTid = 120*65e-9/2; // should be modified later (m)
//long double NTod = 60*65e-9/2; // should be modified later (m)
//long double PTod = 120*65e-9/2; // should be modified later (m)
//
///*Arbiter parameters*/
//long double R=5; /*number of requests*/
//long double NTn1 = 13.5*65e-9/2;
//long double PTn1 = 76*65e-9/2;
//long double NTn2 = 13.5*65e-9/2;
//long double PTn2 = 76*65e-9/2;
//
//
void do_it(result_type *result, arearesult_type *arearesult, area_type *arearesult_subbanked, 
        parameter_type *parameters, double *NSubbanks, final_results *fin_res);
//void transmitter_delay(pda_res_t *a);
//double signal_rise_time();
//double signal_fall_time();
//double wire_cap(double, double, double);
//double wire_res(double, double, double);
//long double read_wordline();
//long double write_wordline();
//long double read_bitline();
//long double write_bitline();
//long double read_operation();
//long double write_operation();
//long double crossbar_power();
//long double arb_power(int);
enum wire_type {
    Global /* gloabl wires with repeaters */, 
    Semi_global /* midlevel wires with repeaters*/, 
    Low_swing /* differential low power wires with high area overhead */,
    Transmission /* tranmission lines with high area overhead */, 
    Optical /* optical wires */, 
    Invalid_wtype
};
enum router_type {
    Low_power /* less number of crossbar ports */,
    Normal,
    High_freq
};
#endif
