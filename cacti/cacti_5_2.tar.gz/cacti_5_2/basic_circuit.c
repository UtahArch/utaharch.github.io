/*------------------------------------------------------------
 *                              CACTI 5.2
 *         Copyright 2008 Hewlett-Packard Development Corporation
 *                         All Rights Reserved
 *
 * Permission to use, copy, and modify this software and its documentation is
 * hereby granted only under the following terms and conditions.  Both the
 * above copyright notice and this permission notice must appear in all copies
 * of the software, derivative works or modified versions, and any portions
 * thereof, and both notices must appear in supporting documentation.
 *
 * Users of this software agree to the terms and conditions set forth herein, and
 * hereby grant back to Hewlett-Packard Company and its affiliated companies ("HP")
 * a non-exclusive, unrestricted, royalty-free right and license under any changes, 
 * enhancements or extensions  made to the core functions of the software, including 
 * but not limited to those affording compatibility with other hardware or software
 * environments, but excluding applications which incorporate this software.
 * Users further agree to use their best efforts to return to HP any such changes,
 * enhancements or extensions that they make and inform HP of noteworthy uses of
 * this software.  Correspondence should be provided to HP at:
 *
 *                       Director of Intellectual Property Licensing
 *                       Office of Strategy and Technology
 *                       Hewlett-Packard Company
 *                       1501 Page Mill Road
 *                       Palo Alto, California  94304
 *
 * This software may be distributed (but not offered for sale or transferred
 * for compensation) to third parties, provided such third parties agree to
 * abide by the terms and conditions of this notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND HP DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS.   IN NO EVENT SHALL HP 
 * CORPORATION BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 *------------------------------------------------------------*/


#include "basic_circuit.h"

int powers (int base, int n)
{
  int i, p;

  p = 1;
  for (i = 1; i <= n; ++i)
    p *= base;
  return p;
}

/*----------------------------------------------------------------------*/

double logtwo (double x)
{
  if (x <= 0)
    printf ("%e\n", x);
  return ((double) (log (x) / log (2.0)));
}

/*----------------------------------------------------------------------*/

double gatecap (double width, double  wirelength)	/* returns gate capacitance in Farads */
     /* width: gate width in um (length is Lphy_periph_global) */
     /* wirelength: poly wire length going to gate in lambda */
{
	double cap;
	if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_cell)){//DRAM access transistor
		cap = (c_g_ideal_itrs_dram_access_transistor +  c_overlap_itrs_dram_access_transistor +
			3 * c_fringe_itrs_dram_access_transistor) * width +	Lphy_dram_access_transistor * Cpolywire;
	}
	else if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_wordline_transistor)){//DRAM wordline transistor
		cap = (c_g_ideal_itrs_dram_wordline_transistor +  c_overlap_itrs_dram_wordline_transistor +
			3 * c_fringe_itrs_dram_wordline_transistor) * width + Lphy_dram_wordline_transistor * Cpolywire;
	}
	else if((ram_cell_tech_flavor != 3)&&(ram_cell_tech_flavor != 4)&&(is_cell)){//SRAM cell transistor
		cap = (c_g_ideal_itrs_sram_cell_transistor +  c_overlap_itrs_sram_cell_transistor +
			3 * c_fringe_itrs_sram_cell_transistor) * width +	Lphy_sram_cell_transistor * Cpolywire;
	}
	else{
		cap = (c_g_ideal_itrs_periph_global +  c_overlap_itrs_periph_global +
			3 * c_fringe_itrs_periph_global) * width +	Lphy_periph_global * Cpolywire;
	}
	return(cap);
}

//In the original 0.8 micron process the gate capacitance of the pass transistor was lower than the gate capacitance per unit area of a CMOS gate. Now
//we no longer distinguish gate capacitance per unit width of a pass transistor and that of a CMOS gate. So the gatecappass function is identical to
//the gatecap function
double gatecappass (double width, double  wirelength) /* returns gate capacitance in Farads */
     /* width: gate width in um (length is Lphy_periph_global) */
     /* wirelength: poly wire length going to gate in lambda */
{
	double cap;
	if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_cell)){//DRAM access transistor
		cap = (c_g_ideal_itrs_dram_access_transistor +  c_overlap_itrs_dram_access_transistor +
			3 * c_fringe_itrs_dram_access_transistor) * width +	Lphy_dram_access_transistor * Cpolywire;
	}
	else if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_wordline_transistor)){//DRAM wordline transistor
		cap = (c_g_ideal_itrs_dram_wordline_transistor +  c_overlap_itrs_dram_wordline_transistor +
			3 * c_fringe_itrs_dram_wordline_transistor) * width + Lphy_dram_wordline_transistor * Cpolywire;
	}
	else if((ram_cell_tech_flavor != 3)&&(ram_cell_tech_flavor != 4)&&(is_cell)){//SRAM cell transistor
		cap = (c_g_ideal_itrs_sram_cell_transistor +  c_overlap_itrs_sram_cell_transistor +
			3 * c_fringe_itrs_sram_cell_transistor) * width +	Lphy_sram_cell_transistor * Cpolywire;
	}
	else{
		cap = (c_g_ideal_itrs_periph_global +  c_overlap_itrs_periph_global +
			3 * c_fringe_itrs_periph_global) * width +	Lphy_periph_global * Cpolywire;
	}
	return(cap);
}


//Function draincap returns drain capacitance in F
double draincap(double width, int nchannel, int stack, 
				int next_arg_thresh_folding_width_or_height_cell, 
				double fold_dimension)
{
	double width_folded_transistor, ratio_p_to_n, height_transistor_region,
		total_drain_width, total_drain_height_for_cap_wrt_gate,
		drain_cap_area, drain_cap_sidewall, drain_cap_wrt_gate, 
		drain_cap_total, c_junc_area, c_junc_sidewall, c_fringe, c_overlap, 
		drain_height_for_sidewall, drain_cap_metal_connecting_folded_transistors;
	int number_folded_transistors;

	c_junc_sidewall = 0.25e-15; //F/micron
	if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_cell)){//DRAM access transistor
	  c_junc_area = c_junc_itrs_dram_access_transistor;
	  c_fringe = 2 * c_fringe_itrs_dram_access_transistor;
	  c_overlap = 2 * c_overlap_itrs_dram_access_transistor;
	}
	else  if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_wordline_transistor)){//DRAM wordline transistor
		c_junc_area = c_junc_itrs_dram_wordline_transistor;
		c_fringe = 2 * c_fringe_itrs_dram_wordline_transistor;
		c_overlap = 2 * c_overlap_itrs_dram_wordline_transistor;
	}
	else if((ram_cell_tech_flavor != 3)&&(ram_cell_tech_flavor != 4)&&(is_cell)){//SRAM cell transistor
		c_junc_area = c_junc_itrs_sram_cell_transistor;
		c_fringe = 2 * c_fringe_itrs_sram_cell_transistor;
		c_overlap = 2 * c_overlap_itrs_sram_cell_transistor;
	}
	else{//DRAM or SRAM all other transistors
		c_junc_area = c_junc_itrs_periph_global;
		c_fringe = 2 * c_fringe_itrs_periph_global;
		c_overlap = 2 * c_overlap_itrs_periph_global;
	}
	
	drain_cap_metal_connecting_folded_transistors = 0;
	//Determine the width of the transistor after folding (if it is getting folded)
	if(next_arg_thresh_folding_width_or_height_cell == 0){//interpret fold_dimension as the
		//the folding width threshold i.e. the value of transistor width above which the
		//transistor gets folded
		width_folded_transistor = fold_dimension;
	} 
	else{//interpret fold_dimension as the height of the cell that this transistor is part of. 
		height_transistor_region = fold_dimension - 2 * HPOWERRAIL;
		ratio_p_to_n = 2.0 / (2.0 + 1.0);
		if(nchannel){
			width_folded_transistor = (1 - ratio_p_to_n) * (height_transistor_region - MIN_GAP_BET_P_AND_N_DIFFS);
		}
		else{
			width_folded_transistor = ratio_p_to_n * (height_transistor_region - MIN_GAP_BET_P_AND_N_DIFFS);
		}
	}
	number_folded_transistors = (int) (ceil(width / width_folded_transistor));

	if(number_folded_transistors < 2){
		width_folded_transistor = width;
	}

	total_drain_width = (WIDTHPOLYCONTACT + 2 * SPACINGPOLYTOCONTACT) + (stack - 1) * SPACINGPOLYTOPOLY;
	drain_height_for_sidewall = width_folded_transistor;
	total_drain_height_for_cap_wrt_gate = width_folded_transistor + 2 * width_folded_transistor * 
		(stack - 1);
	if(number_folded_transistors > 1){
		total_drain_width += (number_folded_transistors - 2) * (WIDTHPOLYCONTACT + 
			2 * SPACINGPOLYTOCONTACT) + (number_folded_transistors - 1) * ((stack - 1) * 
			SPACINGPOLYTOPOLY);
		if(number_folded_transistors%2 == 0){
			drain_height_for_sidewall = 0 ;
		}
		total_drain_height_for_cap_wrt_gate *=  number_folded_transistors;
		drain_cap_metal_connecting_folded_transistors = wire_local_c_per_micron * 
			total_drain_width;
	}
	
	drain_cap_area = c_junc_area * total_drain_width * width_folded_transistor;
	drain_cap_sidewall = c_junc_sidewall * (drain_height_for_sidewall + 2 * total_drain_width);
	drain_cap_wrt_gate  = (c_fringe + c_overlap) * total_drain_height_for_cap_wrt_gate;

	drain_cap_total = drain_cap_area + drain_cap_sidewall + drain_cap_wrt_gate +
		drain_cap_metal_connecting_folded_transistors;
	return(drain_cap_total);
}




double transreson (double width,int nchannel,int stack)	/* returns resistance in ohms */
     /* width: in um */
     /* nchannel: whether n or p-channel (boolean) */
     /* stack: number of transistors in series */
{
  double restrans;
  if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_cell)){//DRAM access transistor
	  restrans = (nchannel) ? Rnchannelon_itrs_dram_access_transistor : Rpchannelon_itrs_dram_access_transistor;	    
  }
  else  if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_wordline_transistor)){//DRAM wordline transistor
	  restrans = (nchannel) ? Rnchannelon_itrs_dram_wordline_transistor : Rpchannelon_itrs_dram_wordline_transistor;	    
  }
  else if((ram_cell_tech_flavor != 3)&&(ram_cell_tech_flavor != 4)&&(is_cell)){//SRAM cell transistor
	  restrans = (nchannel) ? Rnchannelon_itrs_sram_cell_transistor : Rpchannelon_itrs_sram_cell_transistor;	    
  }
  else{//DRAM or SRAM all other transistors
	  restrans = (nchannel) ? Rnchannelon_itrs_periph_global : Rpchannelon_itrs_periph_global;
  }

  return (stack * restrans / width);

}

/*----------------------------------------------------------------------*/

/* This routine operates in reverse: given a resistance, it finds
 * the transistor width that would have this R.  It is used in the
 * data wordline to estimate the wordline driver size. */

double restowidth (double res,int nchannel)	/* returns width in um */
     /* res: resistance in ohms */
     /* nchannel: whether N-channel or P-channel */
{
  double restrans;
   if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_cell)){//DRAM access transistor
	  restrans = (nchannel) ? Rnchannelon_itrs_dram_access_transistor : Rpchannelon_itrs_dram_access_transistor;	    
  }
  else if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_wordline_transistor)){//DRAM wordline transistor
	  restrans = (nchannel) ? Rnchannelon_itrs_dram_wordline_transistor : Rpchannelon_itrs_dram_wordline_transistor;	    
  }
  else if((ram_cell_tech_flavor != 3)&&(ram_cell_tech_flavor != 4)&&(is_cell)){//SRAM cell transistorr
	  restrans = (nchannel) ? Rnchannelon_itrs_sram_cell_transistor : Rpchannelon_itrs_sram_cell_transistor;	    
  }
  else{//DRAM or SRAM all other transistors
	  restrans = (nchannel) ? Rnchannelon_itrs_periph_global : Rpchannelon_itrs_periph_global ;	    
  }
  return (restrans / res);
}


double pmos_to_nmos_sizing_ratio(){
	double p_to_n_sizing_ratio;
	if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(is_wordline_transistor)){//DRAM wordline transistor
		p_to_n_sizing_ratio = nmos_to_pmos_effective_current_drive_ratio_dram_wordline_transistor;
	}
	else{//DRAM or SRAM peripheral/global transistors
		p_to_n_sizing_ratio = nmos_to_pmos_effective_current_drive_ratio_periph_global;
	}
	return(p_to_n_sizing_ratio);
}
/*----------------------------------------------------------------------*/

double horowitz (double inputramptime,double  tf,double  vs1,double  vs2,int rise)
	/* inputramptime: input rise time */
    /* tf: time constant of gate */
    /* vs1, vs2: threshold voltages */
    /* rise: whether INPUT rise or fall (boolean) */
{
  double a, b, td;

  a = inputramptime / tf;
  if (rise == RISE)
    {
      b = 0.5;
      td = tf * sqrt (log (vs1) * log (vs1) + 2 * a * b * (1.0 - vs1)) +
	tf * (log (vs1) - log (vs2));
    }
  else
    {
      b = 0.4;
      td = tf * sqrt (log (1.0 - vs1) * log (1.0 - vs1) + 2 * a * b * (vs1)) +
	tf * (log (1.0 - vs1) - log (1.0 - vs2));
    }
  return (td);
}

//Returns log to the base 4 of the input. When the log to the base 4 of a number is
//an integer (example: logbasefour(64) = 3), this function guarantees (within assumed 
//floating point representation error bounds) that the output would be the exact integral
//representation (example: 3 would be represented as 3.0 and not as something like
//2.99999....or 3.000...1). This guaranteed is based on the use of EPSILON2 below.  Note that
//even though the function works for any double number presently its usage at several places 
//implicitly assumes that the function input is a power of 2 integer
double logbasefour (double x)
{
	double temp;
	if (x <= 0){
	  printf ("logbasefour:%g\n", x);
	  exit(1);
	}
   temp = log (x) / log (4.0);
   if(fabs(temp - (int) (temp + EPSILON3)) < EPSILON2){
	   return((int) (temp + EPSILON3));
   }
   else return(temp);
}

//Returns log to the base 2 of the input. Read comments above logbasefour function above. 
double logbasetwo (double x)
{
	double temp;
	if (x <= 0){
	  printf ("logbasetwo:%g\n", x);
	  exit(1);
	}
   temp = log (x) / log (2.0);
   if(fabs(temp - (int) (temp + EPSILON3)) < EPSILON2){
	   return((int) (temp + EPSILON3));
   }
   else return(temp);
}


