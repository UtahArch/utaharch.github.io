/*------------------------------------------------------------
 *                             CACTI 5.2
 *         Copyright 2008 Hewlett-Packard Development Corporation
 *                         All Rights Reserved
 *
 * Permission to use, copy, and modify this software and its documentation is
 * hereby granted only under the following terms and conditions.  Both the
 * above copyright notice and this permission notice must appear in all copies
 * of the software, derivative works or modified versions, and any portions
 * thereof, and both notices must appear in supporting documentation.
 *
 * Users of this software agree to the terms and conditions set forth herein, and
 * hereby grant back to Hewlett-Packard Company and its affiliated companies ("HP")
 * a non-exclusive, unrestricted, royalty-free right and license under any changes, 
 * enhancements or extensions  made to the core functions of the software, including 
 * but not limited to those affording compatibility with other hardware or software
 * environments, but excluding applications which incorporate this software.
 * Users further agree to use their best efforts to return to HP any such changes,
 * enhancements or extensions that they make and inform HP of noteworthy uses of
 * this software.  Correspondence should be provided to HP at:
 *
 *                       Director of Intellectual Property Licensing
 *                       Office of Strategy and Technology
 *                       Hewlett-Packard Company
 *                       1501 Page Mill Road
 *                       Palo Alto, California  94304
 *
 * This software may be distributed (but not offered for sale or transferred
 * for compensation) to third parties, provided such third parties agree to
 * abide by the terms and conditions of this notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND HP DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS.   IN NO EVENT SHALL HP 
 * CORPORATION BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 *------------------------------------------------------------*/

#include "time.h"
#include "math.h"

/*#ifdef __unix__
pthread_mutex_t com_mut_var = PTHREAD_MUTEX_INITIALIZER;
#endif*/

void reset_powerDef(powerDef *power) {
    power->readOp.dynamic = 0.0;
    power->readOp.leakage = 0.0;

    power->writeOp.dynamic = 0.0;
    power->writeOp.leakage = 0.0;
}

void copy_powerDef(powerDef *dest, powerDef source) {
    dest->readOp.dynamic = source.readOp.dynamic;
    dest->readOp.leakage = source.readOp.leakage;

    dest->writeOp.dynamic = source.writeOp.dynamic;
    dest->writeOp.leakage = source.writeOp.leakage;
}



void compute_widths_repeaters_array_edge_to_bank_edge(array_edge_to_bank_edge_htree_sizing *ptr_arr_edge_to_bank_edge_htree_sizing)
{
	double d, R_v, C_g, C_d, b, a, r, k, R_w, C_w, FO4, lcap, wcap, lopt, wopt,
		delay_per_micron, best_delay, perc_diff_from_dyn_energy_best_delay,
		perc_diff_in_delay_from_best_delay_repeater_solution, dyn_energy_best_delay, delay_given_length,
		dyn_energy, best_perc_diff_from_dyn_energy_best_delay, delay_per_micron_1,
		dyn_energy_best_delay_1, best_delay_new_wcap;
	double pmos_to_nmos_sizing_r;
	int index, i, max_index, best_index;
	typedef struct{
		double lcap;
		double wcap;
		double delay;
		powerDef power;
	} repeater_solution;

    repeater_solution solution[10000];

	ptr_arr_edge_to_bank_edge_htree_sizing->opt_sizing = 0;
	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
	d = 0;
	R_v = transreson(1, NCH, 1);
	C_g = gatecap(1, 0);
	C_d = draincap(1, NCH, 1, 1, DEFAULTHEIGHTCELL);
	a = 3;
	b = C_d * a / C_g;
	r = 1;
	k = 0.69;
	R_w = wire_outside_mat_r_per_micron;
	C_w = wire_outside_mat_c_per_micron;
	lcap = 1;
	FO4 = R_v * a * (C_d + 4 * C_g);		

	lopt = sqrt((18.9 * d + 2 * k * r * (a + b)) / k) * sqrt(R_v * C_g / (R_w * C_w));
	wopt = sqrt(r / a) * sqrt(R_v * C_w / (R_w * C_g));
	lcap = 1.0;
	wcap = 1.0;
	delay_per_micron_1 = (sqrt(d + (k * r * (a + b) / 9.45)) * sqrt(k / 2) * (1 / lcap + lcap) +
		k * sqrt(a * r / 9.45) * (1 / wcap + wcap));
	delay_per_micron =  delay_per_micron_1 * sqrt(FO4 * R_w * C_w);
	best_delay = delay_per_micron ;
	dyn_energy_best_delay_1 = 1 + sqrt(r / a) * sqrt(k / (18.9 * d + 2 * k * r * (a + b))) * (a + b) * wcap / lcap;
	dyn_energy_best_delay = dyn_energy_best_delay_1 * C_w * vdd_periph_global * vdd_periph_global;

	//Now find a solution that is better from an energy-delay perspective. First find solutions that are 
	//worse in delay but within MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION of the best 
	//delay solution
	index = 0;
	for(lcap = 1.0; lcap < 10; lcap += 0.1){
		for(wcap = 1.0; wcap > 0; wcap -= 0.05){
			delay_per_micron = (sqrt(d + (k * r * (a + b) / 9.45)) * sqrt(k / 2) * (1 / lcap + lcap) +
				k * sqrt(a * r / 9.45) * (1 / wcap + wcap)) * sqrt(FO4 * R_w * C_w);
			delay_given_length = delay_per_micron ;
			dyn_energy = C_w * vdd_periph_global * vdd_periph_global * 
				(1 + sqrt(r / a) * sqrt(k / (18.9 * d + 2 * k * r * (a + b))) * (a + b) * wcap / lcap);
			perc_diff_in_delay_from_best_delay_repeater_solution = (delay_given_length - best_delay) * 100 / best_delay;
			if(perc_diff_in_delay_from_best_delay_repeater_solution <= MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION){
				solution[index].lcap = lcap;
				solution[index].wcap = wcap;
				solution[index].delay = delay_given_length;
				solution[index].power.readOp.dynamic = dyn_energy;
				solution[index].power.readOp.leakage = 0;	
				++index;
			}
		}
	}
	max_index = index - 1;

	best_perc_diff_from_dyn_energy_best_delay = 0;
	best_index = 0;
	for(i=0; i<=max_index; ++i){
		perc_diff_from_dyn_energy_best_delay = (double)((dyn_energy_best_delay - 
			solution[i].power.readOp.dynamic) * 100 / dyn_energy_best_delay);
		if(perc_diff_from_dyn_energy_best_delay >= best_perc_diff_from_dyn_energy_best_delay){
			best_perc_diff_from_dyn_energy_best_delay =	perc_diff_from_dyn_energy_best_delay;	
			best_index = i;
		}
	}
	ptr_arr_edge_to_bank_edge_htree_sizing->width_inverter_nmos = solution[best_index].wcap * wopt;
	if(ptr_arr_edge_to_bank_edge_htree_sizing->width_inverter_nmos > MAX_NMOS_WIDTH){
		ptr_arr_edge_to_bank_edge_htree_sizing->width_inverter_nmos = MAX_NMOS_WIDTH;
		//Now wcap has changed and needs to be calculated based on the above value of 
		//width_inverter_nmos. So recalculate optimal lcap for the new wcap.
		//Now it's possible that with the new wcap, the solution does not satisfy the 
		//MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION constraint. In that case, choose the best delay 
		//solution possible with the new wcap
		wcap = ptr_arr_edge_to_bank_edge_htree_sizing->width_inverter_nmos / wopt;
		//Now find out if the MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION can be satisfied
		//with the new wcap and if so find appropriate solution.
		index = 0;
		for(lcap = 1.0; lcap < 10.1; lcap += 0.1){
			delay_per_micron = (sqrt(d + (k * r * (a + b) / 9.45)) * sqrt(k / 2) * (1 / lcap + lcap) +
				k * sqrt(a * r / 9.45) * (1 / wcap + wcap)) * sqrt(FO4 * R_w * C_w);
			delay_given_length = delay_per_micron;
			dyn_energy = C_w * vdd_periph_global * vdd_periph_global * 
				(1 + sqrt(r / a) * sqrt(k / (18.9 * d + 2 * k * r * (a + b))) * (a + b) * wcap / lcap);
			perc_diff_in_delay_from_best_delay_repeater_solution = (delay_given_length - best_delay) * 100 / best_delay;
			if(perc_diff_in_delay_from_best_delay_repeater_solution <= MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION){
				solution[index].lcap = lcap;
				solution[index].wcap = wcap;
				solution[index].delay = delay_given_length;
				solution[index].power.readOp.dynamic = dyn_energy;
				solution[index].power.readOp.leakage = 0;	
				++index;
			}
		}
		max_index = index - 1;
		if(max_index < 0){//this means that it is not possible to satisfy the 
			//MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION with the new wcap, so 
			//we simply find the solution that gives best delay with the new wcap. 
			best_index = 0;
			best_delay_new_wcap = BIGNUM;
			for(lcap = 1.0; lcap < 10.1; lcap += 0.1){
				delay_per_micron = (sqrt(d + (k * r * (a + b) / 9.45)) * sqrt(k / 2) * (1 / lcap + lcap) +
					k * sqrt(a * r / 9.45) * (1 / wcap + wcap)) * sqrt(FO4 * R_w * C_w);
				delay_given_length = delay_per_micron;
				dyn_energy = C_w * vdd_periph_global * vdd_periph_global * 
					(1 + sqrt(r / a) * sqrt(k / (18.9 * d + 2 * k * r * (a + b))) * 
					(a + b) * wcap / lcap);
				if(delay_given_length < best_delay_new_wcap){
					best_delay_new_wcap = delay_given_length;
					solution[best_index].lcap = lcap;
					solution[best_index].wcap = wcap;
					solution[best_index].delay = delay_given_length;
					solution[best_index].power.readOp.dynamic = dyn_energy;
					solution[best_index].power.readOp.leakage = 0;
				}
			}
		}
		else{
			best_perc_diff_from_dyn_energy_best_delay = 0;
			best_index = 0;
			for(i=0; i<=max_index; ++i){
				perc_diff_from_dyn_energy_best_delay = (double)((dyn_energy_best_delay - 
					solution[i].power.readOp.dynamic) * 100 / dyn_energy_best_delay);
				if(perc_diff_from_dyn_energy_best_delay >= best_perc_diff_from_dyn_energy_best_delay){
					best_perc_diff_from_dyn_energy_best_delay =	perc_diff_from_dyn_energy_best_delay;	
					best_index = i;
				}
			}
		}
	}
	ptr_arr_edge_to_bank_edge_htree_sizing->width_inverter_pmos = pmos_to_nmos_sizing_r * ptr_arr_edge_to_bank_edge_htree_sizing->width_inverter_nmos;
	ptr_arr_edge_to_bank_edge_htree_sizing->opt_sizing =  ptr_arr_edge_to_bank_edge_htree_sizing->width_inverter_nmos / (minimum_width_nmos);
	ptr_arr_edge_to_bank_edge_htree_sizing->opt_segment_length =  solution[best_index].lcap * lopt;
		
}



void initialize_addr_datain_htree(
        addr_datain_htree_node *ptr_htree_node, 
        int number_htree_nodes,
        double htree_seg_length,  
        double *delay, powerDef *power, 
        double *length_wire_htree_node)
{
    int i, j, multiplier;
	double input_gate_cap, F, c_load, pmos_to_nmos_sizing_r;

    if(number_htree_nodes == 0){
        number_htree_nodes = 1;
    }
    *delay = 0;
    power->readOp.dynamic = 0;
    power->readOp.leakage = 0;
    power->writeOp.dynamic = 0;
    power->writeOp.leakage = 0;

	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();

    for(i = 0; i < MAX_NUMBER_HTREE_NODES; ++i){
		ptr_htree_node[i].power.readOp.dynamic = 0;
        ptr_htree_node[i].power.readOp.leakage = 0;
        ptr_htree_node[i].power.writeOp.dynamic = 0;
        ptr_htree_node[i].power.writeOp.leakage = 0;
        for(j = 0; j < MAX_NUMBER_GATES_STAGE; ++j){
            ptr_htree_node[i].width_n[j] = 0;
            ptr_htree_node[i].width_p[j] = 0;
         }
    }

    multiplier = 1;
	for(i = number_htree_nodes - 1; i >= 0; --i){
		ptr_htree_node[i].min_number_gates = 2;
		length_wire_htree_node[i] = multiplier * htree_seg_length;
        ptr_htree_node[i].r_wire_load = wire_outside_mat_r_per_micron * length_wire_htree_node[i];
        ptr_htree_node[i].c_wire_load = wire_outside_mat_c_per_micron * length_wire_htree_node[i];
		ptr_htree_node[i].f_wire = ptr_htree_node[i].r_wire_load * ptr_htree_node[i].c_wire_load / (2 * kinv);
		multiplier *= 2;
	}

	//Calculate width of input gate of each H-tree segment
	ptr_htree_node[0].width_n[0] = 2 * minimum_width_nmos;
	ptr_htree_node[0].width_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
	for(i = number_htree_nodes - 1; i > 0; --i){
		if(i == number_htree_nodes - 1){
			ptr_htree_node[i].c_gate_load = gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0);
		}
        else{
			ptr_htree_node[i].c_gate_load = 2 * gatecap(ptr_htree_node[i+1].width_n[0] +
				ptr_htree_node[i+1].width_p[0], 0);
		}
		c_load = ptr_htree_node[i].c_gate_load + ptr_htree_node[i].c_wire_load;
		F = (ptr_htree_node[i-1].r_wire_load * gnand2 * c_load / (2 * kinv * fopt)) * 
			(1 + sqrt(1 + 2 * fopt / ptr_htree_node[i-1].f_wire));
		if(F <= pow(fopt, 2)){
			//Include a two-stage buffer
			F = pow(fopt, 2);
		}
		input_gate_cap = gnand2 * c_load / F;
		ptr_htree_node[i].width_n[0] = (input_gate_cap / 2) / gatecap(1, 0);
		if(ptr_htree_node[i].width_n[0] < 2 * minimum_width_nmos){
			ptr_htree_node[i].width_n[0] = 2 * minimum_width_nmos;
		}
		if(ptr_htree_node[i].width_n[0] > MAX_NMOS_WIDTH){
			//Two-stage buffer with 2nd stage composed of MAX_NMOS_WIDTH. 
			c_load = gatecap(MAX_NMOS_WIDTH + pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH, 0);
			input_gate_cap = gnand2 * c_load / fopt;
			ptr_htree_node[i].width_n[0] = (2 / (2 + pmos_to_nmos_sizing_r)) * input_gate_cap / gatecap(1, 0);
		}
		ptr_htree_node[i].width_p[0] = (pmos_to_nmos_sizing_r / (2 + pmos_to_nmos_sizing_r)) * input_gate_cap / gatecap(1, 0);
	}
	if(number_htree_nodes > 1){
		ptr_htree_node[0].c_gate_load = gatecap(ptr_htree_node[1].width_n[0] + ptr_htree_node[1].width_p[0], 0);
	}
	else{
		ptr_htree_node[0].c_gate_load = gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0);
	}
}


void initialize_addr_datain_htree_with_repeaters(
        addr_datain_htree_at_mat_interval *ptr_htree_at_mat_interval, 
        double *delay, powerDef *power, double mat_dimension)
{

   *delay = 0;
   reset_powerDef(power);
   reset_powerDef(&ptr_htree_at_mat_interval->power_buffer);
   reset_powerDef(&ptr_htree_at_mat_interval->power_buffer_driving_nand2_buffer);
   reset_powerDef(&ptr_htree_at_mat_interval->power_nand2_buffer_driving_buffer);
   reset_powerDef(&ptr_htree_at_mat_interval->power_nand2_buffer_driving_nand2_buffer);
   reset_powerDef(&ptr_htree_at_mat_interval->power_tristate_driver_driving_buffer);
   reset_powerDef(&ptr_htree_at_mat_interval->power_tristate_driver_driving_tristate_driver);
   reset_powerDef(&ptr_htree_at_mat_interval->power_buffer_driving_tristate_driver);
   reset_powerDef(&ptr_htree_at_mat_interval->power_nand2_buffer_driving_final_seg);
   reset_powerDef(&ptr_htree_at_mat_interval->power_buffer_driving_final_seg);
   reset_powerDef(&ptr_htree_at_mat_interval->power_tristate_driver_driving_final_seg);
   ptr_htree_at_mat_interval->area_buffer = 0;
   ptr_htree_at_mat_interval->area_buffer_driving_final_seg = 0;
   ptr_htree_at_mat_interval->area_buffer_driving_nand2_buffer = 0;
   ptr_htree_at_mat_interval->area_nand2_buffer_driving_buffer = 0;
   ptr_htree_at_mat_interval->area_nand2_buffer_driving_final_seg = 0;
   ptr_htree_at_mat_interval->area_nand2_buffer_driving_nand2_buffer = 0;
   ptr_htree_at_mat_interval->area_tristate_driver_driving_buffer = 0;
   ptr_htree_at_mat_interval->area_tristate_driver_driving_final_seg = 0;
   ptr_htree_at_mat_interval->area_tristate_driver_driving_tristate_driver = 0;
   ptr_htree_at_mat_interval->mat_dimension = mat_dimension;
   ptr_htree_at_mat_interval->max_delay_between_buffers = 0;
 }



void compute_widths_addr_datain_htree(addr_datain_htree_node *ptr_htree_node, int number_htree_nodes)
{
    int i, j;
    double c_load, c_input, F, f;
	double pmos_to_nmos_sizing_r;
	
	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
    if(number_htree_nodes == 0){
        number_htree_nodes = 1;
    }
    for(i = 0; i < number_htree_nodes; ++i){
        c_load = ptr_htree_node[i].c_gate_load + ptr_htree_node[i].c_wire_load;
        F =  gnand2 * c_load / gatecap(ptr_htree_node[i].width_n[0] + ptr_htree_node[i].width_p[0], 0);
        ptr_htree_node[i].number_gates = (int) (log(F) / log(fopt));
        if(ptr_htree_node[i].number_gates%2 != 0){
            ++ptr_htree_node[i].number_gates;
        }
		if(ptr_htree_node[i].number_gates < ptr_htree_node[i].min_number_gates){
            ptr_htree_node[i].number_gates = ptr_htree_node[i].min_number_gates;
        }
        f = pow(F, 1.0 / ptr_htree_node[i].number_gates);

		j = ptr_htree_node[i].number_gates - 1;
		c_input = c_load / f;
		ptr_htree_node[i].width_n[j] = (1.0 / (1 + pmos_to_nmos_sizing_r)) * c_input / gatecap(1, 0);
		if(ptr_htree_node[i].width_n[j] < minimum_width_nmos){
			ptr_htree_node[i].width_n[j] = minimum_width_nmos;
		}
		ptr_htree_node[i].width_p[j]  = pmos_to_nmos_sizing_r * ptr_htree_node[i].width_n[j];

		if(ptr_htree_node[i].width_n[j] > MAX_NMOS_WIDTH){
			c_load = gatecap(MAX_NMOS_WIDTH + pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH, 0);
			F =  gnand2 * c_load / gatecap(ptr_htree_node[i].width_n[0] +
				ptr_htree_node[i].width_p[0], 0);
			ptr_htree_node[i].number_gates = (int) (log(F) / log(fopt)) + 1;
			if(ptr_htree_node[i].number_gates%2 != 0){
				++ptr_htree_node[i].number_gates;
			}
			if(ptr_htree_node[i].number_gates < ptr_htree_node[i].min_number_gates){
				ptr_htree_node[i].number_gates = ptr_htree_node[i].min_number_gates;
			}
			f = pow(F, 1.0 / ptr_htree_node[i].number_gates);
			j = ptr_htree_node[i].number_gates - 1;
			ptr_htree_node[i].width_n[j] = MAX_NMOS_WIDTH;
			ptr_htree_node[i].width_p[j]  = pmos_to_nmos_sizing_r * ptr_htree_node[i].width_n[j];
		}
		
		for(j = ptr_htree_node[i].number_gates - 2; j > 0; --j){
            ptr_htree_node[i].width_n[j] = ptr_htree_node[i].width_n[j+1] / f;
            if(ptr_htree_node[i].width_n[j] < minimum_width_nmos){
                ptr_htree_node[i].width_n[j] = minimum_width_nmos;
            }
            ptr_htree_node[i].width_p[j]  = pmos_to_nmos_sizing_r * ptr_htree_node[i].width_n[j];
        }
    }
}


void compute_widths_repeaters_bank_htree(bank_htree_sizing *ptr_bnk_htree_sizing)
{
    int i, index, max_index, best_index;
    double d, R_v, C_g, C_d, b, a, r, k, R_w, C_w, FO4, lcap, wcap, lopt, wopt, F2point5, e,
		internal_fanout, wopt_featuresize, delay_per_micron, delay_given_length, best_delay, dyn_energy_best_delay,
		dyn_energy, perc_diff_in_delay_from_best_delay_repeater_solution, 
		best_perc_diff_from_dyn_energy_best_delay,perc_diff_from_dyn_energy_best_delay, best_delay_new_wcap;
	double c_input_nand2, c_input_nor2;
	double dyn_energy_best_delay_1, pmos_to_nmos_sizing_r;

	typedef struct{
		double lcap;
		double wcap;
		double delay;
		powerDef power;
	} buffer_solution;

	buffer_solution solution[10000];


	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
	//Compute sizing of buffer repeaters using Ron Ho's sizing
	R_v = transreson(1, NCH, 1);
	C_g = gatecap(1, 0);
	C_d = draincap(1, NCH, 1, 1, DEFAULTHEIGHTCELL);
	a = 3;
	internal_fanout = 2.5;
	b = (C_d / C_g) * a * internal_fanout;
	r = 1 / internal_fanout;
	k = 0.69;
	e = a * (C_d / C_g + internal_fanout);
	FO4 = R_v * a * (C_d + 4 * C_g);
	F2point5 = R_v * a * (C_d + 2.5 * C_g);
	d = F2point5 / FO4;
	R_w = wire_outside_mat_r_per_micron;
	C_w = wire_outside_mat_c_per_micron;
	lopt = sqrt((18.9 * d + 2 * k * r * (a + b)) / k) * sqrt(R_v * C_g / (R_w * C_w));
	wopt = sqrt(r / a) * sqrt(R_v * C_w / (R_w * C_g));
	wopt_featuresize = wopt / FEATURESIZE;
	lcap = 1.0;
	wcap = 1.0;
	delay_per_micron = (sqrt(d + (k * r * (a + b) / 9.45)) * sqrt(k / 2) * (1 / lcap + lcap) +
		k * sqrt(a * r / 9.45) * (1 / wcap + wcap)) * sqrt(FO4 * R_w * C_w);
	best_delay = delay_per_micron;
	dyn_energy_best_delay = C_w * vdd_periph_global * vdd_periph_global * 
		(1 + sqrt(r / a) * sqrt(k / (18.9 * d + 2 * k * r * (a + b + e))) * (a + b + e) * wcap / lcap);
	dyn_energy_best_delay_1 = 1 + sqrt(r / a) * sqrt(k / (18.9 * d + 2 * k * r * (a + b + e))) * (a + b + e) * wcap / lcap;
	dyn_energy_best_delay = dyn_energy_best_delay_1 * C_w * vdd_periph_global * vdd_periph_global;
	//Now find a solution that is better from an energy-delay perspective. Find the solution that
	//reduces energy by about OPT_PERC_DIFF_IN_ENERGY_FROM_BEST_DELAY_REPEATER_SOLUTION. We first find solutions that are 
	//worse in delay but within MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION of the best 
	//delay delay. 
	index = 0;
	for(lcap = 1.0; lcap < 10.1; lcap += 0.1){
		for(wcap = 1.0; wcap > 0; wcap -= 0.025){
			delay_per_micron = (sqrt(d + (k * r * (a + b) / 9.45)) * sqrt(k / 2) * (1 / lcap + lcap) +
				k * sqrt(a * r / 9.45) * (1 / wcap + wcap)) * sqrt(FO4 * R_w * C_w);
			delay_given_length = delay_per_micron;
			dyn_energy = C_w * vdd_periph_global * vdd_periph_global * 
				(1 + sqrt(r / a) * sqrt(k / (18.9 * d + 2 * k * r * (a + b + e))) * (a + b + e) * wcap / lcap);
			perc_diff_in_delay_from_best_delay_repeater_solution = (delay_given_length - best_delay) * 100 / best_delay;
			if(perc_diff_in_delay_from_best_delay_repeater_solution <= MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION){
				solution[index].lcap = lcap;
				solution[index].wcap = wcap;
				solution[index].delay = delay_given_length;
				solution[index].power.readOp.dynamic = dyn_energy;
				solution[index].power.readOp.leakage = 0;	
				++index;
			}
		}
	}
	max_index = index - 1;

	best_perc_diff_from_dyn_energy_best_delay = 0;
	best_index = 0;
	for(i=0; i<=max_index; ++i){
		perc_diff_from_dyn_energy_best_delay = (double)((dyn_energy_best_delay - 
			solution[i].power.readOp.dynamic) * 100 / dyn_energy_best_delay);
		if(perc_diff_from_dyn_energy_best_delay >= best_perc_diff_from_dyn_energy_best_delay){
			best_perc_diff_from_dyn_energy_best_delay =	perc_diff_from_dyn_energy_best_delay;	
			best_index = i;
		}
	}
	
	ptr_bnk_htree_sizing->buffer_opt_sizing = solution[best_index].wcap * wopt / (minimum_width_nmos);
	ptr_bnk_htree_sizing->buffer_segment_opt_length = solution[best_index].lcap * lopt;
	
	ptr_bnk_htree_sizing->buffer_width_n[0] = solution[best_index].wcap * wopt;
	ptr_bnk_htree_sizing->buffer_width_n[1] = internal_fanout * ptr_bnk_htree_sizing->buffer_width_n[0];
	if(ptr_bnk_htree_sizing->buffer_width_n[1] > MAX_NMOS_WIDTH){
		ptr_bnk_htree_sizing->buffer_width_n[1] = MAX_NMOS_WIDTH;
		ptr_bnk_htree_sizing->buffer_width_n[0] = MAX_NMOS_WIDTH / internal_fanout;
		//Now wcap has changed and needs to be calculated based on the above value of 
		//ptr_bnk_htree_sizing->buffer_width_n[0]. So recalculate optimal lcap for the new wcap.
		//Now it's possible that with the new wcap, the solution does not satisfy the 
		//MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION constraint. In that case, choose the best delay 
		//solution possible with the new wcap
		wcap = ptr_bnk_htree_sizing->buffer_width_n[0] / wopt;
		//Now find out if the MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION can be satisfied
		//with the new wcap and if so find appropriate solution.
		index = 0;
		for(lcap = 1.0; lcap < 10.1; lcap += 0.1){
			delay_per_micron = (sqrt(d + (k * r * (a + b) / 9.45)) * sqrt(k / 2) * (1 / lcap + lcap) +
				k * sqrt(a * r / 9.45) * (1 / wcap + wcap)) * sqrt(FO4 * R_w * C_w);
			delay_given_length = delay_per_micron;
			dyn_energy = C_w * vdd_periph_global * vdd_periph_global * 
				(1 + sqrt(r / a) * sqrt(k / (18.9 * d + 2 * k * r * (a + b + e))) * (a + b + e) * wcap / lcap);
			perc_diff_in_delay_from_best_delay_repeater_solution = (delay_given_length - best_delay) * 100 / best_delay;
			if(perc_diff_in_delay_from_best_delay_repeater_solution <= MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION){
				solution[index].lcap = lcap;
				solution[index].wcap = wcap;
				solution[index].delay = delay_given_length;
				solution[index].power.readOp.dynamic = dyn_energy;
				solution[index].power.readOp.leakage = 0;	
				++index;
			}
		}
		max_index = index - 1;
		if(max_index < 0){//this means that it is not possible to satisfy the 
			//MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION with the new wcap, so 
			//we simply find the solution that gives best delay with the new wcap. 
			best_index = 0;
			best_delay_new_wcap = BIGNUM;
			for(lcap = 1.0; lcap < 10.1; lcap += 0.1){
				delay_per_micron = (sqrt(d + (k * r * (a + b) / 9.45)) * sqrt(k / 2) * (1 / lcap + lcap) +
					k * sqrt(a * r / 9.45) * (1 / wcap + wcap)) * sqrt(FO4 * R_w * C_w);
				delay_given_length = delay_per_micron;
				dyn_energy = C_w * vdd_periph_global * vdd_periph_global * 
					(1 + sqrt(r / a) * sqrt(k / (18.9 * d + 2 * k * r * (a + b + e))) * 
					(a + b + e) * wcap / lcap);
				if(delay_given_length < best_delay_new_wcap){
					best_delay_new_wcap = delay_given_length;
					solution[best_index].lcap = lcap;
					solution[best_index].wcap = wcap;
					solution[best_index].delay = delay_given_length;
					solution[best_index].power.readOp.dynamic = dyn_energy;
					solution[best_index].power.readOp.leakage = 0;
				}
			}
		}
		else{
			best_perc_diff_from_dyn_energy_best_delay = 0;
			best_index = 0;
			for(i=0; i<=max_index; ++i){
				perc_diff_from_dyn_energy_best_delay = (double)((dyn_energy_best_delay - 
					solution[i].power.readOp.dynamic) * 100 / dyn_energy_best_delay);
				if(perc_diff_from_dyn_energy_best_delay >= best_perc_diff_from_dyn_energy_best_delay){
					best_perc_diff_from_dyn_energy_best_delay =	perc_diff_from_dyn_energy_best_delay;	
					best_index = i;
				}
			}
		}
		ptr_bnk_htree_sizing->buffer_opt_sizing = wcap * wopt / (minimum_width_nmos);
		ptr_bnk_htree_sizing->buffer_segment_opt_length = solution[best_index].lcap * lopt;
		ptr_bnk_htree_sizing->buffer_width_n[0] = wcap * wopt;
		ptr_bnk_htree_sizing->buffer_width_n[1] = internal_fanout * ptr_bnk_htree_sizing->buffer_width_n[0];
	}
	
	ptr_bnk_htree_sizing->buffer_width_p[0] = pmos_to_nmos_sizing_r * ptr_bnk_htree_sizing->buffer_width_n[0];
	ptr_bnk_htree_sizing->buffer_width_p[1] = pmos_to_nmos_sizing_r * ptr_bnk_htree_sizing->buffer_width_n[1];

	ptr_bnk_htree_sizing->nand2_buffer_width_n[1] = ptr_bnk_htree_sizing->buffer_width_n[1];
	ptr_bnk_htree_sizing->nand2_buffer_width_p[1] = ptr_bnk_htree_sizing->buffer_width_p[1];

	c_input_nand2 = gnand2 * gatecap(ptr_bnk_htree_sizing->buffer_width_n[1] +
		ptr_bnk_htree_sizing->buffer_width_n[1], 0) / internal_fanout;
	ptr_bnk_htree_sizing->nand2_buffer_width_n[0] = (2 / (2 + pmos_to_nmos_sizing_r)) * c_input_nand2 / gatecap(1, 0);
	ptr_bnk_htree_sizing->nand2_buffer_width_p[0] = (pmos_to_nmos_sizing_r / (2 + pmos_to_nmos_sizing_r)) * c_input_nand2 / gatecap(1, 0);

	c_input_nand2 = gnand2 * gatecap(ptr_bnk_htree_sizing->buffer_width_p[1], 0) / internal_fanout;
	ptr_bnk_htree_sizing->tristate_driver_nand2_width_n = (c_input_nand2 / 2) / gatecap(1, 0);
	ptr_bnk_htree_sizing->tristate_driver_nand2_width_p = ptr_bnk_htree_sizing->tristate_driver_nand2_width_n;
	c_input_nor2 = gnor2 * gatecap(ptr_bnk_htree_sizing->buffer_width_n[1], 0) / 3.0; //Internal fanout on NOR2 path
	//is assumed to be 3
	ptr_bnk_htree_sizing->tristate_driver_nor2_width_n = (1.0 / ( 1 + 2 * pmos_to_nmos_sizing_r)) * c_input_nor2 / gatecap(1, 0);
	ptr_bnk_htree_sizing->tristate_driver_nor2_width_p = (2 * pmos_to_nmos_sizing_r / (1 + 2 * pmos_to_nmos_sizing_r)) * c_input_nor2 / gatecap(1, 0);

}
   




void initialize_dataout_htree(
        dataout_htree_node *ptr_htree_node, 
        int number_htree_nodes,
        double *delay, powerDef *power,
        double *length_wire_htree_node)
{
    int i, j;
	double input_gate_cap, F, c_load, nand2_gate_cap;
	double pmos_to_nmos_sizing_r;

    *delay = 0;
    power->readOp.dynamic = 0;
    power->readOp.leakage = 0;
    power->writeOp.dynamic = 0;
    power->writeOp.leakage = 0;
	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();


    for(i = 0; i < MAX_NUMBER_HTREE_NODES; ++i){
		 ptr_htree_node[i].power.readOp.dynamic = 0;
		 ptr_htree_node[i].power.readOp.leakage = 0;
		 ptr_htree_node[i].power.writeOp.dynamic = 0;
		 ptr_htree_node[i].power.writeOp.leakage = 0;
        for(j = 0; j < MAX_NUMBER_GATES_STAGE; ++j){
            ptr_htree_node[i].width_n[j] = 0;
            ptr_htree_node[i].width_p[j] = 0;
        }
    }

	for(i = number_htree_nodes - 2; i >= 0; --i){
        ptr_htree_node[i].min_number_gates = 2;
        ptr_htree_node[i].r_wire_load = wire_outside_mat_r_per_micron * length_wire_htree_node[i];
        ptr_htree_node[i].c_wire_load = wire_outside_mat_c_per_micron * length_wire_htree_node[i];
		ptr_htree_node[i].f_wire = ptr_htree_node[i].r_wire_load * ptr_htree_node[i].c_wire_load / (2 * kinv);
    }

	for(i = 0; i < number_htree_nodes - 1; ++i){
		if(i == number_htree_nodes - 2 && i != 0){
			ptr_htree_node[i].width_n[0] = 2 * minimum_width_nmos;
			ptr_htree_node[i].c_gate_load =  gatecap(ptr_htree_node[i-1].width_n[0] +
					ptr_htree_node[i-1].width_p[0] + ptr_htree_node[i-1].width_nor2_n + ptr_htree_node[i-1].width_nor2_p , 0);
		}
		else{
			if(i == 0){
				ptr_htree_node[i].c_gate_load = gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0);
			}
			else{
				ptr_htree_node[i].c_gate_load =  gatecap(ptr_htree_node[i-1].width_n[0] +
					ptr_htree_node[i-1].width_p[0] + ptr_htree_node[i-1].width_nor2_n + ptr_htree_node[i-1].width_nor2_p , 0);
			}
			c_load = ptr_htree_node[i].c_gate_load + ptr_htree_node[i].c_wire_load;
			F = (ptr_htree_node[i+1].r_wire_load * gnand2 * gpmos * c_load / (2 * kinv * fopt)) *
				(1 + sqrt( 1 + 2 * fopt / ptr_htree_node[i+1].f_wire));
			if(F <= pow(fopt, 2)){
				//Assume a two-stage tristate driver
				F = pow(fopt, 2);
			}
			input_gate_cap = gnand2 * gpmos * c_load / F;
			ptr_htree_node[i].width_n[0] = (2 / (2 + pmos_to_nmos_sizing_r)) * input_gate_cap / gatecap(1, 0);
			if(ptr_htree_node[i].width_n[0] < 2 * minimum_width_nmos){
				ptr_htree_node[i].width_n[0] = 2 * minimum_width_nmos;
			}
			if(ptr_htree_node[i].width_n[0] > MAX_NMOS_WIDTH){
				//Two-stage buffer with 2nd stage composed of pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH. First stage NAND2 width
				//calculated as follows
				c_load = gatecap(pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH, 0);
				input_gate_cap = gnand2 * c_load / fopt;
				ptr_htree_node[i].width_n[0] = (2 / (2 + pmos_to_nmos_sizing_r)) * input_gate_cap / gatecap(1, 0);
			}
		}
		ptr_htree_node[i].width_p[0] = (pmos_to_nmos_sizing_r / 2) * ptr_htree_node[i].width_n[0];
		nand2_gate_cap = gatecap(ptr_htree_node[i].width_n[0] + ptr_htree_node[i].width_p[0], 0);
		input_gate_cap = gnor2 * gnmos * nand2_gate_cap / (gnand2 * gpmos);
		ptr_htree_node[i].width_nor2_n = (1 / (1 + 2 * pmos_to_nmos_sizing_r)) * input_gate_cap / gatecap(1, 0);
        if(ptr_htree_node[i].width_nor2_n < minimum_width_nmos){
            ptr_htree_node[i].width_nor2_n = minimum_width_nmos;
        }
        ptr_htree_node[i].width_nor2_p = 2 * pmos_to_nmos_sizing_r *  ptr_htree_node[i].width_nor2_n;
	}
}


void compute_widths_dataout_htree(dataout_htree_node *ptr_htree_node, int number_htree_nodes)
{

    int i, j;
    double G, c_load, H, f, B, F, c_input, pmos_to_nmos_sizing_r;

    B = 1;
    G = gnand2 * gpmos;
	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
    for(i = number_htree_nodes - 2; i >= 0; --i){
        c_load = ptr_htree_node[i].c_gate_load + ptr_htree_node[i].c_wire_load;
        H = c_load / gatecap(ptr_htree_node[i].width_n[0] + ptr_htree_node[i].width_p[0] , 0);
        F = G * B * H;
        ptr_htree_node[i].number_gates = (int) (log(F) / log(fopt));
        if(ptr_htree_node[i].number_gates%2 != 0){
            ++ptr_htree_node[i].number_gates;
        }
        if(ptr_htree_node[i].number_gates < ptr_htree_node[i].min_number_gates){
            ptr_htree_node[i].number_gates = ptr_htree_node[i].min_number_gates;
        }
        f = pow(F, 1.0 / ptr_htree_node[i].number_gates);
        j = ptr_htree_node[i].number_gates - 1;
        ptr_htree_node[i].width_p[j] = gpmos * c_load /(f * gatecap(1, 0));
        if(ptr_htree_node[i].width_p[j] < pmos_to_nmos_sizing_r * minimum_width_nmos){
            ptr_htree_node[i].width_p[j] = pmos_to_nmos_sizing_r * minimum_width_nmos;
        }
		ptr_htree_node[i].width_n[j] = ptr_htree_node[i].width_p[j] / pmos_to_nmos_sizing_r;

		if(ptr_htree_node[i].width_p[j] > pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH){
			c_load = gatecap(pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH + MAX_NMOS_WIDTH, 0);
			F =  gnand2 * c_load / gatecap(ptr_htree_node[i].width_n[0] +
				ptr_htree_node[i].width_p[0] , 0);
			ptr_htree_node[i].number_gates = (int) (log(F) / log(fopt)) + 1;
			if(ptr_htree_node[i].number_gates%2 != 0){
				++ptr_htree_node[i].number_gates;
			}
			if(ptr_htree_node[i].number_gates < ptr_htree_node[i].min_number_gates){
				ptr_htree_node[i].number_gates = ptr_htree_node[i].min_number_gates;
			}
			f = pow(F, 1.0 / ptr_htree_node[i].number_gates);
			j = ptr_htree_node[i].number_gates - 1;
			ptr_htree_node[i].width_p[j] = pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH;
			ptr_htree_node[i].width_n[j] = ptr_htree_node[i].width_p[j] / pmos_to_nmos_sizing_r;
		}
 
        for(j = ptr_htree_node[i].number_gates - 2; j >= 1; --j){
			if(j == ptr_htree_node[i].number_gates - 2){
				c_input = gatecap(ptr_htree_node[i].width_p[j+1], 0) / f;
			}
			else{
				c_input = gatecap(ptr_htree_node[i].width_n[j+1] + 
					ptr_htree_node[i].width_p[j+1], 0) / f;
			}
            ptr_htree_node[i].width_n[j] = (1.0 / 3.0) * (c_input / gatecap(1, 0));
            if(ptr_htree_node[i].width_n[j] < minimum_width_nmos){
                ptr_htree_node[i].width_n[j] = minimum_width_nmos;
            }
            ptr_htree_node[i].width_p[j]  = pmos_to_nmos_sizing_r * ptr_htree_node[i].width_n[j];
        }
    }
}

static void compute_widths_subarray_output_driver(
    dataout_htree_node *ptr_htree_node,
    int number_htree_nodes)
{
    int j;
    double G, H, F, f, c_load, c_input, B, nand2_gate_cap, pmos_to_nmos_sizing_r;
   
	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
    ptr_htree_node->min_number_gates = 2;
    ptr_htree_node->c_gate_load = gatecap(2 * minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos +
		minimum_width_nmos + 2 * pmos_to_nmos_sizing_r * minimum_width_nmos, 0);//Minimum-size NAND2 + Minimum-size NOR2
    ptr_htree_node->r_wire_load = wire_outside_mat_r_per_micron * height_subarray;
    ptr_htree_node->c_wire_load = wire_outside_mat_c_per_micron * height_subarray;
    ptr_htree_node->power.readOp.dynamic = 0;
    ptr_htree_node->power.readOp.leakage = 0;
    ptr_htree_node->power.writeOp.dynamic = 0;
    ptr_htree_node->power.writeOp.leakage = 0;
    c_load = ptr_htree_node->c_gate_load + ptr_htree_node->c_wire_load;

	ptr_htree_node->width_n[0] = 2 * minimum_width_nmos;
    ptr_htree_node->width_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
	nand2_gate_cap = gatecap(ptr_htree_node->width_n[0] + ptr_htree_node->width_p[0], 0);
	c_input = gnor2 * gnmos * nand2_gate_cap / (gnand2 * gpmos);
	ptr_htree_node->width_nor2_n = (1 /( 1 + 2 * pmos_to_nmos_sizing_r)) * c_input / gatecap(1, 0);
	if(ptr_htree_node->width_nor2_n < minimum_width_nmos){
		ptr_htree_node->width_nor2_n = minimum_width_nmos;
	}
	ptr_htree_node->width_nor2_p = 2 * pmos_to_nmos_sizing_r * ptr_htree_node->width_nor2_n;


	B = 1;
    G = gnand2 * gpmos;
	c_load = ptr_htree_node->c_gate_load + ptr_htree_node->c_wire_load;
	H = c_load / gatecap(ptr_htree_node->width_n[0] + ptr_htree_node->width_p[0] , 0);
	F = G * B * H;
	ptr_htree_node->number_gates = (int) (log(F) / log(fopt));
	if(ptr_htree_node->number_gates%2 != 0){
		++ptr_htree_node->number_gates;
	}
	if(ptr_htree_node->number_gates < ptr_htree_node->min_number_gates){
		ptr_htree_node->number_gates = ptr_htree_node->min_number_gates;
	}
	f = pow(F, 1.0 / ptr_htree_node->number_gates);
	j = ptr_htree_node->number_gates - 1;
	ptr_htree_node->width_p[j] = gpmos * c_load /(f * gatecap(1, 0));
	if(ptr_htree_node->width_p[j] < pmos_to_nmos_sizing_r * minimum_width_nmos){
		ptr_htree_node->width_p[j] = pmos_to_nmos_sizing_r * minimum_width_nmos;
	}
	ptr_htree_node->width_n[j] = ptr_htree_node->width_p[j] / pmos_to_nmos_sizing_r;

	if(ptr_htree_node->width_p[j] > pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH){
		c_load = gatecap(pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH + MAX_NMOS_WIDTH, 0);
		F =  gnand2 * c_load / gatecap(ptr_htree_node->width_n[0] +	ptr_htree_node->width_p[0], 0);
		ptr_htree_node->number_gates = (int) (log(F) / log(fopt)) + 1;
		if(ptr_htree_node->number_gates%2 != 0){
			++ptr_htree_node->number_gates;
		}
		if(ptr_htree_node->number_gates < ptr_htree_node->min_number_gates){
			ptr_htree_node->number_gates = ptr_htree_node->min_number_gates;
		}
		f = pow(F, 1.0 / ptr_htree_node->number_gates);
		j = ptr_htree_node->number_gates - 1;
		ptr_htree_node->width_p[j] = pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH;
		ptr_htree_node->width_n[j] = ptr_htree_node->width_p[j] / pmos_to_nmos_sizing_r;
	}

	for(j = ptr_htree_node->number_gates - 2; j >= 1; --j){
		if(j == ptr_htree_node->number_gates - 2){
			c_input = gatecap(ptr_htree_node->width_p[j+1], 0) / f;
		}
		else{
			c_input = gatecap(ptr_htree_node->width_n[j+1] + ptr_htree_node->width_p[j+1], 0) / f;
		}
		ptr_htree_node->width_n[j] = (1 /( 1 + pmos_to_nmos_sizing_r))  * c_input / gatecap(1, 0);
		if(ptr_htree_node->width_n[j] < minimum_width_nmos){
			ptr_htree_node->width_n[j] = minimum_width_nmos;
		}
		ptr_htree_node->width_p[j]  = pmos_to_nmos_sizing_r  * ptr_htree_node->width_n[j];
	}
}


void delay_addr_datain_htree(addr_datain_htree_node *ptr_htree_node, int number_htree_nodes, 
        double inrisetime, double *outrisetime, double *delay)
{
    int i, j;
    double rd, c_load, c_intrinsic, tf, this_delay;
    this_delay = 0;
    *delay = 0;
	for(i = 0; i < number_htree_nodes ; ++i){
        for(j = 0; j < ptr_htree_node[i].number_gates; ++j){
			if(j == 0){//NAND2 gate
                rd = transreson(ptr_htree_node[i].width_n[j], NCH, 2);
                c_load = gatecap(ptr_htree_node[i].width_n[j+1] + ptr_htree_node[i].width_p[j+1], 0.0);
                c_intrinsic = 2 * draincap(ptr_htree_node[i].width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                    draincap(ptr_htree_node[i].width_n[j], NCH, 2, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load);
            }
            else if(j == ptr_htree_node[i].number_gates - 1){
				rd = transreson(ptr_htree_node[i].width_n[j], NCH, 1);
				c_load = ptr_htree_node[i].c_gate_load + ptr_htree_node[i].c_wire_load;
				c_intrinsic = draincap(ptr_htree_node[i].width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
					draincap(ptr_htree_node[i].width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
				tf = rd * (c_intrinsic + c_load) + 
					ptr_htree_node[i].r_wire_load * (ptr_htree_node[i].c_wire_load / 2 +
					ptr_htree_node[i].c_gate_load);
			}
			else{//inverter
				rd = transreson(ptr_htree_node[i].width_n[j], NCH, 1);
				c_load = gatecap(ptr_htree_node[i].width_n[j+1] + ptr_htree_node[i].width_p[j+1], 0.0);
				c_intrinsic = draincap(ptr_htree_node[i].width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
					draincap(ptr_htree_node[i].width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
				tf = rd * ( c_intrinsic + c_load);
			}
			this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
            *delay += this_delay;
            inrisetime = this_delay/(1.0 - 0.5);
		}
	}
    *outrisetime = inrisetime;
}

void power_addr_datain_htree_node(addr_datain_htree_node *ptr_htree_node, powerDef *power)
{
    int j;
    double c_load, c_intrinsic;
    
    power->readOp.dynamic = 0;
    power->readOp.leakage = 0;
    power->writeOp.dynamic = 0;
    power->writeOp.leakage = 0;
    
    for(j = 0; j < ptr_htree_node->number_gates; ++j){
		if(j == 0){//NAND2 gate
			c_load = gatecap(ptr_htree_node->width_n[j+1] + ptr_htree_node->width_p[j+1], 0.0);
			c_intrinsic = 2 * draincap(ptr_htree_node->width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
				draincap(ptr_htree_node->width_n[j], NCH, 2, 1, DEFAULTHEIGHTCELL);
			power->readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
			power->readOp.leakage += cmos_ileakage(ptr_htree_node->width_n[j], 
                        ptr_htree_node->width_p[j], temper) * 0.5 * vdd_periph_global;
		}
		else if(j == ptr_htree_node->number_gates - 1){
			c_load = ptr_htree_node->c_gate_load + ptr_htree_node->c_wire_load;
			c_intrinsic = draincap(ptr_htree_node->width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
				draincap(ptr_htree_node->width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
			power->readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
			power->readOp.leakage += cmos_ileakage(ptr_htree_node->width_n[j], 
				ptr_htree_node->width_p[j], temper) * 0.5 * vdd_periph_global;
		}
		else{//inverter
			c_load = gatecap(ptr_htree_node->width_n[j+1] + ptr_htree_node->width_p[j+1], 0.0);
			c_intrinsic = draincap(ptr_htree_node->width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
				draincap(ptr_htree_node->width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
			power->readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
			power->readOp.leakage += cmos_ileakage(ptr_htree_node->width_n[j], 
				ptr_htree_node->width_p[j], temper) * 0.5 * vdd_periph_global;
		}
	}
}

void delay_array_edge_to_bank_edge_htree(array_edge_to_bank_edge_htree_sizing *ptr_arr_edge_to_bank_edge_sizing, double length, double horizontal_htree_input_load, 
										 double *delay, double inrisetime, 
										  double *outrisetime, powerDef *power)
{
	double rd, c_intrinsic, c_gate_load, c_wire_load, r_wire, tf, this_delay;
	powerDef power_repeater;
	int opt_number_repeaters;

	*delay = 0;
	power->readOp.dynamic = 0;
	power->readOp.leakage = 0;
	power->writeOp.dynamic = 0;
	power->writeOp.leakage = 0;

	if(length > 0){		
		opt_number_repeaters = (int) (ceil(length /  ptr_arr_edge_to_bank_edge_sizing->opt_segment_length));
		//Calculate delay of first inverter driving second inverter (repeater stage)
		rd = transreson(ptr_arr_edge_to_bank_edge_sizing->width_inverter_nmos, NCH, 1);
		c_intrinsic = draincap(ptr_arr_edge_to_bank_edge_sizing->width_inverter_pmos, PCH, 1, 1, DEFAULTHEIGHTCELL) + 
			draincap(ptr_arr_edge_to_bank_edge_sizing->width_inverter_nmos, NCH, 1, 1, DEFAULTHEIGHTCELL);
		c_gate_load = gatecap(ptr_arr_edge_to_bank_edge_sizing->width_inverter_nmos + ptr_arr_edge_to_bank_edge_sizing->width_inverter_pmos, 0.0);
		c_wire_load = ptr_arr_edge_to_bank_edge_sizing->opt_segment_length * wire_outside_mat_c_per_micron;
		r_wire = ptr_arr_edge_to_bank_edge_sizing->opt_segment_length * wire_outside_mat_r_per_micron;
		tf = rd * (c_intrinsic + c_wire_load + c_gate_load) + r_wire * (c_wire_load / 2 + c_gate_load);
		this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
		power_repeater.readOp.dynamic = (c_intrinsic + c_wire_load + c_gate_load) * 
			vdd_periph_global * vdd_periph_global * 0.5;
		power_repeater.readOp.leakage  = cmos_ileakage(ptr_arr_edge_to_bank_edge_sizing->width_inverter_nmos, ptr_arr_edge_to_bank_edge_sizing->width_inverter_pmos, temper) * 
			0.5 * vdd_periph_global;
		if(opt_number_repeaters > 1){
			*delay += this_delay;
			inrisetime = this_delay/(1.0 - 0.5);
			power->readOp.dynamic += power_repeater.readOp.dynamic;
			power->readOp.leakage += power_repeater.readOp.leakage;
		}
		
		//Calculate delay through all except last but one inverter
		if(opt_number_repeaters > 2){
			this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
			*delay += (opt_number_repeaters - 2) * this_delay;
			power->readOp.dynamic += power_repeater.readOp.dynamic * (opt_number_repeaters - 2);
			power->readOp.leakage += power_repeater.readOp.leakage * (opt_number_repeaters - 2);
		}

		//Calculate delay of last inverter driving input of Horizontal H-tree within bank
		c_gate_load = horizontal_htree_input_load;
		tf = rd * (c_intrinsic + c_wire_load + c_gate_load) + r_wire * (c_wire_load / 2 + c_gate_load);
		this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
		*delay += this_delay;
		*outrisetime = this_delay/(1.0 - 0.5);
		power->readOp.dynamic += (c_intrinsic + c_wire_load + c_gate_load) * 
			vdd_periph_global * vdd_periph_global * 0.5;
		power->readOp.leakage  += cmos_ileakage(ptr_arr_edge_to_bank_edge_sizing->width_inverter_nmos, ptr_arr_edge_to_bank_edge_sizing->width_inverter_pmos, temper) * 
			0.5 * vdd_periph_global;
		power->writeOp.dynamic = power->readOp.dynamic;
	}
}




void delay_addr_datain_htree_with_repeaters(bank_htree_sizing *ptr_bnk_htree_sizing, 
											addr_datain_htree_at_mat_interval *ptr_htree_at_mat_interval, 
											double c_output_load,
											int number_htree_nodes,
											int broadcast,
											double *delay,
											double inrisetime,
											double *outrisetime)
{
	int j, number_buffers;
	double c_gate_load, c_wire_load, c_intrinsic, rd, tf, this_delay,
		buffer_out_resistance, length, buffer_segment_length, r_wire,
		time_constant_internal_nand2_buffer, time_constant_buffer_driving_nand2_buffer, 
		time_constant_nand2_buffer_driving_buffer, time_constant_nand2_buffer_driving_nand2_buffer, 
		time_constant_nand2_buffer_driving_final_seg, delay_internal_buffer, delay_internal_nand2_buffer, pmos_to_nmos_sizing_r;

	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
	//Calculate delay of buffer
	j = 0;
	rd = transreson(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1);
	c_gate_load = gatecap(ptr_bnk_htree_sizing->buffer_width_n[j+1] + ptr_bnk_htree_sizing->buffer_width_p[j+1], 0.0);
	c_intrinsic = draincap(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
	ptr_htree_at_mat_interval->time_constant_internal_buffer = rd * (c_intrinsic + c_gate_load);
		ptr_htree_at_mat_interval->power_buffer.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->buffer_width_n[j], ptr_bnk_htree_sizing->buffer_width_p[j], temper) * 
		0.5 * vdd_periph_global;
	j = 1;
	buffer_out_resistance = transreson(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1);
	c_gate_load = gatecap(ptr_bnk_htree_sizing->buffer_width_n[j-1] + 
		ptr_bnk_htree_sizing->buffer_width_p[j-1], 0.0);
	c_intrinsic = draincap(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
	ptr_htree_at_mat_interval->time_constant_buffer_driving_buffer = buffer_out_resistance * (c_intrinsic + c_gate_load);
	ptr_htree_at_mat_interval->power_buffer.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->buffer_width_n[j], ptr_bnk_htree_sizing->buffer_width_p[j], temper) * 
		0.5 * vdd_periph_global;


	//Calculate delay of NAND2 buffer driving buffer and delay of NAND2 buffer driving final segment
	//of H-tree
	j = 0;
	rd = transreson(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], NCH, 2);
	c_gate_load = gatecap(ptr_bnk_htree_sizing->nand2_buffer_width_n[j+1] + 
		ptr_bnk_htree_sizing->nand2_buffer_width_p[j+1], 0.0);
	c_intrinsic = 2 * draincap(ptr_bnk_htree_sizing->nand2_buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], NCH, 2, 1, DEFAULTHEIGHTCELL);
	time_constant_internal_nand2_buffer = rd * (c_intrinsic + c_gate_load);
	ptr_htree_at_mat_interval->power_nand2_buffer_driving_buffer.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_nand2_buffer_driving_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], ptr_bnk_htree_sizing->nand2_buffer_width_p[j], temper) * 
		0.5 * vdd_periph_global;
	j = 1;
	rd = transreson(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], NCH, 1);
	c_gate_load = gatecap(ptr_bnk_htree_sizing->buffer_width_n[0] + ptr_bnk_htree_sizing->buffer_width_p[0], 0.0);
	c_intrinsic = draincap(ptr_bnk_htree_sizing->nand2_buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
	time_constant_nand2_buffer_driving_buffer = rd * (c_intrinsic + c_gate_load);
	c_gate_load = gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0);
	time_constant_nand2_buffer_driving_final_seg = rd * (c_intrinsic + c_gate_load);
	ptr_htree_at_mat_interval->power_nand2_buffer_driving_buffer.readOp.dynamic += (c_intrinsic + 
		c_gate_load) * vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_nand2_buffer_driving_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], 
		ptr_bnk_htree_sizing->nand2_buffer_width_p[j], temper) * 0.5 * vdd_periph_global;


	//Calculate delay of buffer driving NAND2 buffer and delay of buffer driving final segment of H-tree
	j = 0;
	c_gate_load = gatecap(ptr_bnk_htree_sizing->buffer_width_n[j+1] + 
		ptr_bnk_htree_sizing->buffer_width_p[j+1], 0.0);
	c_intrinsic = draincap(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
	ptr_htree_at_mat_interval->power_buffer_driving_nand2_buffer.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_buffer_driving_nand2_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], ptr_bnk_htree_sizing->nand2_buffer_width_p[j], temper) * 
		0.5 * vdd_periph_global;
	j = 1;
	rd = transreson(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1);
	c_gate_load = 2 * gatecap(ptr_bnk_htree_sizing->nand2_buffer_width_n[0] + 
		ptr_bnk_htree_sizing->nand2_buffer_width_p[0], 0.0);
	c_intrinsic = draincap(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
	time_constant_buffer_driving_nand2_buffer = rd * (c_intrinsic + c_gate_load);
	ptr_htree_at_mat_interval->power_buffer_driving_nand2_buffer.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_buffer_driving_nand2_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], ptr_bnk_htree_sizing->nand2_buffer_width_p[j], temper) * 
		0.5 * vdd_periph_global;
	c_gate_load = gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0);
	ptr_htree_at_mat_interval->time_constant_buffer_driving_final_seg = rd * (c_intrinsic + c_gate_load);
	ptr_htree_at_mat_interval->power_buffer_driving_final_seg.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_buffer_driving_final_seg.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], ptr_bnk_htree_sizing->nand2_buffer_width_p[j], temper) * 
		0.5 * vdd_periph_global;

	//Calculate delay of NAND2 buffer driving NAND2 buffer
	j = 0;
	c_gate_load = gatecap(ptr_bnk_htree_sizing->nand2_buffer_width_n[j+1] + 
		ptr_bnk_htree_sizing->nand2_buffer_width_p[j+1], 0.0);
	c_intrinsic = 2 * draincap(ptr_bnk_htree_sizing->nand2_buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], NCH, 2, 1, DEFAULTHEIGHTCELL);
	ptr_htree_at_mat_interval->power_nand2_buffer_driving_nand2_buffer.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_nand2_buffer_driving_nand2_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], ptr_bnk_htree_sizing->nand2_buffer_width_p[j], temper) * 
		0.5 * vdd_periph_global;
	j = 1;
	rd = transreson(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1);
	c_gate_load = 2 * gatecap(ptr_bnk_htree_sizing->nand2_buffer_width_n[0] + 
		ptr_bnk_htree_sizing->nand2_buffer_width_p[0], 0.0);
	c_intrinsic = draincap(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
	time_constant_nand2_buffer_driving_nand2_buffer = rd * (c_intrinsic + c_gate_load);
	ptr_htree_at_mat_interval->power_nand2_buffer_driving_nand2_buffer.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_nand2_buffer_driving_nand2_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->nand2_buffer_width_n[j], ptr_bnk_htree_sizing->nand2_buffer_width_p[j], temper) * 
		0.5 * vdd_periph_global;
	
    *delay = 0;
	length = pow(2, number_htree_nodes - 1) * ptr_htree_at_mat_interval->mat_dimension / 2;
	for(j = 0; j < number_htree_nodes; ++j){
		if(length < 2 * BUFFER_SEPARATION_LENGTH_MULTIPLIER * ptr_bnk_htree_sizing->buffer_segment_opt_length){
			c_wire_load = length * wire_outside_mat_c_per_micron;
			r_wire = length * wire_outside_mat_r_per_micron;
			delay_internal_nand2_buffer = horowitz(inrisetime, time_constant_internal_nand2_buffer, 0.5
					, 0.5, RISE);
			inrisetime = delay_internal_nand2_buffer / (1.0 - 0.5);
			if(j == number_htree_nodes - 1){//NAND2 buffer is driving input of gate in mat
				c_gate_load = gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0);
				tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
					c_gate_load) + time_constant_nand2_buffer_driving_final_seg;
			}
			else{//NAND2 buffer is driving NAND2 buffer
				c_gate_load = gatecap(ptr_bnk_htree_sizing->nand2_buffer_width_n[0] + 
					ptr_bnk_htree_sizing->nand2_buffer_width_p[0], 0.0);
				tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
					c_gate_load) + time_constant_nand2_buffer_driving_nand2_buffer;
			}
			this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
			*delay += delay_internal_nand2_buffer + this_delay;
			if((delay_internal_nand2_buffer + this_delay) > 
				ptr_htree_at_mat_interval->max_delay_between_buffers){
					ptr_htree_at_mat_interval->max_delay_between_buffers = delay_internal_nand2_buffer + this_delay;
			}
			inrisetime = this_delay / (1.0 - 0.5);
		}
		else{
			number_buffers = (int)(floor(length / (BUFFER_SEPARATION_LENGTH_MULTIPLIER * ptr_bnk_htree_sizing->buffer_segment_opt_length)));
			buffer_segment_length = length / number_buffers;
			number_buffers -= 1;
			c_wire_load = buffer_segment_length * wire_outside_mat_c_per_micron;
			r_wire = buffer_segment_length * wire_outside_mat_r_per_micron;
			//Calculate delay of NAND2 buffer driving buffer
			delay_internal_nand2_buffer = horowitz(inrisetime, time_constant_internal_nand2_buffer, 0.5,
				0.5, RISE);
			inrisetime = delay_internal_nand2_buffer / (1.0 - 0.5);
			c_gate_load = gatecap(ptr_bnk_htree_sizing->buffer_width_n[0] + 
					ptr_bnk_htree_sizing->buffer_width_p[0], 0.0);
			tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
				c_gate_load) + time_constant_nand2_buffer_driving_buffer;
			this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
			*delay += delay_internal_nand2_buffer + this_delay;
			if((delay_internal_nand2_buffer + this_delay) > 
				ptr_htree_at_mat_interval->max_delay_between_buffers){
					ptr_htree_at_mat_interval->max_delay_between_buffers = delay_internal_nand2_buffer + this_delay;
			}
			inrisetime = this_delay / (1.0 - 0.5);

			//Calculate delay through all but the last buffer
			delay_internal_buffer = horowitz(inrisetime, ptr_htree_at_mat_interval->time_constant_internal_buffer, 0.5, 0.5, RISE);
			inrisetime = delay_internal_buffer / (1.0 - 0.5);
			tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
				c_gate_load) + ptr_htree_at_mat_interval->time_constant_buffer_driving_buffer;
			this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
			*delay += (number_buffers - 1) * (delay_internal_buffer + this_delay);
			inrisetime = this_delay / (1.0 - 0.5);

			//Calculate delay through the last buffer
			delay_internal_buffer = horowitz(inrisetime, ptr_htree_at_mat_interval->time_constant_internal_buffer, 0.5, 0.5, RISE);
			inrisetime = delay_internal_buffer / (1.0 - 0.5);
			if(j == number_htree_nodes - 1){
				c_gate_load = gatecap(c_output_load, 0);
				tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
					c_gate_load) + ptr_htree_at_mat_interval->time_constant_buffer_driving_final_seg;
				this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
			}
			else{
				c_gate_load = 2 * gatecap(ptr_bnk_htree_sizing->nand2_buffer_width_n[0] + 
					ptr_bnk_htree_sizing->nand2_buffer_width_p[0], 0.0);	
				tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
					c_gate_load) + time_constant_buffer_driving_nand2_buffer;
				this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
			}
			*delay += (this_delay + delay_internal_buffer);
			if((delay_internal_buffer + this_delay) > 
				ptr_htree_at_mat_interval->max_delay_between_buffers){
					ptr_htree_at_mat_interval->max_delay_between_buffers = delay_internal_buffer + this_delay;
			}
			inrisetime = this_delay / (1.0 - 0.5);
		}
		length /= 2;
	}
	*outrisetime = inrisetime;
}

	
void power_addr_datain_htree_node_at_mat_interval(bank_htree_sizing *ptr_bnk_htree_sizing, addr_datain_htree_at_mat_interval *ptr_htree_at_mat_interval, 
													  double length_htree_segment, int number_htree_nodes,
													  int htree_node_number, powerDef *power)
{
	int number_buffers;
	double buffer_segment_length, c_wire_load;
    reset_powerDef(power);
	if(length_htree_segment < 2 * BUFFER_SEPARATION_LENGTH_MULTIPLIER * ptr_bnk_htree_sizing->buffer_segment_opt_length){
		c_wire_load = length_htree_segment * wire_outside_mat_c_per_micron;
		power->readOp.dynamic += c_wire_load * vdd_periph_global * vdd_periph_global * 0.5;
		if(htree_node_number == number_htree_nodes - 1){
			power->readOp.dynamic += ptr_htree_at_mat_interval->power_nand2_buffer_driving_final_seg.readOp.dynamic;
			power->readOp.leakage += ptr_htree_at_mat_interval->power_nand2_buffer_driving_final_seg.readOp.leakage;
		}
		else{
			power->readOp.dynamic += ptr_htree_at_mat_interval->power_nand2_buffer_driving_nand2_buffer.readOp.dynamic;
			power->readOp.leakage += ptr_htree_at_mat_interval->power_nand2_buffer_driving_nand2_buffer.readOp.leakage;
		}
	}
	else{
		number_buffers = (int)(floor(length_htree_segment / (BUFFER_SEPARATION_LENGTH_MULTIPLIER * ptr_bnk_htree_sizing->buffer_segment_opt_length)));
		buffer_segment_length = length_htree_segment / number_buffers;
		number_buffers -= 1;
		c_wire_load = buffer_segment_length * wire_outside_mat_c_per_micron;
		power->readOp.dynamic += c_wire_load * vdd_periph_global * vdd_periph_global * 0.5;
		power->readOp.dynamic += ptr_htree_at_mat_interval->power_nand2_buffer_driving_buffer.readOp.dynamic;
		power->readOp.leakage += ptr_htree_at_mat_interval->power_nand2_buffer_driving_buffer.readOp.leakage;
		power->readOp.dynamic += (number_buffers - 1) * c_wire_load * vdd_periph_global * vdd_periph_global * 0.5;
		power->readOp.dynamic += (number_buffers - 1) * ptr_htree_at_mat_interval->power_buffer.readOp.dynamic;
		power->readOp.leakage += (number_buffers - 1) * ptr_htree_at_mat_interval->power_buffer.readOp.leakage;
		power->readOp.dynamic += c_wire_load * vdd_periph_global * vdd_periph_global * 0.5;
		if(htree_node_number == number_htree_nodes - 1){
			power->readOp.dynamic += ptr_htree_at_mat_interval->power_buffer_driving_final_seg.readOp.dynamic;
			power->readOp.leakage += ptr_htree_at_mat_interval->power_buffer_driving_final_seg.readOp.leakage;
		}
		else{
			power->readOp.dynamic += ptr_htree_at_mat_interval->power_buffer_driving_nand2_buffer.readOp.dynamic;
			power->readOp.leakage += ptr_htree_at_mat_interval->power_buffer_driving_nand2_buffer.readOp.leakage;
		}
	}
}


void power_dataout_htree_node_at_mat_interval(bank_htree_sizing *ptr_bnk_htree_sizing, addr_datain_htree_at_mat_interval *ptr_htree_at_mat_interval,
											  double length_htree_segment, int htree_node_number, 
											  powerDef *power)
{
	int number_buffers;
	double c_wire_load, buffer_segment_length;

	reset_powerDef(power);
	if(length_htree_segment < 2 * BUFFER_SEPARATION_LENGTH_MULTIPLIER * ptr_bnk_htree_sizing->buffer_segment_opt_length){
		c_wire_load = length_htree_segment * wire_outside_mat_c_per_micron;
		power->readOp.dynamic += c_wire_load * vdd_periph_global * vdd_periph_global * 0.5;
		if(htree_node_number == 0){
			power->readOp.dynamic += ptr_htree_at_mat_interval->power_tristate_driver_driving_final_seg.readOp.dynamic;
			power->readOp.leakage += ptr_htree_at_mat_interval->power_tristate_driver_driving_final_seg.readOp.leakage;
		}
		else{
			power->readOp.dynamic += ptr_htree_at_mat_interval->power_tristate_driver_driving_tristate_driver.readOp.dynamic;
			power->readOp.leakage += ptr_htree_at_mat_interval->power_tristate_driver_driving_tristate_driver.readOp.leakage;
		}
	}
	else{
		number_buffers = (int)(floor(length_htree_segment / (BUFFER_SEPARATION_LENGTH_MULTIPLIER * ptr_bnk_htree_sizing->buffer_segment_opt_length)));
		buffer_segment_length = length_htree_segment / number_buffers;
		number_buffers -= 1;
		c_wire_load = buffer_segment_length * wire_outside_mat_c_per_micron;
		power->readOp.dynamic += c_wire_load * vdd_periph_global * vdd_periph_global * 0.5;
		power->readOp.dynamic += ptr_htree_at_mat_interval->power_tristate_driver_driving_buffer.readOp.dynamic;
		power->readOp.leakage += ptr_htree_at_mat_interval->power_tristate_driver_driving_buffer.readOp.leakage;
		power->readOp.dynamic += (number_buffers - 1) * c_wire_load * vdd_periph_global * vdd_periph_global * 0.5;
		power->readOp.dynamic += (number_buffers - 1) * ptr_htree_at_mat_interval->power_buffer.readOp.dynamic;
		power->readOp.leakage += (number_buffers - 1) * ptr_htree_at_mat_interval->power_buffer.readOp.leakage;
		power->readOp.dynamic += c_wire_load * vdd_periph_global * vdd_periph_global * 0.5;
		if(htree_node_number == 0){
			power->readOp.dynamic += ptr_htree_at_mat_interval->power_tristate_driver_driving_final_seg.readOp.dynamic;
			power->readOp.leakage += ptr_htree_at_mat_interval->power_tristate_driver_driving_final_seg.readOp.leakage;
		}
		else{
			power->readOp.dynamic += ptr_htree_at_mat_interval->power_tristate_driver_driving_tristate_driver.readOp.dynamic;
			power->readOp.leakage += ptr_htree_at_mat_interval->power_tristate_driver_driving_tristate_driver.readOp.leakage;
		}
	}
}

void delay_dataout_vertical_htree(dataout_htree_node *ptr_htree_node, int number_htree_nodes, 
        double inrisetime, double *outrisetime, double *delay, powerDef *power)
{
    int i, j, htree_node_multiplier;
    double c_load, rd, tf, this_delay, c_intrinsic;
    this_delay = 0;
    *delay = 0;
    *outrisetime = 0;
	reset_powerDef(power);
   
	for(i = number_htree_nodes - 2; i >= 0; --i){
        for(j = 0; j < ptr_htree_node[i].number_gates; ++j){
            if(j == 0){//NAND2 gate
                rd = transreson(ptr_htree_node[i].width_n[j], NCH, 2);
				if(ptr_htree_node[i].number_gates == 2){
					c_load = gatecap(ptr_htree_node[i].width_p[j+1], 0.0);//NAND2 driving PMOS output stage
				}
				else{
					c_load = gatecap(ptr_htree_node[i].width_p[j+1], 0.0);//NAND2 driving inverter
				}
                c_intrinsic = draincap(ptr_htree_node[i].width_n[j], NCH, 2, 1, DEFAULTHEIGHTCELL) + 
                    2 * draincap(ptr_htree_node[i].width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load);
                power->readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
            }
            else if(j == ptr_htree_node[i].number_gates - 1){//PMOS 
				rd = transreson(ptr_htree_node[i].width_p[j], PCH, 1);
				c_load = ptr_htree_node[i].c_wire_load + ptr_htree_node[i].c_gate_load;
				c_intrinsic = draincap(ptr_htree_node[i].width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
					draincap(ptr_htree_node[i].width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
				tf = rd * (c_intrinsic + c_load) + ptr_htree_node[i].r_wire_load * 
					(ptr_htree_node[i].c_wire_load / 2 + ptr_htree_node[i].c_gate_load +
					draincap(ptr_htree_node[i].width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL) + 
					draincap(ptr_htree_node[i].width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL));
				power->readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
			}
			else{//inverter
				rd = transreson(ptr_htree_node[i].width_n[j], NCH, 1);
				if(j == ptr_htree_node[i].number_gates - 2){//inverter driving PMOS of output stage
					c_load = gatecap(ptr_htree_node[i].width_p[j+1], 0.0);
				}
				else{//inverter driving inverter
					c_load = gatecap(ptr_htree_node[i].width_n[j+1] + ptr_htree_node[i].width_p[j+1], 0.0);
				}				
				c_intrinsic = draincap(ptr_htree_node[i].width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) +
					draincap(ptr_htree_node[i].width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
				tf = rd * (c_intrinsic + c_load);
				power->readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
			}

			this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
            *delay += this_delay;
            inrisetime = this_delay/(1.0 - 0.5);
        }
    }
    *outrisetime = inrisetime;

    htree_node_multiplier = 1;
    for(i = 0; i < number_htree_nodes - 1; ++i){
        for(j = 0; j < ptr_htree_node[i].number_gates; ++j){
            if(j == 0){//NAND gate, NOR gate
                power->readOp.leakage += cmos_ileakage(ptr_htree_node[i].width_n[j], 
                        ptr_htree_node[i].width_p[j], temper) * 0.5 * vdd_periph_global * 
						htree_node_multiplier;
				power->readOp.leakage += cmos_ileakage(ptr_htree_node[i].width_nor2_n, 
					ptr_htree_node[i].width_nor2_p, temper) * 0.5 * vdd_periph_global * htree_node_multiplier;
            }
            else if(j == ptr_htree_node[i].number_gates - 1){//PMOS and NMOS output stage
				power->readOp.leakage += cmos_ileakage(ptr_htree_node[i].width_n[j], 
					ptr_htree_node[i].width_p[j], temper) * 0.5 * vdd_periph_global * htree_node_multiplier;
			}
			else{//inverters in NAND2 and NOR2 paths. Assume that inverters in the NOR2 path 
				//half the width of corresp inverters in NAND2 path (because inverters in NOR2 path
				//drive NMOS of output stage compared to inverters in NAND2 path that drive PMOS of 
				//output stage)
				power->readOp.leakage += cmos_ileakage(ptr_htree_node[i].width_n[j] + ptr_htree_node[i].width_n[j] / 2,
					ptr_htree_node[i].width_p[j] + ptr_htree_node[i].width_p[j] / 2, temper) * 
					0.5 * vdd_periph_global * htree_node_multiplier;
			}
			htree_node_multiplier *= 2;
		}
	}
}

void delay_datout_vertical_htree_with_repeaters(bank_htree_sizing *ptr_bnk_htree_sizing,
												addr_datain_htree_at_mat_interval *ptr_htree_at_mat_interval, 
													   int number_htree_nodes, 
													   double *delay,
													   double inrisetime,
													   double *outrisetime)
{
	int j, i, number_buffers;
    double rd, c_gate_load, c_intrinsic, c_wire_load, tf, this_delay, 
		r_wire, buffer_out_resistance, length, buffer_segment_length,
		time_constant_internal_tristate_driver, time_constant_tristate_driver_driving_tristate_driver, 
		time_constant_tristate_driver_driving_buffer, time_constant_buffer_driving_tristate_driver, 
		time_constant_tristate_driver_driving_final_seg, delay_internal_tristate_driver, delay_internal_buffer, pmos_to_nmos_sizing_r;
 
	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
	//Calculate delay of tristate driver driving buffer and delay of tristate driver driving final segment
	j = 0;
	rd = transreson(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n, NCH, 2);
	c_gate_load = gatecap(ptr_bnk_htree_sizing->buffer_width_p[j+1], 0.0);
	c_intrinsic = 2 * draincap(ptr_bnk_htree_sizing->tristate_driver_nand2_width_p, PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n, NCH, 2, 1, DEFAULTHEIGHTCELL);
	time_constant_internal_tristate_driver = rd * (c_intrinsic + c_gate_load);
	ptr_htree_at_mat_interval->power_tristate_driver_driving_buffer.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_tristate_driver_driving_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n, ptr_bnk_htree_sizing->tristate_driver_nand2_width_p, temper) * 
		0.5 * vdd_periph_global;
	ptr_htree_at_mat_interval->power_tristate_driver_driving_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->tristate_driver_nor2_width_n, ptr_bnk_htree_sizing->tristate_driver_nor2_width_p, temper) * 
		0.5 * vdd_periph_global;
	j = 1;
	buffer_out_resistance = transreson(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1);
	c_gate_load =  gatecap(ptr_bnk_htree_sizing->buffer_width_n[0] + 
		ptr_bnk_htree_sizing->buffer_width_p[0], 0.0);
	c_intrinsic = draincap(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
	time_constant_tristate_driver_driving_buffer = rd * (c_intrinsic + c_gate_load);
	c_gate_load =  gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0.0);
	time_constant_tristate_driver_driving_final_seg = rd * (c_intrinsic + c_gate_load);
	ptr_htree_at_mat_interval->power_tristate_driver_driving_buffer.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_tristate_driver_driving_buffer.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->buffer_width_n[1], ptr_bnk_htree_sizing->buffer_width_p[1], temper) * 
		0.5 * vdd_periph_global;

	//Calculate delay of tristate driver driving tristate driver
	j = 0;
	rd = transreson(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n, NCH, 2);
	c_gate_load = gatecap(ptr_bnk_htree_sizing->buffer_width_p[j+1], 0.0);
	c_intrinsic = 2 * draincap(ptr_bnk_htree_sizing->tristate_driver_nand2_width_p, PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n, NCH, 2, 1, DEFAULTHEIGHTCELL);
	ptr_htree_at_mat_interval->power_tristate_driver_driving_tristate_driver.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_tristate_driver_driving_tristate_driver.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n, ptr_bnk_htree_sizing->tristate_driver_nand2_width_p, temper) * 
		0.5 * vdd_periph_global;
	ptr_htree_at_mat_interval->power_tristate_driver_driving_tristate_driver.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->tristate_driver_nor2_width_n, ptr_bnk_htree_sizing->tristate_driver_nor2_width_p, temper) * 
		0.5 * vdd_periph_global;
	j = 1;
	rd = transreson(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1);
	c_gate_load =  gatecap(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n + 
		ptr_bnk_htree_sizing->tristate_driver_nand2_width_p +
		ptr_bnk_htree_sizing->tristate_driver_nor2_width_n + 
		ptr_bnk_htree_sizing->tristate_driver_nor2_width_p, 0.0) +
		draincap(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
	c_intrinsic = draincap(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
	time_constant_tristate_driver_driving_tristate_driver = rd * (c_intrinsic + c_gate_load);
	ptr_htree_at_mat_interval->power_tristate_driver_driving_tristate_driver.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_tristate_driver_driving_tristate_driver.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->buffer_width_n[1], ptr_bnk_htree_sizing->buffer_width_p[1], temper) * 
		0.5 * vdd_periph_global;
	

	//Calculate delay of buffer driving tristate driver
	j = 0;
	rd = transreson(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1);
	c_gate_load = gatecap(ptr_bnk_htree_sizing->buffer_width_n[j+1] + 
		ptr_bnk_htree_sizing->buffer_width_p[j+1], 0.0);
	c_intrinsic = draincap(ptr_bnk_htree_sizing->tristate_driver_nand2_width_p, PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n, NCH, 1, 1, DEFAULTHEIGHTCELL);
	ptr_htree_at_mat_interval->power_buffer_driving_tristate_driver.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_buffer_driving_tristate_driver.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->buffer_width_n[j], ptr_bnk_htree_sizing->buffer_width_p[j], temper) * 
		0.5 * vdd_periph_global;
	j = 1;
	rd = transreson(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1);
	c_gate_load =  gatecap(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n + 
		ptr_bnk_htree_sizing->tristate_driver_nand2_width_p +
		ptr_bnk_htree_sizing->tristate_driver_nor2_width_n + 
		ptr_bnk_htree_sizing->tristate_driver_nor2_width_p, 0.0);
	c_intrinsic = draincap(ptr_bnk_htree_sizing->buffer_width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
		draincap(ptr_bnk_htree_sizing->buffer_width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
	time_constant_buffer_driving_tristate_driver = rd * (c_intrinsic + c_gate_load);
	ptr_htree_at_mat_interval->power_buffer_driving_tristate_driver.readOp.dynamic += (c_intrinsic + c_gate_load) * 
		vdd_periph_global * vdd_periph_global * 0.5;
	ptr_htree_at_mat_interval->power_buffer_driving_tristate_driver.readOp.leakage += 
		cmos_ileakage(ptr_bnk_htree_sizing->buffer_width_n[j], ptr_bnk_htree_sizing->buffer_width_p[j], temper) * 
		0.5 * vdd_periph_global;

    *delay = 0;
	length = ptr_htree_at_mat_interval->mat_dimension;
	for(i = number_htree_nodes - 2; i >= 0; --i){
		if(length < 2 * BUFFER_SEPARATION_LENGTH_MULTIPLIER * ptr_bnk_htree_sizing->buffer_segment_opt_length){
			c_wire_load = length * wire_outside_mat_c_per_micron;
			r_wire = length * wire_outside_mat_r_per_micron;
			delay_internal_tristate_driver = horowitz(inrisetime, time_constant_internal_tristate_driver, 0.5,
				0.5, RISE);
			inrisetime = delay_internal_tristate_driver / (1.0 - 0.5);
			if(i == 0){
				c_gate_load = gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0);
				tf = buffer_out_resistance * (c_wire_load + c_gate_load) + r_wire * (c_wire_load / 2 + 
					c_gate_load) + time_constant_tristate_driver_driving_final_seg;
			}
			else{
				c_gate_load =  gatecap(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n + 
					ptr_bnk_htree_sizing->tristate_driver_nand2_width_p +
					ptr_bnk_htree_sizing->tristate_driver_nor2_width_n + 
					ptr_bnk_htree_sizing->tristate_driver_nor2_width_p, 0.0);
				tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
					c_gate_load) + time_constant_tristate_driver_driving_tristate_driver;
			}
			this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
			*delay += (this_delay + delay_internal_tristate_driver);
			if((delay_internal_tristate_driver + this_delay) > 
				ptr_htree_at_mat_interval->max_delay_between_buffers){
					ptr_htree_at_mat_interval->max_delay_between_buffers = delay_internal_tristate_driver + this_delay;
			}
			inrisetime = this_delay / (1.0 - 0.5);
		}
		else{
			number_buffers = (int)(floor(length / (BUFFER_SEPARATION_LENGTH_MULTIPLIER * 
				ptr_bnk_htree_sizing->buffer_segment_opt_length)));
			buffer_segment_length = length / number_buffers;
			number_buffers -= 1;
			//Calculate delay of tristate driver driving buffer
			c_wire_load = buffer_segment_length * wire_outside_mat_c_per_micron;
			r_wire = buffer_segment_length * wire_outside_mat_r_per_micron;
			delay_internal_tristate_driver = horowitz(inrisetime, time_constant_internal_tristate_driver, 0.5,
				0.5, RISE);
			inrisetime = delay_internal_tristate_driver / (1.0 - 0.5);
			c_gate_load = gatecap(ptr_bnk_htree_sizing->buffer_width_n[0] + 
				ptr_bnk_htree_sizing->buffer_width_p[0], 0.0);
			tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
				c_gate_load) + time_constant_tristate_driver_driving_buffer;
		    this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
			inrisetime = this_delay / (1.0 - 0.5);
			*delay += this_delay + delay_internal_tristate_driver;
			if((delay_internal_tristate_driver + this_delay) > 
				ptr_htree_at_mat_interval->max_delay_between_buffers){
					ptr_htree_at_mat_interval->max_delay_between_buffers = delay_internal_tristate_driver + this_delay;
			}

			//Calculate delay through all but the last buffer
			delay_internal_buffer = horowitz(inrisetime, ptr_htree_at_mat_interval->time_constant_internal_buffer, 0.5, 0.5, RISE);
			inrisetime = delay_internal_buffer / (1.0 - 0.5);
			tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
				c_gate_load) + ptr_htree_at_mat_interval->time_constant_buffer_driving_buffer;
			this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
			*delay += (number_buffers - 1) * (delay_internal_buffer + this_delay);
			inrisetime = this_delay / (1.0 - 0.5);

			//Calculate delay through the last buffer
			if(i == 0){
				c_gate_load = 2 * gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0);
				tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
					c_gate_load) + ptr_htree_at_mat_interval->time_constant_buffer_driving_final_seg;
			}
			else{
				c_gate_load =  gatecap(ptr_bnk_htree_sizing->tristate_driver_nand2_width_n + 
					ptr_bnk_htree_sizing->tristate_driver_nand2_width_p +
					ptr_bnk_htree_sizing->tristate_driver_nor2_width_n + 
					ptr_bnk_htree_sizing->tristate_driver_nor2_width_p, 0.0);
				tf = buffer_out_resistance * c_wire_load + r_wire * (c_wire_load / 2 + 
					c_gate_load) + time_constant_buffer_driving_tristate_driver;
			}
			this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
			*delay += this_delay + delay_internal_buffer;
			if((delay_internal_buffer + this_delay) > 
				ptr_htree_at_mat_interval->max_delay_between_buffers){
					ptr_htree_at_mat_interval->max_delay_between_buffers = delay_internal_buffer + this_delay;
			}
			inrisetime = this_delay / (1.0 - 0.5);
		}
		length *= 2;
	}
}




void initialize_decoder(int num_decode_signals, int flag_way_select, double c_load_decoder_output, 
        double r_wire_decoder_output, decoder *ptr_dec)
{
    int number_addr_bits_decode, i;
    ptr_dec->flag_decoder_exists = 0;
    ptr_dec->min_number_gates = 2;
    ptr_dec->delay = 0;
    ptr_dec->power.readOp.dynamic = 0;
    ptr_dec->power.readOp.leakage = 0;
    ptr_dec->power.writeOp.dynamic = 0;
    ptr_dec->power.writeOp.leakage = 0;
    for(i = 0; i < MAX_NUMBER_GATES_STAGE; ++i){
        ptr_dec->width_decoder_n[i] = 0;
        ptr_dec->width_decoder_p[i] = 0;
    }
    number_addr_bits_decode = (int) (logbasetwo((double) (num_decode_signals)));	
	if(number_addr_bits_decode < 4){
		if(flag_way_select)
		{
			ptr_dec->flag_decoder_exists = 1;
			ptr_dec->number_input_signals = 2;
		}
		else{
			ptr_dec->number_input_signals = 0;
		}
    }
    else{
		if(flag_way_select)
		{
			ptr_dec->flag_decoder_exists = 1;
			ptr_dec->number_input_signals = 3;
		}
		else{
			ptr_dec->flag_decoder_exists = 1;
			ptr_dec->number_input_signals = 2;
		}
    }	
    ptr_dec->r_wire_decoder_output = r_wire_decoder_output;
    ptr_dec->c_load_decoder_output = c_load_decoder_output;
}

void initialize_predecoder_blocks(int num_decode_signals, predecoder_block *ptr_predec_blk_1,
        predecoder_block *ptr_predec_blk_2, decoder *ptr_dec,
        double c_wire_predecoder_block_output, 
        double r_wire_predecoder_block_output,
        int number_decode_gates_driven_per_predecode_output)
{
    int number_addr_bits_decode, branch_effort_predecoder_block_1_output,
    branch_effort_predecoder_block_2_output, i;
    double c_load_decoder_gate;
    number_addr_bits_decode = (int) (logbasetwo((double) (num_decode_signals)));
    ptr_predec_blk_1->flag_block_exists = 0;
    ptr_predec_blk_2->flag_block_exists = 0;
    ptr_predec_blk_1->number_input_addr_bits = 0;
    ptr_predec_blk_2->number_input_addr_bits = 0;
    ptr_predec_blk_1->number_gates_first_level_nand2_path = 0;
    ptr_predec_blk_1->number_gates_first_level_nand3_path = 0;
    ptr_predec_blk_1->number_gates_second_level = 0;
    ptr_predec_blk_2->number_gates_first_level_nand2_path = 0;
    ptr_predec_blk_2->number_gates_first_level_nand3_path = 0;
    ptr_predec_blk_2->number_gates_second_level = 0;
    ptr_predec_blk_1->min_number_gates_first_level = 2;
    ptr_predec_blk_1->min_number_gates_second_level = 2;
    ptr_predec_blk_2->min_number_gates_first_level = 2;
    ptr_predec_blk_2->min_number_gates_second_level = 2;
    ptr_predec_blk_1->delay_nand2_path = 0;
    ptr_predec_blk_1->delay_nand3_path = 0;
    ptr_predec_blk_2->delay_nand2_path = 0;
    ptr_predec_blk_2->delay_nand3_path = 0;
    ptr_predec_blk_1->power_nand2_path.readOp.dynamic = 0;
    ptr_predec_blk_1->power_nand3_path.readOp.dynamic = 0;
    ptr_predec_blk_1->power_second_level.readOp.dynamic = 0;
    ptr_predec_blk_1->power_nand2_path.readOp.leakage = 0;
    ptr_predec_blk_1->power_nand3_path.readOp.leakage = 0;
    ptr_predec_blk_1->power_second_level.readOp.leakage = 0;
    ptr_predec_blk_2->power_nand2_path.readOp.dynamic = 0;
    ptr_predec_blk_2->power_nand3_path.readOp.dynamic = 0;
    ptr_predec_blk_2->power_second_level.readOp.dynamic = 0;
    ptr_predec_blk_2->power_nand2_path.readOp.leakage = 0;
    ptr_predec_blk_2->power_nand3_path.readOp.leakage = 0;
    ptr_predec_blk_2->power_second_level.readOp.leakage = 0;
    ptr_predec_blk_1->power_nand2_path.writeOp.dynamic = 0;
    ptr_predec_blk_1->power_nand3_path.writeOp.dynamic = 0;
    ptr_predec_blk_1->power_second_level.writeOp.dynamic = 0;
    ptr_predec_blk_1->power_nand2_path.writeOp.leakage = 0;
    ptr_predec_blk_1->power_nand3_path.writeOp.leakage = 0;
    ptr_predec_blk_1->power_second_level.writeOp.leakage = 0;
    ptr_predec_blk_2->power_nand2_path.writeOp.dynamic = 0;
    ptr_predec_blk_2->power_nand3_path.writeOp.dynamic = 0;
    ptr_predec_blk_2->power_second_level.writeOp.dynamic = 0;
    ptr_predec_blk_2->power_nand2_path.writeOp.leakage = 0;
    ptr_predec_blk_2->power_nand3_path.writeOp.leakage = 0;
    ptr_predec_blk_2->power_second_level.writeOp.leakage = 0;
    for(i = 0; i < MAX_NUMBER_GATES_STAGE; ++i){
        ptr_predec_blk_1->width_first_level_nand2_path_n[i] = 0;
        ptr_predec_blk_1->width_first_level_nand2_path_p[i] = 0;
        ptr_predec_blk_1->width_first_level_nand3_path_n[i] = 0;
        ptr_predec_blk_1->width_first_level_nand3_path_p[i] = 0;
        ptr_predec_blk_2->width_first_level_nand2_path_n[i] = 0;
        ptr_predec_blk_2->width_first_level_nand2_path_p[i] = 0;
        ptr_predec_blk_2->width_first_level_nand3_path_n[i] = 0;
        ptr_predec_blk_2->width_first_level_nand3_path_p[i] = 0;
        ptr_predec_blk_2->width_second_level_n[i] = 0;
        ptr_predec_blk_2->width_second_level_p[i] = 0;
    }

    if((number_addr_bits_decode != 0)){
        if((number_addr_bits_decode == 1)||(number_addr_bits_decode == 2)){//Just one predecoder block is
            //required with NAND2 gates. No decoder required. The first level of predecoding directly drives 
            //the decoder output load
            ptr_predec_blk_1->flag_block_exists = 1;
            ptr_predec_blk_1->number_input_addr_bits = number_addr_bits_decode;
            ptr_predec_blk_2->number_input_addr_bits = 0;
            ptr_predec_blk_1->r_wire_predecoder_block_output = ptr_dec->r_wire_decoder_output;
            ptr_predec_blk_2->r_wire_predecoder_block_output = 0;
            ptr_predec_blk_1->c_load_predecoder_block_output = ptr_dec->c_load_decoder_output ;	
            ptr_predec_blk_2->c_load_predecoder_block_output = 0;	
        }
        else{
            if(number_addr_bits_decode == 3){//Just one predecoder block is required with NAND3 gates. No decoder required. The first level 
                    //of predecoding durectly drives the decoder output load.
				ptr_predec_blk_1->flag_block_exists = 1;
				ptr_predec_blk_1->number_input_addr_bits = 3;
				ptr_predec_blk_2->number_input_addr_bits = 0;
				ptr_predec_blk_1->r_wire_predecoder_block_output = ptr_dec->r_wire_decoder_output;
				ptr_predec_blk_2->r_wire_predecoder_block_output = 0;
                    ptr_predec_blk_1->c_load_predecoder_block_output = ptr_dec->c_load_decoder_output;	
                    ptr_predec_blk_2->c_load_predecoder_block_output = 0;	
            }
            else{
                ptr_predec_blk_1->flag_block_exists = 1;
                ptr_predec_blk_2->flag_block_exists = 1;
                if(number_addr_bits_decode%2 == 0){
                    ptr_predec_blk_1->number_input_addr_bits = number_addr_bits_decode / 2;
                }
                else{
                    ptr_predec_blk_1->number_input_addr_bits = (int) (number_addr_bits_decode / 2) + 1;
                }
                ptr_predec_blk_2->number_input_addr_bits = number_addr_bits_decode - ptr_predec_blk_1->number_input_addr_bits;
                branch_effort_predecoder_block_1_output = (int) (pow(2, ptr_predec_blk_2->number_input_addr_bits));
                branch_effort_predecoder_block_2_output = (int) (pow(2, ptr_predec_blk_1->number_input_addr_bits));
                c_load_decoder_gate = number_decode_gates_driven_per_predecode_output *
                    gatecap(ptr_dec->width_decoder_n[0] + ptr_dec->width_decoder_p[0], 0);
                ptr_predec_blk_1->r_wire_predecoder_block_output = r_wire_predecoder_block_output;
                ptr_predec_blk_2->r_wire_predecoder_block_output = r_wire_predecoder_block_output;
                ptr_predec_blk_1->c_load_predecoder_block_output = 
                    branch_effort_predecoder_block_1_output * c_load_decoder_gate + c_wire_predecoder_block_output;	
                ptr_predec_blk_2->c_load_predecoder_block_output = 
                    branch_effort_predecoder_block_2_output * c_load_decoder_gate + c_wire_predecoder_block_output;	
            }
        }
    }
}

void initialize_predecoder_block_drivers(int number_decode_signals, int flag_way_select, int way_select,
										 predecoder_block_driver *ptr_predec_blk_driver_1,
										 predecoder_block_driver *ptr_predec_blk_driver_2,
										 predecoder_block *ptr_predec_blk_1,
										 predecoder_block *ptr_predec_blk_2, decoder *ptr_dec)
{
    int number_addr_bits_decode, i;
    number_addr_bits_decode = (int) (logbasetwo((double) (number_decode_signals)));
    ptr_predec_blk_driver_1->flag_driver_exists = 0;
    ptr_predec_blk_driver_2->flag_driver_exists = 0;
    ptr_predec_blk_driver_1->flag_driving_decoder_output = 0;
    ptr_predec_blk_driver_2->flag_driving_decoder_output = 0;
    ptr_predec_blk_driver_1->number_input_addr_bits = ptr_predec_blk_1->number_input_addr_bits;
	ptr_predec_blk_driver_2->number_input_addr_bits = ptr_predec_blk_2->number_input_addr_bits;
    ptr_predec_blk_driver_1->number_gates_nand2_path = 0;
    ptr_predec_blk_driver_2->number_gates_nand2_path = 0;
    ptr_predec_blk_driver_1->number_gates_nand3_path = 0;
    ptr_predec_blk_driver_2->number_gates_nand3_path = 0;
    ptr_predec_blk_driver_1->number_parallel_instances_driving_1_nand2_load = 0;
    ptr_predec_blk_driver_1->number_parallel_instances_driving_2_nand2_load = 0;
    ptr_predec_blk_driver_1->number_parallel_instances_driving_4_nand2_load = 0;
    ptr_predec_blk_driver_1->number_parallel_instances_driving_2_nand3_load = 0;
    ptr_predec_blk_driver_1->number_parallel_instances_driving_8_nand3_load = 0;
    ptr_predec_blk_driver_2->number_parallel_instances_driving_1_nand2_load = 0;
    ptr_predec_blk_driver_2->number_parallel_instances_driving_2_nand2_load = 0;
    ptr_predec_blk_driver_2->number_parallel_instances_driving_4_nand2_load = 0;
    ptr_predec_blk_driver_2->number_parallel_instances_driving_2_nand3_load = 0;
    ptr_predec_blk_driver_2->number_parallel_instances_driving_8_nand3_load = 0;
    ptr_predec_blk_driver_1->min_number_gates = 2;
    ptr_predec_blk_driver_2->min_number_gates = 2;
    ptr_predec_blk_driver_1->delay_nand2_path = 0;
    ptr_predec_blk_driver_1->delay_nand3_path = 0;
    ptr_predec_blk_driver_2->delay_nand2_path = 0;
    ptr_predec_blk_driver_2->delay_nand3_path = 0;
    ptr_predec_blk_driver_1->power_nand2_path.readOp.dynamic = 0;
    ptr_predec_blk_driver_1->power_nand3_path.readOp.dynamic = 0;
    ptr_predec_blk_driver_1->power_nand2_path.readOp.leakage = 0;
    ptr_predec_blk_driver_1->power_nand3_path.readOp.leakage = 0;
    ptr_predec_blk_driver_1->power_nand2_path.writeOp.dynamic = 0;
    ptr_predec_blk_driver_1->power_nand3_path.writeOp.dynamic = 0;
    ptr_predec_blk_driver_1->power_nand2_path.writeOp.leakage = 0;
    ptr_predec_blk_driver_1->power_nand3_path.writeOp.leakage = 0;
    ptr_predec_blk_driver_2->power_nand2_path.readOp.dynamic = 0;
    ptr_predec_blk_driver_2->power_nand3_path.readOp.dynamic = 0;
    ptr_predec_blk_driver_2->power_nand2_path.readOp.leakage = 0;
    ptr_predec_blk_driver_2->power_nand3_path.readOp.leakage = 0;
    ptr_predec_blk_driver_2->power_nand2_path.writeOp.dynamic = 0;
    ptr_predec_blk_driver_2->power_nand3_path.writeOp.dynamic = 0;
    ptr_predec_blk_driver_2->power_nand2_path.writeOp.leakage = 0;
    ptr_predec_blk_driver_2->power_nand3_path.writeOp.leakage = 0;
    for(i = 0; i < MAX_NUMBER_GATES_STAGE; ++i){
        ptr_predec_blk_driver_1->width_nand2_path_n[i] = 0;
        ptr_predec_blk_driver_1->width_nand2_path_p[i] = 0;
        ptr_predec_blk_driver_1->width_nand3_path_n[i] = 0;
        ptr_predec_blk_driver_1->width_nand3_path_p[i] = 0;
        ptr_predec_blk_driver_2->width_nand2_path_n[i] = 0;
        ptr_predec_blk_driver_2->width_nand2_path_p[i] = 0;
        ptr_predec_blk_driver_2->width_nand3_path_n[i] = 0;
        ptr_predec_blk_driver_2->width_nand3_path_p[i] = 0;
    }
    ptr_predec_blk_driver_1->r_load_nand2_path_predecode_block_driver_output = 0;
    ptr_predec_blk_driver_1->r_load_nand3_path_predecode_block_driver_output = 0;
    ptr_predec_blk_driver_2->r_load_nand2_path_predecode_block_driver_output = 0;
    ptr_predec_blk_driver_2->r_load_nand3_path_predecode_block_driver_output = 0;

	if(flag_way_select && (way_select > 1)){
		ptr_predec_blk_driver_1->flag_driver_exists = 1;
		ptr_predec_blk_driver_1->number_input_addr_bits = way_select; 
		if(ptr_dec->number_input_signals == 2){
			 ptr_predec_blk_driver_1->c_load_nand2_path_predecode_block_driver_output = 
				 gatecap(ptr_dec->width_decoder_n[0] + ptr_dec->width_decoder_p[0], 0);
			 ptr_predec_blk_driver_1->number_parallel_instances_driving_2_nand2_load =
				 ptr_predec_blk_driver_1->number_input_addr_bits;
		}
		else{
			if(ptr_dec->number_input_signals == 3){
				ptr_predec_blk_driver_1->c_load_nand3_path_predecode_block_driver_output = 
					gatecap(ptr_dec->width_decoder_n[0] + ptr_dec->width_decoder_p[0], 0);
				ptr_predec_blk_driver_1->number_parallel_instances_driving_2_nand3_load =
					ptr_predec_blk_driver_1->number_input_addr_bits;
			}
		}
        ptr_predec_blk_driver_1->r_load_nand2_path_predecode_block_driver_output = 0;
		ptr_predec_blk_driver_1->c_load_nand3_path_predecode_block_driver_output = 0;
        ptr_predec_blk_driver_1->r_load_nand3_path_predecode_block_driver_output = 0;
        ptr_predec_blk_driver_2->c_load_nand2_path_predecode_block_driver_output = 0;
        ptr_predec_blk_driver_2->r_load_nand2_path_predecode_block_driver_output = 0;
        ptr_predec_blk_driver_2->c_load_nand3_path_predecode_block_driver_output = 0;
        ptr_predec_blk_driver_2->r_load_nand3_path_predecode_block_driver_output = 0;
	}
	if(!flag_way_select){
		/*if(number_addr_bits_decode == 0){//means that there is no decoding required, however the 
			//load still needs to be driven by a chain of inverters. Use only one predecode block
			//driver
			ptr_predec_blk_driver_1->flag_driver_exists = 1;
			ptr_predec_blk_driver_1->flag_driving_decoder_output = 1;
			ptr_predec_blk_driver_1->c_load_nand2_path_predecode_block_driver_output = 
				ptr_dec->c_load_decoder_output;
			ptr_predec_blk_driver_1->r_load_nand2_path_predecode_block_driver_output =
				ptr_dec->r_wire_decoder_output;
			ptr_predec_blk_driver_1->c_load_nand3_path_predecode_block_driver_output = 0;
			ptr_predec_blk_driver_1->r_load_nand3_path_predecode_block_driver_output = 0;
			ptr_predec_blk_driver_2->c_load_nand2_path_predecode_block_driver_output = 0;
			ptr_predec_blk_driver_2->r_load_nand2_path_predecode_block_driver_output = 0;
			ptr_predec_blk_driver_2->c_load_nand3_path_predecode_block_driver_output = 0;
			ptr_predec_blk_driver_2->r_load_nand3_path_predecode_block_driver_output = 0;
		}
		else{*/
			if(ptr_predec_blk_1->flag_block_exists){
				ptr_predec_blk_driver_1->flag_driver_exists = 1;
			}
			if(ptr_predec_blk_2->flag_block_exists){
				ptr_predec_blk_driver_2->flag_driver_exists = 1;
			}
		//}
	}
}


static void compute_widths_predecoder_block_driver(
    predecoder_block_driver *ptr_predec_blk_driver,
    predecoder_block *ptr_predec_blk,
    decoder *ptr_dec,
    int way_select)
{
    //The predecode block driver accepts as input the address bits from the h-tree network. For 
    //each addr bit it then generates addr and addrbar as outputs. For now ignore the effect of
    //inversion to generate addrbar and simply treat addrbar as addr.

    int  i;
    double F, f, pmos_to_nmos_sizing_r;

	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
    if(ptr_predec_blk_driver->flag_driver_exists){	
		if(ptr_predec_blk_driver->flag_driving_decoder_output){
			ptr_predec_blk_driver->number_parallel_instances_driving_1_nand2_load = 1;
            ptr_predec_blk_driver->number_parallel_instances_driving_2_nand2_load = 0;
            ptr_predec_blk_driver->number_parallel_instances_driving_4_nand2_load = 0;
            ptr_predec_blk_driver->number_parallel_instances_driving_2_nand3_load = 0;
            ptr_predec_blk_driver->number_parallel_instances_driving_8_nand3_load = 0;
            ptr_predec_blk_driver->width_nand2_path_n[0] = minimum_width_nmos;
            ptr_predec_blk_driver->width_nand2_path_p[0] = pmos_to_nmos_sizing_r * ptr_predec_blk_driver->width_nand2_path_n[0];
            F = ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output / gatecap(ptr_predec_blk_driver->width_nand2_path_n[0] +
                    ptr_predec_blk_driver->width_nand2_path_p[0], 0);
            ptr_predec_blk_driver->number_gates_nand2_path = (int) (log(F) / log(fopt));
            //Check if number_gates_second_level_predecoder is odd. If it is, add 1 to make it even.
            if(ptr_predec_blk_driver->number_gates_nand2_path%2 != 0) {
                ++ptr_predec_blk_driver->number_gates_nand2_path;
            }
            if(ptr_predec_blk_driver->number_gates_nand2_path < ptr_predec_blk_driver->min_number_gates){
                ptr_predec_blk_driver->number_gates_nand2_path = ptr_predec_blk_driver->min_number_gates;
            }
            //Recalculate the effective fanout of each stage for the above number_gates_last_level_predecoder
            f = pow(F, 1.0 / ptr_predec_blk_driver->number_gates_nand2_path);
            i = ptr_predec_blk_driver->number_gates_nand2_path - 1;
            ptr_predec_blk_driver->width_nand2_path_n[i] = ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output / (gatecap(1, 0) * f);
            ptr_predec_blk_driver->width_nand2_path_p[i]  = 2 * ptr_predec_blk_driver->width_nand2_path_n[i];
            for(i = ptr_predec_blk_driver->number_gates_nand2_path - 2; i >= 1; --i){
                ptr_predec_blk_driver->width_nand2_path_n[i] = ptr_predec_blk_driver->width_nand2_path_n[i+1] / f;
                ptr_predec_blk_driver->width_nand2_path_p[i] = 2 * ptr_predec_blk_driver->width_nand2_path_n[i];
            }
        }
        else{
			if(way_select == 0){
				if(ptr_predec_blk->number_input_addr_bits == 1){//2 NAND2 gates
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand2_load =	1;
					ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output = 
						2 * gatecap(ptr_predec_blk->width_first_level_nand2_path_n[0] +
						ptr_predec_blk->width_first_level_nand2_path_p[0], 0);

				}
				if(ptr_predec_blk->number_input_addr_bits == 2){//4 NAND2 gates
					ptr_predec_blk_driver->number_parallel_instances_driving_1_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_4_nand2_load = 2;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand3_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_8_nand3_load = 0;
					ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output = 
						4 * gatecap(ptr_predec_blk->width_first_level_nand2_path_n[0] +
						ptr_predec_blk->width_first_level_nand2_path_p[0], 0);
				}
				if(ptr_predec_blk->number_input_addr_bits == 3){//8 NAND3 gates
					ptr_predec_blk_driver->number_parallel_instances_driving_1_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_4_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand3_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_8_nand3_load = 3;
					ptr_predec_blk_driver->c_load_nand3_path_predecode_block_driver_output = 
						8 * gatecap(ptr_predec_blk->width_first_level_nand3_path_n[0] +
						ptr_predec_blk->width_first_level_nand3_path_p[0], 0);
				}
				if(ptr_predec_blk->number_input_addr_bits == 4){//4 + 4 NAND2 gates
					ptr_predec_blk_driver->number_parallel_instances_driving_1_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_4_nand2_load = 4;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand3_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_8_nand3_load = 0;
					ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output = 
						4 * gatecap(ptr_predec_blk->width_first_level_nand2_path_n[0] +
						ptr_predec_blk->width_first_level_nand2_path_p[0], 0);
				}
				if(ptr_predec_blk->number_input_addr_bits == 5){//4 NAND2 gates, 8 NAND3 gates
					ptr_predec_blk_driver->number_parallel_instances_driving_1_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_4_nand2_load = 2;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand3_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_8_nand3_load = 3;
					ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output =
						4 * gatecap(ptr_predec_blk->width_first_level_nand2_path_n[0] +
						ptr_predec_blk->width_first_level_nand2_path_p[0], 0);
					ptr_predec_blk_driver->c_load_nand3_path_predecode_block_driver_output = 
						8 * gatecap(ptr_predec_blk->width_first_level_nand3_path_n[0] +
						ptr_predec_blk->width_first_level_nand3_path_p[0], 0);
				}
				if(ptr_predec_blk->number_input_addr_bits == 6){//8 + 8 NAND3 gates
					ptr_predec_blk_driver->number_parallel_instances_driving_1_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_4_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand3_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_8_nand3_load = 6;
					ptr_predec_blk_driver->c_load_nand3_path_predecode_block_driver_output = 
						8 * gatecap(ptr_predec_blk->width_first_level_nand3_path_n[0] +
						ptr_predec_blk->width_first_level_nand3_path_p[0], 0);
				}
				if(ptr_predec_blk->number_input_addr_bits == 7){//4 + 4 NAND2 gates, 8 NAND3 gates
					ptr_predec_blk_driver->number_parallel_instances_driving_1_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_4_nand2_load = 4;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand3_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_8_nand3_load = 3;
					ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output =
						4 * gatecap(ptr_predec_blk->width_first_level_nand2_path_n[0] +
						ptr_predec_blk->width_first_level_nand2_path_p[0], 0);
					ptr_predec_blk_driver->c_load_nand3_path_predecode_block_driver_output = 
						8 * gatecap(ptr_predec_blk->width_first_level_nand3_path_n[0] +
						ptr_predec_blk->width_first_level_nand3_path_p[0], 0);
				}
				if(ptr_predec_blk->number_input_addr_bits == 8){//4 NAND2 gates, 8 + 8 NAND3 gates
					ptr_predec_blk_driver->number_parallel_instances_driving_1_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_4_nand2_load = 2;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand3_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_8_nand3_load = 6;
					ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output =
						4 * gatecap(ptr_predec_blk->width_first_level_nand2_path_n[0] +
						ptr_predec_blk->width_first_level_nand2_path_p[0], 0);
					ptr_predec_blk_driver->c_load_nand3_path_predecode_block_driver_output = 
						8 * gatecap(ptr_predec_blk->width_first_level_nand3_path_n[0] +
						ptr_predec_blk->width_first_level_nand3_path_p[0], 0);
				}
				if(ptr_predec_blk->number_input_addr_bits == 9){//8 + 8 + 8 NAND3 gates
					ptr_predec_blk_driver->number_parallel_instances_driving_1_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_4_nand2_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_2_nand3_load = 0;
					ptr_predec_blk_driver->number_parallel_instances_driving_8_nand3_load = 9;
					ptr_predec_blk_driver->c_load_nand3_path_predecode_block_driver_output = 
						8 * gatecap(ptr_predec_blk->width_first_level_nand3_path_n[0] +
						ptr_predec_blk->width_first_level_nand3_path_p[0], 0);
				}
			}

			if((ptr_predec_blk->flag_two_unique_paths)||(ptr_predec_blk->number_inputs_first_level_gate == 2)
				||(ptr_predec_blk_driver->number_input_addr_bits == 0)|| 
					((way_select)&&(ptr_dec->number_input_signals == 2))){ //this means that way_select is driving NAND2 in decoder. 
						ptr_predec_blk_driver->width_nand2_path_n[0] = minimum_width_nmos;
						ptr_predec_blk_driver->width_nand2_path_p[0] = pmos_to_nmos_sizing_r * ptr_predec_blk_driver->width_nand2_path_n[0];
						F = ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output / gatecap(ptr_predec_blk_driver->width_nand2_path_n[0] +
							ptr_predec_blk_driver->width_nand2_path_p[0], 0);
						ptr_predec_blk_driver->number_gates_nand2_path = (int) (log(F) / log(fopt));
						if(ptr_predec_blk_driver->number_gates_nand2_path%2 != 0){
							++ptr_predec_blk_driver->number_gates_nand2_path;
						}
						if(ptr_predec_blk_driver->number_gates_nand2_path < ptr_predec_blk_driver->min_number_gates){
							ptr_predec_blk_driver->number_gates_nand2_path = ptr_predec_blk_driver->min_number_gates;
						}
						//Recalculate the effective fanout of each stage for the above number_gates_last_level_predecoder
						f = pow(F, 1.0 / ptr_predec_blk_driver->number_gates_nand2_path);
						i = ptr_predec_blk_driver->number_gates_nand2_path - 1;
						ptr_predec_blk_driver->width_nand2_path_n[i] = ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output / (gatecap(1, 0) * f);
						ptr_predec_blk_driver->width_nand2_path_p[i]  = 2 * ptr_predec_blk_driver->width_nand2_path_n[i];
						for(i = ptr_predec_blk_driver->number_gates_nand2_path - 2; i >= 1; --i){
							ptr_predec_blk_driver->width_nand2_path_n[i] = ptr_predec_blk_driver->width_nand2_path_n[i+1] / f;
							ptr_predec_blk_driver->width_nand2_path_p[i] = 2 * ptr_predec_blk_driver->width_nand2_path_n[i];
						}
			}
			if((ptr_predec_blk->flag_two_unique_paths)||(ptr_predec_blk->number_inputs_first_level_gate == 3)||
					((way_select)&&(ptr_dec->number_input_signals == 3))){ //this means that way_select is driving NAND3 in decoder. 
						ptr_predec_blk_driver->width_nand3_path_n[0] = minimum_width_nmos;
						ptr_predec_blk_driver->width_nand3_path_p[0] = pmos_to_nmos_sizing_r * ptr_predec_blk_driver->width_nand3_path_n[0];
						F = ptr_predec_blk_driver->c_load_nand3_path_predecode_block_driver_output / gatecap(ptr_predec_blk_driver->width_nand3_path_n[0] +
							ptr_predec_blk_driver->width_nand3_path_p[0], 0);
						ptr_predec_blk_driver->number_gates_nand3_path = (int) (log(F) / log(fopt));
						if(ptr_predec_blk_driver->number_gates_nand3_path%2 != 0){
							++ptr_predec_blk_driver->number_gates_nand3_path;
						}
						if(ptr_predec_blk_driver->number_gates_nand3_path < ptr_predec_blk_driver->min_number_gates){
							ptr_predec_blk_driver->number_gates_nand3_path = ptr_predec_blk_driver->min_number_gates;
						}
						//Recalculate the effective fanout of each stage for the above number_gates_last_level_predecoder
						f = pow(F, 1.0 / ptr_predec_blk_driver->number_gates_nand3_path);
						i = ptr_predec_blk_driver->number_gates_nand3_path - 1;
						ptr_predec_blk_driver->width_nand3_path_n[i] =  ptr_predec_blk_driver->c_load_nand3_path_predecode_block_driver_output / (gatecap(1, 0) * f);
						ptr_predec_blk_driver->width_nand3_path_p[i]  = 2 * ptr_predec_blk_driver->width_nand3_path_n[i];
						for(i = ptr_predec_blk_driver->number_gates_nand3_path - 2; i >= 1; --i){
							ptr_predec_blk_driver->width_nand3_path_n[i] = ptr_predec_blk_driver->width_nand3_path_n[i+1] / f;
							ptr_predec_blk_driver->width_nand3_path_p[i] = 2 * ptr_predec_blk_driver->width_nand3_path_n[i];
						}
			}
		}
    }
}


static void delay_predecoder_block_driver(
    predecoder_block_driver *ptr_predec_blk_driver,
    double inrisetime_nand2_path,
    double inrisetime_nand3_path,
    double *outrisetime_nand2_path,
    double *outrisetime_nand3_path)
{
    int i;
    double rd, c_gate_load, c_load, c_intrinsic, tf, this_delay;
    *outrisetime_nand2_path = 0;
    *outrisetime_nand3_path = 0;
    if(ptr_predec_blk_driver->flag_driver_exists){
        for(i = 0; i < ptr_predec_blk_driver->number_gates_nand2_path - 1; ++i){
            rd = transreson(ptr_predec_blk_driver->width_nand2_path_n[i], NCH, 1);
            c_gate_load = gatecap(ptr_predec_blk_driver->width_nand2_path_p[i+1] + 
                    ptr_predec_blk_driver->width_nand2_path_n[i+1], 0.0);
            c_intrinsic = draincap(ptr_predec_blk_driver->width_nand2_path_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                draincap(ptr_predec_blk_driver->width_nand2_path_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
            tf = rd * (c_intrinsic + c_gate_load);
            this_delay = horowitz(inrisetime_nand2_path, tf, 0.5, 0.5, RISE);
            ptr_predec_blk_driver->delay_nand2_path += this_delay;
            inrisetime_nand2_path = this_delay / (1.0 - 0.5);
            ptr_predec_blk_driver->power_nand2_path.readOp.dynamic += 
                (c_gate_load + c_intrinsic) * 0.5 * vdd_periph_global * vdd_periph_global;
        }

        //Final inverter drives the predecoder block or the decoder output load 
        if(ptr_predec_blk_driver->number_gates_nand2_path != 0){
            i = ptr_predec_blk_driver->number_gates_nand2_path - 1;
            rd = transreson(ptr_predec_blk_driver->width_nand2_path_n[i], NCH, 1);
            c_intrinsic = draincap(ptr_predec_blk_driver->width_nand2_path_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                draincap(ptr_predec_blk_driver->width_nand2_path_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
            c_load = ptr_predec_blk_driver->c_load_nand2_path_predecode_block_driver_output;
            tf = rd * (c_intrinsic + c_load) + 
                ptr_predec_blk_driver->r_load_nand2_path_predecode_block_driver_output * 
                c_load/ 2;
            this_delay = horowitz(inrisetime_nand2_path, tf, 0.5, 0.5, RISE);
            ptr_predec_blk_driver->delay_nand2_path += this_delay;
            *outrisetime_nand2_path = this_delay / (1.0 - 0.5);	
            ptr_predec_blk_driver->power_nand2_path.readOp.dynamic += 
                (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
        }


        for(i = 0; i < ptr_predec_blk_driver->number_gates_nand3_path - 1; ++i){
            rd = transreson(ptr_predec_blk_driver->width_nand3_path_n[i], NCH, 1);
            c_gate_load = gatecap(ptr_predec_blk_driver->width_nand3_path_p[i+1] + 
                    ptr_predec_blk_driver->width_nand3_path_n[i+1], 0.0);
            c_intrinsic = draincap(ptr_predec_blk_driver->width_nand3_path_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                draincap(ptr_predec_blk_driver->width_nand3_path_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
            tf = rd * (c_intrinsic + c_gate_load);
            this_delay = horowitz(inrisetime_nand3_path, tf, 0.5, 0.5, RISE);
            ptr_predec_blk_driver->delay_nand3_path += this_delay;
            inrisetime_nand3_path = this_delay / (1.0 - 0.5);
            ptr_predec_blk_driver->power_nand3_path.readOp.dynamic += 
                (c_gate_load + c_intrinsic) * 0.5 * vdd_periph_global * vdd_periph_global;
        }

        //Final inverter drives the predecoder block or the decoder output load 
        if(ptr_predec_blk_driver->number_gates_nand3_path != 0){
            i = ptr_predec_blk_driver->number_gates_nand3_path - 1;
            rd = transreson(ptr_predec_blk_driver->width_nand3_path_n[i], NCH, 1);
            c_intrinsic = draincap(ptr_predec_blk_driver->width_nand3_path_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                draincap(ptr_predec_blk_driver->width_nand3_path_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
            c_load = ptr_predec_blk_driver->c_load_nand3_path_predecode_block_driver_output;
            tf = rd * (c_intrinsic + c_load) + 
                ptr_predec_blk_driver->r_load_nand3_path_predecode_block_driver_output * 
                c_load / 2;
            this_delay = horowitz(inrisetime_nand3_path, tf, 0.5, 0.5, RISE);
            ptr_predec_blk_driver->delay_nand3_path += this_delay;
            *outrisetime_nand3_path = this_delay / (1.0 - 0.5);	
            ptr_predec_blk_driver->power_nand3_path.readOp.dynamic += 
                (c_intrinsic + c_load) * 0.5 *	vdd_periph_global * vdd_periph_global;
        }
    }
}


static void compute_widths_predecoder_block(predecoder_block *ptr_predec_blk)
{
    int i;
    double F, f, c_load_nand3_path, c_load_nand2_path, c_input, c_load, pmos_to_nmos_sizing_r;

	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
    if(ptr_predec_blk->flag_block_exists){ 
        ptr_predec_blk->branch_effort_nand2_gate_output = 1;
        ptr_predec_blk->branch_effort_nand3_gate_output = 1;
        ptr_predec_blk->number_inputs_first_level_gate = 0;

        if(ptr_predec_blk->number_input_addr_bits == 1){
            ptr_predec_blk->flag_two_unique_paths = 0;
            ptr_predec_blk->number_inputs_first_level_gate = 2;
            ptr_predec_blk->flag_second_level_gate = 0;
        } 
        if(ptr_predec_blk->number_input_addr_bits == 2){
            ptr_predec_blk->flag_two_unique_paths = 0;
            ptr_predec_blk->number_inputs_first_level_gate = 2;
            ptr_predec_blk->flag_second_level_gate = 0;
        } 
        if(ptr_predec_blk->number_input_addr_bits == 3){
            ptr_predec_blk->flag_two_unique_paths = 0;
            ptr_predec_blk->flag_second_level_gate = 0;		
            ptr_predec_blk->number_inputs_first_level_gate = 3;
        }
        if(ptr_predec_blk->number_input_addr_bits == 4){
            ptr_predec_blk->flag_two_unique_paths = 0;
            ptr_predec_blk->flag_second_level_gate = 2;	
            ptr_predec_blk->number_inputs_first_level_gate = 2;
            ptr_predec_blk->branch_effort_nand2_gate_output = 4;
        }
        if(ptr_predec_blk->number_input_addr_bits == 5){
            ptr_predec_blk->flag_two_unique_paths = 1;
            ptr_predec_blk->flag_second_level_gate = 2;	
            ptr_predec_blk->branch_effort_nand2_gate_output = 8;
			ptr_predec_blk->branch_effort_nand3_gate_output = 4;
        }
        if(ptr_predec_blk->number_input_addr_bits == 6){
            ptr_predec_blk->flag_two_unique_paths = 0;
            ptr_predec_blk->number_inputs_first_level_gate = 3;
            ptr_predec_blk->flag_second_level_gate = 2;	
            ptr_predec_blk->branch_effort_nand3_gate_output = 8;
        }
        if(ptr_predec_blk->number_input_addr_bits == 7){
            ptr_predec_blk->flag_two_unique_paths = 1;
            ptr_predec_blk->flag_second_level_gate = 3;	
            ptr_predec_blk->branch_effort_nand2_gate_output = 32;
            ptr_predec_blk->branch_effort_nand3_gate_output = 16;
        }
        if(ptr_predec_blk->number_input_addr_bits == 8){
            ptr_predec_blk->flag_two_unique_paths = 1;
            ptr_predec_blk->flag_second_level_gate = 3;	
            ptr_predec_blk->branch_effort_nand2_gate_output = 64;
           ptr_predec_blk->branch_effort_nand3_gate_output = 32;
		}           
        if(ptr_predec_blk->number_input_addr_bits == 9){
            ptr_predec_blk->flag_two_unique_paths = 0;
			ptr_predec_blk->number_inputs_first_level_gate = 3;
            ptr_predec_blk->flag_second_level_gate = 3;
            ptr_predec_blk->branch_effort_nand3_gate_output = 64;
        }

        //Find number of gates and sizing in second level of predecoder (if there is a second level)
		if(ptr_predec_blk->flag_second_level_gate){
            if(ptr_predec_blk->flag_second_level_gate == 2){//2nd level is a NAND2 gate
                ptr_predec_blk->width_second_level_n[0] = 2 * minimum_width_nmos;
                ptr_predec_blk->width_second_level_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
                F = gnand2 * ptr_predec_blk->c_load_predecoder_block_output / (gatecap(ptr_predec_blk->width_second_level_n[0], 0) +
                        gatecap(ptr_predec_blk->width_second_level_p[0], 0));
            }
            else{//2nd level is a NAND3 gate
                ptr_predec_blk->width_second_level_n[0] = 3 * minimum_width_nmos;
                ptr_predec_blk->width_second_level_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
                F = gnand3 * ptr_predec_blk->c_load_predecoder_block_output / (gatecap(ptr_predec_blk->width_second_level_n[0], 0) +
                        gatecap(ptr_predec_blk->width_second_level_p[0], 0));
            }
            ptr_predec_blk->number_gates_second_level = (int) (log(F) / log(fopt));
            //Check if number_gates_second_level_predecoder is odd. If it is, add 1 to make it even.
            if(ptr_predec_blk->number_gates_second_level%2 != 0) {
                ++ptr_predec_blk->number_gates_second_level;
            }
            if(ptr_predec_blk->number_gates_second_level < ptr_predec_blk->min_number_gates_second_level){
                ptr_predec_blk->number_gates_second_level = ptr_predec_blk->min_number_gates_second_level;
            }
            //Recalculate the effective fanout of each stage for the above number_gates_last_level_predecoder
            f = pow(F, 1.0 / ptr_predec_blk->number_gates_second_level);
            i = ptr_predec_blk->number_gates_second_level - 1;
			c_input = ptr_predec_blk->c_load_predecoder_block_output / f;
            ptr_predec_blk->width_second_level_n[i]  = (1.0 / 3.0) * c_input / gatecap(1, 0);
            ptr_predec_blk->width_second_level_p[i] = 2 * ptr_predec_blk->width_second_level_n[i];

			if( ptr_predec_blk->width_second_level_n[i] > MAX_NMOS_WIDTH){
				 c_load = gatecap(MAX_NMOS_WIDTH + 2 * MAX_NMOS_WIDTH, 0);
				 if(ptr_predec_blk->flag_second_level_gate == 2){
					 F =  gnand2 * c_load / gatecap(ptr_predec_blk->width_second_level_n[0] +
						 ptr_predec_blk->width_second_level_p[0] , 0);
				 }
				 else{
					 if(ptr_predec_blk->flag_second_level_gate == 3){
						F =  gnand3 * c_load / gatecap(ptr_predec_blk->width_second_level_n[0] +
							ptr_predec_blk->width_second_level_p[0], 0);
					 }
				 }
				 ptr_predec_blk->number_gates_second_level = (int) (log(F) / log(fopt)) + 1;
				 if(ptr_predec_blk->number_gates_second_level%2 != 0){
					 ++ptr_predec_blk->number_gates_second_level;
				 }
				 if(ptr_predec_blk->number_gates_second_level < ptr_predec_blk->min_number_gates_second_level){
					 ptr_predec_blk->number_gates_second_level = ptr_predec_blk->min_number_gates_second_level;
				 }
				 f = pow(F, 1.0 / ptr_predec_blk->number_gates_second_level);
				 i = ptr_predec_blk->number_gates_second_level - 1;
				 ptr_predec_blk->width_second_level_n[i] = MAX_NMOS_WIDTH;
				 ptr_predec_blk->width_second_level_p[i] = 2 *  ptr_predec_blk->width_second_level_n[i];
			}

        for(i = ptr_predec_blk->number_gates_second_level - 2; i >= 1; --i){
			ptr_predec_blk->width_second_level_n[i] = ptr_predec_blk->width_second_level_n[i + 1] / f;
            ptr_predec_blk->width_second_level_p[i] = 2 * ptr_predec_blk->width_second_level_n[i];
		}


            //Now find number of gates and widths in first level of predecoder
		if((ptr_predec_blk->flag_two_unique_paths)||(ptr_predec_blk->number_inputs_first_level_gate == 2)){//Whenever flag_two_unique_paths is 
                //TRUE, it means first level of decoder employs both NAND2 and NAND3 gates. Or when 
                //number_inputs_first_level_gate is 2, it means a NAND2 gate is used in the first level of
                //the predecoder
                c_load_nand2_path = ptr_predec_blk->branch_effort_nand2_gate_output * 
                    (gatecap(ptr_predec_blk->width_second_level_n[0], 0) + 
                     gatecap(ptr_predec_blk->width_second_level_p[0], 0));
                ptr_predec_blk->width_first_level_nand2_path_n[0] = 2 * minimum_width_nmos;
                ptr_predec_blk->width_first_level_nand2_path_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
                F = gnand2 * c_load_nand2_path / (gatecap(ptr_predec_blk->width_first_level_nand2_path_n[0], 0) +
                        gatecap(ptr_predec_blk->width_first_level_nand2_path_p[0], 0));
                ptr_predec_blk->number_gates_first_level_nand2_path = (int) (log(F) / log(fopt));
                //Check if number_gates_second_level_predecoder is odd. If it is, add 1 to make it even.
                if(ptr_predec_blk->number_gates_first_level_nand2_path % 2 != 0) {
                    ++ptr_predec_blk->number_gates_first_level_nand2_path;
                }
                if(ptr_predec_blk->number_gates_first_level_nand2_path < ptr_predec_blk->min_number_gates_first_level){
                    ptr_predec_blk->number_gates_first_level_nand2_path = ptr_predec_blk->min_number_gates_first_level;
                }
                //Recalculate the effective fanout of each stage 
                f = pow(F, 1.0 / ptr_predec_blk->number_gates_first_level_nand2_path);
                i = ptr_predec_blk->number_gates_first_level_nand2_path - 1;
				c_input = c_load_nand2_path / f;
                ptr_predec_blk->width_first_level_nand2_path_n[i]  = (1.0 / 3.0) * c_input / gatecap(1, 0);
                ptr_predec_blk->width_first_level_nand2_path_p[i] = 2 * ptr_predec_blk->width_first_level_nand2_path_n[i];
					
				if( ptr_predec_blk->width_first_level_nand2_path_n[i] > MAX_NMOS_WIDTH){
					c_load = gatecap(MAX_NMOS_WIDTH + 2 * MAX_NMOS_WIDTH, 0);
					F =  gnand2 * c_load / gatecap(ptr_predec_blk->width_first_level_nand2_path_n[0] +
						ptr_predec_blk->width_first_level_nand2_path_p[0] , 0);
					ptr_predec_blk->number_gates_first_level_nand2_path = (int) (log(F) / log(fopt)) + 1;
					if(ptr_predec_blk->number_gates_first_level_nand2_path%2 != 0){
						++ptr_predec_blk->number_gates_first_level_nand2_path;
				 }
					if(ptr_predec_blk->number_gates_first_level_nand2_path < ptr_predec_blk->min_number_gates_first_level){
						ptr_predec_blk->number_gates_first_level_nand2_path = ptr_predec_blk->min_number_gates_first_level;
				 }
					f = pow(F, 1.0 / ptr_predec_blk->number_gates_first_level_nand2_path);
					i = ptr_predec_blk->number_gates_first_level_nand2_path - 1;
					ptr_predec_blk->width_first_level_nand2_path_n[i] = MAX_NMOS_WIDTH;
					ptr_predec_blk->width_first_level_nand2_path_p[i] = 2 *  ptr_predec_blk->width_first_level_nand2_path_n[i];
				}

                for(i = ptr_predec_blk->number_gates_first_level_nand2_path - 2; i >= 1; --i){
                    ptr_predec_blk->width_first_level_nand2_path_n[i] = ptr_predec_blk->width_first_level_nand2_path_n[i + 1] / f;
                    ptr_predec_blk->width_first_level_nand2_path_p[i] = 2 * ptr_predec_blk->width_first_level_nand2_path_n[i];
                }
            }

            //Now find widths of gates along path in which first gate is a NAND3
            if((ptr_predec_blk->flag_two_unique_paths)||(ptr_predec_blk->number_inputs_first_level_gate == 3)){//Whenever flag_two_unique_paths is 
                //TRUE, it means first level of decoder employs both NAND2 and NAND3 gates. Or when 
                //number_inputs_first_level_gate is 3, it means a NAND3 gate is used in the first level of
                //the predecoder
                c_load_nand3_path = ptr_predec_blk->branch_effort_nand3_gate_output * 
                    (gatecap(ptr_predec_blk->width_second_level_n[0], 0) + 
                     gatecap(ptr_predec_blk->width_second_level_p[0], 0));
                ptr_predec_blk->width_first_level_nand3_path_n[0] = 3 * minimum_width_nmos;
                ptr_predec_blk->width_first_level_nand3_path_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
                F = gnand3 * c_load_nand3_path / (gatecap(ptr_predec_blk->width_first_level_nand3_path_n[0], 0) +
                        gatecap(ptr_predec_blk->width_first_level_nand3_path_p[0], 0));
                ptr_predec_blk->number_gates_first_level_nand3_path = (int) (log(F) / log(fopt));
                //Check if number_gates_second_level_predecoder is odd. If it is, add 1 to make it even.
                if(ptr_predec_blk->number_gates_first_level_nand3_path % 2 != 0) {
                    ++ptr_predec_blk->number_gates_first_level_nand3_path;
                }
                if(ptr_predec_blk->number_gates_first_level_nand3_path < ptr_predec_blk->min_number_gates_first_level){
                    ptr_predec_blk->number_gates_first_level_nand3_path = ptr_predec_blk->min_number_gates_first_level;
                }
                //Recalculate the effective fanout of each stage 
                f = pow(F, 1.0 / ptr_predec_blk->number_gates_first_level_nand3_path);
                i = ptr_predec_blk->number_gates_first_level_nand3_path - 1;
				c_input = c_load_nand3_path / f;
                ptr_predec_blk->width_first_level_nand3_path_n[i]  = (1.0 / 3.0) * c_input / gatecap(1, 0);
                ptr_predec_blk->width_first_level_nand3_path_p[i] = 2 * ptr_predec_blk->width_first_level_nand3_path_n[i];
				
				if( ptr_predec_blk->width_first_level_nand3_path_n[i] > MAX_NMOS_WIDTH){
					c_load = gatecap(MAX_NMOS_WIDTH + 2 * MAX_NMOS_WIDTH, 0);
					F =  gnand3 * c_load / gatecap(ptr_predec_blk->width_first_level_nand3_path_n[0] +
						ptr_predec_blk->width_first_level_nand3_path_p[0] , 0);
					ptr_predec_blk->number_gates_first_level_nand3_path = (int) (log(F) / log(fopt)) + 1;
					if(ptr_predec_blk->number_gates_first_level_nand3_path%2 != 0){
						++ptr_predec_blk->number_gates_first_level_nand3_path;
				 }
					if(ptr_predec_blk->number_gates_first_level_nand3_path < ptr_predec_blk->min_number_gates_first_level){
						ptr_predec_blk->number_gates_first_level_nand3_path = ptr_predec_blk->min_number_gates_first_level;
				 }
					f = pow(F, 1.0 / ptr_predec_blk->number_gates_first_level_nand3_path);
					i = ptr_predec_blk->number_gates_first_level_nand3_path - 1;
					ptr_predec_blk->width_first_level_nand3_path_n[i] = MAX_NMOS_WIDTH;
					ptr_predec_blk->width_first_level_nand3_path_p[i] = 2 *  ptr_predec_blk->width_first_level_nand3_path_n[i];
				}

               for(i = ptr_predec_blk->number_gates_first_level_nand3_path - 2; i >= 1; --i){
                    ptr_predec_blk->width_first_level_nand3_path_n[i] = ptr_predec_blk->width_first_level_nand3_path_n[i + 1] / f;
                    ptr_predec_blk->width_first_level_nand3_path_p[i] = 2 * ptr_predec_blk->width_first_level_nand3_path_n[i];
                }
            }	
        }
		else{//Find number of gates and widths in first level of predecoder block when there is no second level 
            if(ptr_predec_blk->number_inputs_first_level_gate == 2){
                ptr_predec_blk->width_first_level_nand2_path_n[0] = 2 * minimum_width_nmos;
                ptr_predec_blk->width_first_level_nand2_path_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
                F = ptr_predec_blk->c_load_predecoder_block_output / (gatecap(ptr_predec_blk->width_first_level_nand2_path_n[0], 0) +
                        gatecap(ptr_predec_blk->width_first_level_nand2_path_p[0], 0));
                ptr_predec_blk->number_gates_first_level_nand2_path = (int) (log(F) / log(fopt));
                //Check if number_gates_second_level_predecoder is odd. If it is, add 1 to make it even.
                if(ptr_predec_blk->number_gates_first_level_nand2_path % 2 != 0) {
                    ++ptr_predec_blk->number_gates_first_level_nand2_path;
                }
                if(ptr_predec_blk->number_gates_first_level_nand2_path < ptr_predec_blk->min_number_gates_first_level){
                    ptr_predec_blk->number_gates_first_level_nand2_path = ptr_predec_blk->min_number_gates_first_level;
                }
                //Recalculate the effective fanout of each stage 
                f = pow(F, 1.0 / ptr_predec_blk->number_gates_first_level_nand2_path);
                i = ptr_predec_blk->number_gates_first_level_nand2_path - 1;
                
				c_input = ptr_predec_blk->c_load_predecoder_block_output / f;
                ptr_predec_blk->width_first_level_nand2_path_n[i]  = (1.0 / 3.0) * c_input / gatecap(1, 0);
                ptr_predec_blk->width_first_level_nand2_path_p[i] = 2 * ptr_predec_blk->width_first_level_nand2_path_n[i];
					
				if( ptr_predec_blk->width_first_level_nand2_path_n[i] > MAX_NMOS_WIDTH){
					c_load = gatecap(MAX_NMOS_WIDTH + 2 * MAX_NMOS_WIDTH, 0);
					F =  gnand2 * c_load / gatecap(ptr_predec_blk->width_first_level_nand2_path_n[0] +
						ptr_predec_blk->width_first_level_nand2_path_p[0] , 0);
					ptr_predec_blk->number_gates_first_level_nand2_path = (int) (log(F) / log(fopt)) + 1;
					if(ptr_predec_blk->number_gates_first_level_nand2_path%2 != 0){
						++ptr_predec_blk->number_gates_first_level_nand2_path;
				 }
					if(ptr_predec_blk->number_gates_first_level_nand2_path < ptr_predec_blk->min_number_gates_first_level){
						ptr_predec_blk->number_gates_first_level_nand2_path = ptr_predec_blk->min_number_gates_first_level;
				 }
					f = pow(F, 1.0 / ptr_predec_blk->number_gates_first_level_nand2_path);
					i = ptr_predec_blk->number_gates_first_level_nand2_path - 1;
					ptr_predec_blk->width_first_level_nand2_path_n[i] = MAX_NMOS_WIDTH;
					ptr_predec_blk->width_first_level_nand2_path_p[i] = 2 *  ptr_predec_blk->width_first_level_nand2_path_n[i];
				}

                for(i = ptr_predec_blk->number_gates_first_level_nand2_path - 2; i >= 1; --i){
                    ptr_predec_blk->width_first_level_nand2_path_n[i] = ptr_predec_blk->width_first_level_nand2_path_n[i + 1] / f;
                    ptr_predec_blk->width_first_level_nand2_path_p[i] = 2 * ptr_predec_blk->width_first_level_nand2_path_n[i];
                }
            }

            if(ptr_predec_blk->number_inputs_first_level_gate == 3){
                ptr_predec_blk->width_first_level_nand3_path_n[0] = 3 * minimum_width_nmos;
                ptr_predec_blk->width_first_level_nand3_path_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
                F = ptr_predec_blk->c_load_predecoder_block_output / (gatecap(ptr_predec_blk->width_first_level_nand3_path_n[0], 0) +
                        gatecap(ptr_predec_blk->width_first_level_nand3_path_p[0], 0));
                ptr_predec_blk->number_gates_first_level_nand3_path = (int) (log(F) / log(fopt));
                //Check if number_gates_second_level_predecoder is odd. If it is, add 1 to make it even.
                if(ptr_predec_blk->number_gates_first_level_nand3_path % 2 != 0) {
                    ++ptr_predec_blk->number_gates_first_level_nand3_path;
                }
                if(ptr_predec_blk->number_gates_first_level_nand3_path < ptr_predec_blk->min_number_gates_first_level){
                    ptr_predec_blk->number_gates_first_level_nand3_path = ptr_predec_blk->min_number_gates_first_level;
                }
                //Recalculate the effective fanout of each stage 
                f = pow(F, 1.0 / ptr_predec_blk->number_gates_first_level_nand3_path);
                i = ptr_predec_blk->number_gates_first_level_nand3_path - 1;
				c_input = ptr_predec_blk->c_load_predecoder_block_output / f;
                ptr_predec_blk->width_first_level_nand3_path_n[i]  = (1.0 / 3.0) * c_input / gatecap(1, 0);
                ptr_predec_blk->width_first_level_nand3_path_p[i] = 2 * ptr_predec_blk->width_first_level_nand3_path_n[i];
				
				if( ptr_predec_blk->width_first_level_nand3_path_n[i] > MAX_NMOS_WIDTH){
					c_load = gatecap(MAX_NMOS_WIDTH + 2 * MAX_NMOS_WIDTH, 0);
					F =  gnand3 * c_load / gatecap(ptr_predec_blk->width_first_level_nand3_path_n[0] +
						ptr_predec_blk->width_first_level_nand3_path_p[0] , 0);
					ptr_predec_blk->number_gates_first_level_nand3_path = (int) (log(F) / log(fopt)) + 1;
					if(ptr_predec_blk->number_gates_first_level_nand3_path%2 != 0){
						++ptr_predec_blk->number_gates_first_level_nand3_path;
				 }
					if(ptr_predec_blk->number_gates_first_level_nand3_path < ptr_predec_blk->min_number_gates_first_level){
						ptr_predec_blk->number_gates_first_level_nand3_path = ptr_predec_blk->min_number_gates_first_level;
				 }
					f = pow(F, 1.0 / ptr_predec_blk->number_gates_first_level_nand3_path);
					i = ptr_predec_blk->number_gates_first_level_nand3_path - 1;
					ptr_predec_blk->width_first_level_nand3_path_n[i] = MAX_NMOS_WIDTH;
					ptr_predec_blk->width_first_level_nand3_path_p[i] = 2 *  ptr_predec_blk->width_first_level_nand3_path_n[i];
				}

                for(i = ptr_predec_blk->number_gates_first_level_nand3_path - 2; i >= 1; --i){
                    ptr_predec_blk->width_first_level_nand3_path_n[i] = ptr_predec_blk->width_first_level_nand3_path_n[i + 1] / f;
                    ptr_predec_blk->width_first_level_nand3_path_p[i] = 2 * ptr_predec_blk->width_first_level_nand3_path_n[i];
                }
            }
        }
    }
}


static void delay_predecoder_block(
    predecoder_block *ptr_predec_blk,
    double inrisetime_nand2_path,
    double inrisetime_nand3_path,
    double *outrisetime_nand2_path,
    double *outrisetime_nand3_path)
{
    int i;
    double   rd, c_load, c_intrinsic, tf, this_delay;
    *outrisetime_nand2_path = 0;
    *outrisetime_nand3_path = 0;
    //First check whether a predecoder block is required
    if(ptr_predec_blk->flag_block_exists){
        //Find delay in first level of predecoder block
        //First find delay in path 
        if((ptr_predec_blk->flag_two_unique_paths)||(ptr_predec_blk->number_inputs_first_level_gate == 2)){
            //First gate is a NAND2 gate
            rd = transreson(ptr_predec_blk->width_first_level_nand2_path_n[0], NCH, 2);
            c_load = gatecap(ptr_predec_blk->width_first_level_nand2_path_n[1] +
                    ptr_predec_blk->width_first_level_nand2_path_p[1], 0.0);
            c_intrinsic = 2 * draincap(ptr_predec_blk->width_first_level_nand2_path_p[0], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                draincap(ptr_predec_blk->width_first_level_nand2_path_n[0], NCH, 2, 1, DEFAULTHEIGHTCELL);
            tf = rd * (c_intrinsic + c_load);
            this_delay = horowitz(inrisetime_nand2_path, tf, 0.5, 0.5, RISE);
            ptr_predec_blk->delay_nand2_path += this_delay;
            inrisetime_nand2_path = this_delay / (1.0 - 0.5);
            ptr_predec_blk->power_nand2_path.readOp.dynamic += 
                (c_load + c_intrinsic) * vdd_periph_global * vdd_periph_global;

            //Add delays of all but the last inverter in the chain
            for(i = 1; i < ptr_predec_blk->number_gates_first_level_nand2_path - 1; ++i){
                rd = transreson(ptr_predec_blk->width_first_level_nand2_path_n[i], NCH, 1);
                c_load = gatecap(ptr_predec_blk->width_first_level_nand2_path_n[i+1] +
                        ptr_predec_blk->width_first_level_nand2_path_p[i+1], 0.0);
                c_intrinsic = draincap(ptr_predec_blk->width_first_level_nand2_path_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                    draincap(ptr_predec_blk->width_first_level_nand2_path_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load);
                this_delay = horowitz(inrisetime_nand2_path, tf, 0.5, 0.5, RISE);
                ptr_predec_blk->delay_nand2_path += this_delay;
                inrisetime_nand2_path = this_delay / (1.0 - 0.5);
                ptr_predec_blk->power_nand2_path.readOp.dynamic += (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
            }

            //Add delay of the last inverter
            i = ptr_predec_blk->number_gates_first_level_nand2_path - 1;
            rd = transreson(ptr_predec_blk->width_first_level_nand2_path_n[i], NCH, 1);
            if(ptr_predec_blk->flag_second_level_gate){
                c_load = ptr_predec_blk->branch_effort_nand2_gate_output * 
                    (gatecap(ptr_predec_blk->width_second_level_n[0], 0) + 
                     gatecap(ptr_predec_blk->width_second_level_p[0], 0));
                c_intrinsic = draincap(ptr_predec_blk->width_first_level_nand2_path_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                    draincap(ptr_predec_blk->width_first_level_nand2_path_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load);
                this_delay = horowitz(inrisetime_nand2_path, tf, 0.5, 0.5, RISE);
                ptr_predec_blk->delay_nand2_path += this_delay;
                inrisetime_nand2_path = this_delay / (1.0 - 0.5);
                ptr_predec_blk->power_nand2_path.readOp.dynamic += 
                    (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
            }
            else{//First level directly drives decoder output load
                c_load = ptr_predec_blk->c_load_predecoder_block_output;
                c_intrinsic = draincap(ptr_predec_blk->width_first_level_nand2_path_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                    draincap(ptr_predec_blk->width_first_level_nand2_path_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load) + ptr_predec_blk->r_wire_predecoder_block_output *
                    c_load / 2; 
                this_delay = horowitz(inrisetime_nand2_path, tf, 0.5, 0.5, RISE);
                ptr_predec_blk->delay_nand2_path += this_delay;
                *outrisetime_nand2_path = this_delay / (1.0 - 0.5);		
                ptr_predec_blk->power_nand2_path.readOp.dynamic += 
                    (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
            }
        }

        if((ptr_predec_blk->flag_two_unique_paths)||(ptr_predec_blk->number_inputs_first_level_gate == 3)){
            //Check if the number of gates in the first level is more than 1. 
            //First gate is a NAND3 gate
            rd = transreson(ptr_predec_blk->width_first_level_nand3_path_n[0], NCH, 3);
            c_load = gatecap(ptr_predec_blk->width_first_level_nand3_path_n[1] +
                    ptr_predec_blk->width_first_level_nand3_path_p[1], 0.0);
            c_intrinsic = 3 * draincap(ptr_predec_blk->width_first_level_nand3_path_p[0], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                draincap(ptr_predec_blk->width_first_level_nand3_path_n[0], NCH, 3, 1, DEFAULTHEIGHTCELL);
            tf = rd * (c_intrinsic + c_load);
            this_delay = horowitz(inrisetime_nand3_path, tf, 0.5, 0.5, RISE);
            ptr_predec_blk->delay_nand3_path += this_delay;
            inrisetime_nand3_path = this_delay / (1.0 - 0.5);
            ptr_predec_blk->power_nand3_path.readOp.dynamic += 
                (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;

            //Add delays of all but the last inverter in the chain
            for(i = 1; i < ptr_predec_blk->number_gates_first_level_nand3_path - 1; ++i){
                rd = transreson(ptr_predec_blk->width_first_level_nand3_path_n[i], NCH, 3);
                c_load = gatecap(ptr_predec_blk->width_first_level_nand3_path_n[i+1] +
                        ptr_predec_blk->width_first_level_nand3_path_p[i+1], 0.0);
                c_intrinsic = draincap(ptr_predec_blk->width_first_level_nand3_path_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                    draincap(ptr_predec_blk->width_first_level_nand3_path_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load);
                this_delay = horowitz(inrisetime_nand3_path, tf, 0.5, 0.5, RISE);
                ptr_predec_blk->delay_nand3_path += this_delay;
                inrisetime_nand3_path = this_delay / (1.0 - 0.5);
                ptr_predec_blk->power_nand3_path.readOp.dynamic += 
                    (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
            }

            //Add delay of the last inverter
            i = ptr_predec_blk->number_gates_first_level_nand3_path - 1;
            rd = transreson(ptr_predec_blk->width_first_level_nand3_path_n[i], NCH, 1);
            if(ptr_predec_blk->flag_second_level_gate){
                c_load = ptr_predec_blk->branch_effort_nand3_gate_output * 
                    (gatecap(ptr_predec_blk->width_second_level_n[0], 0) + 
                     gatecap(ptr_predec_blk->width_second_level_p[0], 0));
                c_intrinsic = draincap(ptr_predec_blk->width_first_level_nand3_path_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                    draincap(ptr_predec_blk->width_first_level_nand3_path_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load);
                this_delay = horowitz(inrisetime_nand3_path, tf, 0.5, 0.5, RISE);
                ptr_predec_blk->delay_nand3_path += this_delay;
                inrisetime_nand3_path = this_delay / (1.0 - 0.5);
                ptr_predec_blk->power_nand3_path.readOp.dynamic += 
                    (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
            }
            else{//First level directly drives decoder output load
                c_load = ptr_predec_blk->c_load_predecoder_block_output;
                c_intrinsic = draincap(ptr_predec_blk->width_first_level_nand3_path_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                    draincap(ptr_predec_blk->width_first_level_nand3_path_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load) + ptr_predec_blk->r_wire_predecoder_block_output *
                    c_load / 2; 
                this_delay = horowitz(inrisetime_nand3_path, tf, 0.5, 0.5, RISE);
                ptr_predec_blk->delay_nand3_path += this_delay;
                *outrisetime_nand3_path = this_delay / (1.0 - 0.5);	
                ptr_predec_blk->power_nand3_path.readOp.dynamic += 
                    (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
            }
        }	

        //Find delay through second level 
        if(ptr_predec_blk->flag_second_level_gate){
            if(ptr_predec_blk->flag_second_level_gate == 2){
                rd = transreson(ptr_predec_blk->width_second_level_n[0], NCH, 2);
                c_load = gatecap(ptr_predec_blk->width_second_level_n[1] +
                        ptr_predec_blk->width_second_level_p[1], 0.0);
                c_intrinsic = 2 * draincap(ptr_predec_blk->width_second_level_p[0], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                    draincap(ptr_predec_blk->width_second_level_n[0], NCH, 2, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load);
                this_delay = horowitz(inrisetime_nand2_path, tf, 0.5, 0.5, RISE);
                ptr_predec_blk->delay_nand2_path += this_delay;
                inrisetime_nand2_path = this_delay / (1.0 - 0.5);
                ptr_predec_blk->power_second_level.readOp.dynamic += 
                    (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
            }
            else{//flag_second_level_gate = 3)
                rd = transreson(ptr_predec_blk->width_second_level_n[0], NCH, 3);
                c_load = gatecap(ptr_predec_blk->width_second_level_n[1] +
                        ptr_predec_blk->width_second_level_p[1], 0.0);
                c_intrinsic = 3 * draincap(ptr_predec_blk->width_second_level_p[0], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                    draincap(ptr_predec_blk->width_second_level_n[0], NCH, 3, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load);
                this_delay = horowitz(inrisetime_nand3_path, tf, 0.5, 0.5, RISE);
                ptr_predec_blk->delay_nand3_path += this_delay;
                inrisetime_nand3_path = this_delay / (1.0 - 0.5);
                ptr_predec_blk->power_second_level.readOp.dynamic += 
                    (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
            }


            for(i = 1; i < ptr_predec_blk->number_gates_second_level - 1; ++i){
                rd = transreson(ptr_predec_blk->width_second_level_n[i], NCH, 1);
                c_load = gatecap(ptr_predec_blk->width_second_level_n[i+1] +
                        ptr_predec_blk->width_second_level_p[i+1], 0.0);
                c_intrinsic = draincap(ptr_predec_blk->width_second_level_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                    draincap(ptr_predec_blk->width_second_level_p[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
                tf = rd * (c_intrinsic + c_load);
                this_delay = horowitz(inrisetime_nand2_path, tf, 0.5, 0.5, RISE);
                ptr_predec_blk->delay_nand2_path += this_delay;
                inrisetime_nand2_path = this_delay / (1.0 - 0.5);
                this_delay = horowitz(inrisetime_nand3_path, tf, 0.5, 0.5, RISE);
                ptr_predec_blk->delay_nand3_path += this_delay;
                inrisetime_nand3_path = this_delay / (1.0 - 0.5);
                ptr_predec_blk->power_second_level.readOp.dynamic += 
                    (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
            }
            //Add delay of final inverter that drives the wordline decoders
            i = ptr_predec_blk->number_gates_second_level - 1;
            c_load = ptr_predec_blk->c_load_predecoder_block_output;
            rd = transreson(ptr_predec_blk->width_second_level_n[i], NCH, 1);
            c_intrinsic = draincap(ptr_predec_blk->width_second_level_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                draincap(ptr_predec_blk->width_second_level_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
            tf = rd * (c_intrinsic + c_load) + ptr_predec_blk->r_wire_predecoder_block_output *
                c_load / 2;
            this_delay = horowitz(inrisetime_nand2_path, tf, 0.5, 0.5, RISE);
            ptr_predec_blk->delay_nand2_path += this_delay;
            *outrisetime_nand2_path = this_delay / (1.0 - 0.5);	
            this_delay = horowitz(inrisetime_nand3_path, tf, 0.5, 0.5, RISE);
            ptr_predec_blk->delay_nand3_path += this_delay;
            *outrisetime_nand3_path = this_delay / (1.0 - 0.5);	
            ptr_predec_blk->power_second_level.readOp.dynamic += 
                (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
        }
    }
}


void compute_widths_decoder(int is_fa, decoder *ptr_dec)
{
    int i;
    double F, f, c_input, c_load, pmos_to_nmos_sizing_r;

	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
    if(ptr_dec->flag_decoder_exists){
        if((ptr_dec->number_input_signals == 2)||is_fa){
            ptr_dec->width_decoder_n[0] = 2 * minimum_width_nmos;
            ptr_dec->width_decoder_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
			F = gnand2 * ptr_dec->c_load_decoder_output / (gatecap(ptr_dec->width_decoder_n[0], 0) +
                    gatecap(ptr_dec->width_decoder_p[0], 0));
        }
        else{
            if(ptr_dec->number_input_signals == 3){
                ptr_dec->width_decoder_n[0] = 3 * minimum_width_nmos;
                ptr_dec->width_decoder_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
                F = gnand3 * ptr_dec->c_load_decoder_output / (gatecap(ptr_dec->width_decoder_n[0], 0) +
                        gatecap(ptr_dec->width_decoder_p[0], 0));
            }
        }
        ptr_dec->number_gates = (int) (log(F) / log(fopt));
        //Check if ptr_dec->number_gates  is odd. If it is, add 1 to make it even.
        if(ptr_dec->number_gates % 2 != 0){
            ++ptr_dec->number_gates;
        }
        if(ptr_dec->number_gates < ptr_dec->min_number_gates){
            ptr_dec->number_gates = ptr_dec->min_number_gates;
        }

        //Recalculate the effective fanout of each stage 
        f = pow(F, 1.0 / ptr_dec->number_gates);
        i = ptr_dec->number_gates - 1;
        c_input = ptr_dec->c_load_decoder_output /  f;
		ptr_dec->width_decoder_n[i] = (1.0 / 3.0) * c_input / gatecap(1, 0);
		ptr_dec->width_decoder_p[i] = 2 * ptr_dec->width_decoder_n[i];

		if(ptr_dec->width_decoder_n[i] > MAX_NMOS_WIDTH){
			c_load = gatecap(MAX_NMOS_WIDTH + 2 * MAX_NMOS_WIDTH, 0);
			if(ptr_dec->number_input_signals == 2){
				F =  gnand2 * c_load / gatecap(ptr_dec->width_decoder_n[0] +
					ptr_dec->width_decoder_p[0] , 0);
			}
			else{
				if(ptr_dec->number_input_signals == 3){
					F =  gnand3 * c_load / gatecap(ptr_dec->width_decoder_n[0] +
						ptr_dec->width_decoder_p[0], 0);
				}
			}
			ptr_dec->number_gates = (int) (log(F) / log(fopt)) + 1;
			if(ptr_dec->number_gates%2 != 0){
				++ptr_dec->number_gates;
			}
			if(ptr_dec->number_gates < ptr_dec->min_number_gates){
				ptr_dec->number_gates = ptr_dec->min_number_gates;
			}
			f = pow(F, 1.0 / ptr_dec->number_gates);
			i = ptr_dec->number_gates - 1;
			ptr_dec->width_decoder_n[i] = MAX_NMOS_WIDTH;
			ptr_dec->width_decoder_p[i] = 2 * ptr_dec->width_decoder_n[i];
		}
        
        for(i = ptr_dec->number_gates - 2; i >= 1; --i){
            ptr_dec->width_decoder_n[i] = ptr_dec->width_decoder_n[i+1] / f;
            ptr_dec->width_decoder_p[i] = 2 * ptr_dec->width_decoder_n[i];
        }
    }
}



static void delay_decoder(
    decoder *ptr_dec,
    double inrisetime,
    double *outrisetime)
{
    int i;
    double rd, tf, this_delay, c_load, c_intrinsic, vdd_wordline;
    *outrisetime = 0;
	if((is_wordline_transistor)&&((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))){
		vdd_wordline = vpp;
	}
	else if(is_wordline_transistor){
		vdd_wordline = vdd_sram_cell;
	}
	else{
		vdd_wordline = vdd_periph_global;
	}
    if(ptr_dec->flag_decoder_exists){//First check whether a decoder is required at all
        if(ptr_dec->number_input_signals == 2){
            rd = transreson(ptr_dec->width_decoder_n[0], NCH, 2);
            c_load = gatecap(ptr_dec->width_decoder_n[1] +
                    ptr_dec->width_decoder_p[1], 0.0);
            c_intrinsic = 2 * draincap(ptr_dec->width_decoder_p[1], PCH, 1, 1, 4 * height_cell) + 
                draincap(ptr_dec->width_decoder_n[1], NCH, 2, 1, 4 * height_cell);
            tf = rd * (c_intrinsic + c_load);
            this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
            ptr_dec->delay += this_delay;
            inrisetime = this_delay / (1.0 - 0.5);
            ptr_dec->power.readOp.dynamic += (c_load + c_intrinsic) * vdd_periph_global * vdd_periph_global;
        }
        else{
            if(ptr_dec->number_input_signals == 3){
                rd = transreson(ptr_dec->width_decoder_n[0], NCH, 3);
                c_load = gatecap(ptr_dec->width_decoder_n[1] +
                        ptr_dec->width_decoder_p[1], 0.0);
                c_intrinsic = 2 * draincap(ptr_dec->width_decoder_p[0], PCH, 1, 1, 4 * height_cell) + 
                    draincap(ptr_dec->width_decoder_p[0], NCH, 2, 1, 4 * height_cell);
                tf = rd * (c_intrinsic + c_load);
                this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
                ptr_dec->delay += this_delay;
                inrisetime = this_delay / (1.0 - 0.5);	
                ptr_dec->power.readOp.dynamic += (c_load + c_intrinsic) * vdd_periph_global * vdd_periph_global;
            }
        }
        for(i = 1; i < ptr_dec->number_gates - 1; ++i){
            rd = transreson(ptr_dec->width_decoder_n[i], NCH, 3);
            c_load = gatecap(ptr_dec->width_decoder_p[i+1] +
                    ptr_dec->width_decoder_n[i+1], 0.0);
            c_intrinsic = draincap(ptr_dec->width_decoder_p[i], PCH, 1, 1, 4 * height_cell) + 
                draincap(ptr_dec->width_decoder_n[i], NCH, 1, 1, 4 * height_cell);
            tf = rd * (c_intrinsic + c_load);
            this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
            ptr_dec->delay += this_delay;
            inrisetime = this_delay / (1.0 - 0.5);
            ptr_dec->power.readOp.dynamic += (c_load + c_intrinsic) * vdd_periph_global * vdd_periph_global;
        }
        //Add delay of final inverter that drives the wordline 
        i = ptr_dec->number_gates - 1;
        c_load = ptr_dec->c_load_decoder_output;
        rd = transreson(ptr_dec->width_decoder_n[i], NCH, 1);
        c_intrinsic = draincap(ptr_dec->width_decoder_p[i], PCH, 1, 1, 4 * height_cell) + 
            draincap(ptr_dec->width_decoder_n[i], NCH, 1, 1, 4 * height_cell);
        tf = rd * (c_intrinsic + c_load) + ptr_dec->r_wire_decoder_output * c_load / 2;
        this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
        ptr_dec->delay += this_delay;
        *outrisetime = this_delay / (1.0 - 0.5);
		ptr_dec->power.readOp.dynamic += c_intrinsic * vdd_periph_global * vdd_periph_global + 
			c_load * vdd_wordline * vdd_wordline;
    }
}



static void delay_comparator(
    int tagbits,
    int A,
    double inputtime,
    double  *outputtime,
    double *delay,
    powerDef *power)

{
    double Req, Ceq, tf, st1del, st2del, st3del, nextinputtime, m;
    double c1, c2, r1, r2, tstep, a, b, c, lkgCurrent;
    double Tcomparatorni;

    *delay = 0;
    power->readOp.dynamic = 0;
    power->readOp.leakage = 0;
    power->writeOp.dynamic = 0;
    power->writeOp.leakage = 0;

    tagbits = tagbits / 4;//Assuming there are 4 quarter comparators. input tagbits is already
    //a multiple of 4.

    /* First Inverter */
    Ceq = gatecap(Wcompinvn2+Wcompinvp2, 0) +
        draincap(Wcompinvp1,PCH,1, 1, DEFAULTHEIGHTCELL) + draincap(Wcompinvn1,NCH,1, 1, DEFAULTHEIGHTCELL);
    Req = transreson(Wcompinvp1,PCH,1);
    tf = Req*Ceq;
    st1del = horowitz(inputtime,tf,VTHCOMPINV,VTHCOMPINV,FALL);
    nextinputtime = st1del/VTHCOMPINV;
    power->readOp.dynamic += 0.5 * Ceq * vdd_periph_global * vdd_periph_global * 4 * A;//For each degree of associativity 
    //there are 4 such quarter comparators
    lkgCurrent = 0.5 * cmos_ileakage(Wcompinvn1, Wcompinvp1, temper) * 4 * A;

    /* Second Inverter */
    Ceq = gatecap(Wcompinvn3+Wcompinvp3, 0) +
        draincap(Wcompinvp2,PCH,1, 1, DEFAULTHEIGHTCELL) + draincap(Wcompinvn2,NCH,1, 1, DEFAULTHEIGHTCELL);
    Req = transreson(Wcompinvn2,NCH,1);
    tf = Req*Ceq;
    st2del = horowitz(nextinputtime,tf,VTHCOMPINV,VTHCOMPINV,RISE);
    nextinputtime = st2del/(1.0-VTHCOMPINV);
    power->readOp.dynamic += 0.5 * Ceq * vdd_periph_global * vdd_periph_global * 4 * A;
    lkgCurrent += 0.5 * cmos_ileakage(Wcompinvn2, Wcompinvp2, temper) * 4 * A;

    /* Third Inverter */
    Ceq = gatecap(Wevalinvn+Wevalinvp, 0) +
        draincap(Wcompinvp3,PCH,1, 1, DEFAULTHEIGHTCELL) + draincap(Wcompinvn3,NCH,1, 1, DEFAULTHEIGHTCELL);
    Req = transreson(Wcompinvp3,PCH,1);
    tf = Req*Ceq;
    st3del = horowitz(nextinputtime,tf,VTHCOMPINV,VTHEVALINV,FALL);
    nextinputtime = st3del/(VTHEVALINV);
    power->readOp.dynamic += 0.5 * Ceq * vdd_periph_global * vdd_periph_global * 4 * A;
    lkgCurrent += 0.5 * cmos_ileakage(Wcompinvn3,Wcompinvp3,  temper) * 4 * A;

    /* Final Inverter (virtual ground driver) discharging compare part */
    r1 = transreson(Wcompn,NCH,2);
    r2 = transreson(Wevalinvn,NCH,1); /* was switch */
    c2 = (tagbits)*(draincap(Wcompn,NCH,1, 1, DEFAULTHEIGHTCELL)+draincap(Wcompn,NCH,2, 1, DEFAULTHEIGHTCELL))+
        draincap(Wevalinvp,PCH,1, 1, DEFAULTHEIGHTCELL) + draincap(Wevalinvn,NCH,1, 1, DEFAULTHEIGHTCELL);
    c1 = (tagbits)*(draincap(Wcompn,NCH,1, 1, DEFAULTHEIGHTCELL)+draincap(Wcompn,NCH,2, 1, DEFAULTHEIGHTCELL))
        +draincap(Wcompp,PCH,1, 1, DEFAULTHEIGHTCELL) + gatecap(WmuxdrvNANDn+WmuxdrvNANDp,0);
    power->readOp.dynamic += 0.5 * c2 * vdd_periph_global * vdd_periph_global * 4 * A;
    power->readOp.dynamic += c1 * vdd_periph_global * vdd_periph_global *  (A - 1);
    lkgCurrent += 0.5 * cmos_ileakage(Wevalinvn,Wevalinvp, temper) * 4 * A;
    lkgCurrent += 0.2 * 0.5 * cmos_ileakage(Wcompn,Wcompp, temper) * 4 * A;//stack factor of 0.2

    /* time to go to threshold of mux driver */
    tstep = (r2*c2+(r1+r2)*c1)*log(1.0/VTHMUXNAND);
    /* take into account non-zero input rise time */
    m = vdd_periph_global/nextinputtime;

    if((tstep) <= (0.5*(vdd_periph_global-v_th_periph_global)/m)) {
        a = m;
        b = 2*((vdd_periph_global*VTHEVALINV)-v_th_periph_global);
        c = -2*(tstep)*(vdd_periph_global-v_th_periph_global)+1/m*((vdd_periph_global*VTHEVALINV)-v_th_periph_global)*((vdd_periph_global*VTHEVALINV)-v_th_periph_global);
        Tcomparatorni = (-b+sqrt(b*b-4*a*c))/(2*a);
    }
    else{
        Tcomparatorni = (tstep) + (vdd_periph_global+v_th_periph_global)/(2*m) - (vdd_periph_global*VTHEVALINV)/m;
    }
    *outputtime = Tcomparatorni/(1.0-VTHMUXNAND);
    *delay = Tcomparatorni+st1del+st2del+st3del;
    power->readOp.leakage = lkgCurrent * vdd_periph_global;
}



double objective_function(int flag_opt_for_dynamic_energy, int flag_opt_for_dynamic_power, int flag_opt_for_leakage_power,
        int flag_opt_for_cycle_time, double dynamic_energy_weight, double dynamic_power_weight, 
        double leakage_power_weight, double cycle_time_weight, double dyn_energy_wrt_min_dynamic_energy, 
        double dyn_power_wrt_min_dyn_power, double leak_power_wrt_min_leak_power, 
        double cycle_time_wrt_min_cycle_time)
{
    double t = (double)(dyn_energy_wrt_min_dynamic_energy * flag_opt_for_dynamic_energy * dynamic_energy_weight +
                 dyn_power_wrt_min_dyn_power * flag_opt_for_dynamic_power * dynamic_power_weight + 
                 leak_power_wrt_min_leak_power * flag_opt_for_leakage_power * leakage_power_weight + 
                 cycle_time_wrt_min_cycle_time * flag_opt_for_cycle_time * cycle_time_weight);
    return t;
}



double bitline_delay(int number_rows_subarray, int number_cols_subarray, int number_subarrays, 
					 double inrisetime, double *outrisetime,powerDef *power, double *per_bitline_read_energy, 
					 int deg_bitline_muxing, int deg_senseamp_muxing, int number_activated_mats_horizontal_direction, 
					 double *writeback_delay, int RWP, int ERP, int EWP)
{
 
    double Tbit, tau, v_bitline_precharge, v_th_mem_cell, v_wordline;
    double m, tstep;
	double dynRdEnergy = 0.0, dynWriteEnergy = 0.0;
    double Icell, Iport;
    double Cbitrow_drain_capacitance, R_cell_pull_down, R_cell_acc, Cbitline, 
		Rbitline, C_drain_bit_mux, R_bit_mux, C_drain_sense_amp_iso, R_sense_amp_iso, 
		C_sense_amp_latch, C_drain_sense_amp_mux, r_dev;
	double leakage_power_cc_inverters_sram_cell, 
		leakage_power_access_transistors_read_write_or_write_only_port_sram_cell,
		leakage_power_read_only_port_sram_cell, fraction;

	*writeback_delay  = 0;
	leakage_power_cc_inverters_sram_cell = 0;
	leakage_power_access_transistors_read_write_or_write_only_port_sram_cell = 0;
	leakage_power_read_only_port_sram_cell = 0;

	if((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)){
		v_bitline_precharge = Vbitpre_dram;
		v_th_mem_cell = v_th_dram_access_transistor;
		v_wordline = vpp;
		is_cell = 1;
		Cbitrow_drain_capacitance = draincap(Wmemcella_dram, NCH, 1, 0, width_cell) / 2.0;	/*due to shared contact*/ 
		//The access transistor is not folded. So we just need to specify a theshold value for the
		//folding width that is equal to or greater than Wmemcella. 
		R_cell_acc = transreson(Wmemcella_dram, NCH, 1);
		is_cell = 0;
		if(ram_cell_tech_flavor == 4){
			Cbitline = number_rows_subarray * Cbitmetal ;
		}
		else{
			Cbitline = number_rows_subarray * Cbitrow_drain_capacitance + number_rows_subarray * 
			Cbitmetal ;
		}
		Rbitline = 0;
		Rbitline = number_rows_subarray * Rbitmetal;
		r_dev = vdd_dram_cell / I_on_dram_cell + Rbitline / 2;
	}
	else{//SRAM
		v_bitline_precharge = Vbitpre_sram;
		v_th_mem_cell = v_th_sram_cell_transistor;
		v_wordline = vdd_sram_cell;
		 is_cell = 1; 
		 Cbitrow_drain_capacitance = draincap(Wmemcella_sram, NCH, 1, 0, width_cell) / 2.0;	/* due to shared contact */
		 R_cell_pull_down = transreson(Wmemcellnmos_sram, NCH, 1);
		 R_cell_acc = transreson(Wmemcella_sram, NCH, 1);
		 Cbitline = number_rows_subarray * (Cbitrow_drain_capacitance + Cbitmetal);
	     //Leakage current of an SRAM cell
		 Iport = cmos_ileakage(Wmemcella_sram, 0,  temper); 
		 Icell = cmos_ileakage(Wmemcellnmos_sram, Wmemcellpmos_sram, temper);
		 is_cell = 0; 
		 leakage_power_cc_inverters_sram_cell = Icell * vdd_sram_cell;
		 leakage_power_access_transistors_read_write_or_write_only_port_sram_cell = Iport * vdd_sram_cell;
		 leakage_power_read_only_port_sram_cell = 
			 leakage_power_access_transistors_read_write_or_write_only_port_sram_cell *
				 NAND2_LEAK_STACK_FACTOR;
	}

  
	Rbitline = number_rows_subarray * Rbitmetal;
	C_drain_bit_mux = draincap(width_nmos_bit_mux, NCH, 1, 0, width_cell / (2 *(RWP + ERP + RWP)));
	R_bit_mux = transreson(width_nmos_bit_mux, NCH, 1);
	C_drain_sense_amp_iso = draincap(Wiso, PCH, 1, 0, width_cell * deg_bitline_muxing / (RWP + ERP));
	R_sense_amp_iso = transreson(Wiso, PCH, 1);
	C_sense_amp_latch = gatecap(WsenseP + WsenseN, 0) + draincap(WsenseN, NCH, 1, 0, width_cell * deg_bitline_muxing / (RWP + ERP)) + 
		draincap(WsenseP, PCH, 1, 0, width_cell * deg_bitline_muxing / (RWP + ERP));
	C_drain_sense_amp_mux = draincap(width_nmos_sense_amp_mux, NCH, 1, 0, width_cell * deg_bitline_muxing / (RWP + ERP));
	if((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)){
		fraction = Vbitsense / ((vdd_dram_cell/2) * c_dram_cell /(c_dram_cell + Cbitline));
		//fraction = 1;
		tstep = 2.3 * fraction * r_dev * (c_dram_cell * (Cbitline + 2 * C_drain_sense_amp_iso + 
			C_sense_amp_latch + C_drain_sense_amp_mux)) / (c_dram_cell + (Cbitline + 2 * 
			C_drain_sense_amp_iso + C_sense_amp_latch + C_drain_sense_amp_mux));
		*writeback_delay = tstep;
		dynRdEnergy +=  (Cbitline + 2 * C_drain_sense_amp_iso + 
			C_sense_amp_latch + C_drain_sense_amp_mux) * 
            (vdd_dram_cell / 2 )* vdd_dram_cell * number_cols_subarray * 4 *  number_activated_mats_horizontal_direction;
		dynWriteEnergy += (number_cols_subarray * 4  *	number_activated_mats_horizontal_direction * Cbitline + 2 * C_drain_bit_mux) * (vdd_dram_cell / 2) * vdd_dram_cell;
		*per_bitline_read_energy = (Cbitline + 2 * C_drain_sense_amp_iso + 
			C_sense_amp_latch + C_drain_sense_amp_mux) *  (vdd_dram_cell / 2) * vdd_dram_cell;
	}
	else{
		Vbitsense = (0.05 * vdd_sram_cell > VBITSENSEMIN) ? 0.05 * vdd_sram_cell : VBITSENSEMIN;
		if(deg_bitline_muxing > 1){
			tau = (R_cell_pull_down + R_cell_acc) * (Cbitline + 2 * C_drain_bit_mux + 
				2 * C_drain_sense_amp_iso + C_sense_amp_latch + C_drain_sense_amp_mux) + Rbitline * 
				(Cbitline / 2 + 2 * C_drain_bit_mux + 	2 * C_drain_sense_amp_iso + C_sense_amp_latch +
				C_drain_sense_amp_mux)+ R_bit_mux * (C_drain_bit_mux + 2 * C_drain_sense_amp_iso +
				C_sense_amp_latch + C_drain_sense_amp_mux) + R_sense_amp_iso * (C_drain_sense_amp_iso + C_sense_amp_latch + 
				C_drain_sense_amp_mux);
			dynRdEnergy += (Cbitline + 2 * C_drain_bit_mux) * 2 * Vbitsense * vdd_sram_cell * 
				number_cols_subarray * 4 * number_activated_mats_horizontal_direction;
			dynRdEnergy += (C_drain_sense_amp_iso +	C_sense_amp_latch +	C_drain_sense_amp_mux) * 
				2 * Vbitsense * vdd_sram_cell * (number_cols_subarray * 4 / deg_bitline_muxing) *
				number_activated_mats_horizontal_direction;
		}
		else{//deg_bitline_muxing == 1
			tau = (R_cell_pull_down + R_cell_acc) * (Cbitline + C_drain_sense_amp_iso +
				C_sense_amp_latch + C_drain_sense_amp_mux) + Rbitline * Cbitline / 2 + 
				R_sense_amp_iso * (C_drain_sense_amp_iso + C_sense_amp_latch + 	C_drain_sense_amp_mux);
			dynRdEnergy += (Cbitline + C_drain_sense_amp_iso + C_sense_amp_latch + 
				C_drain_sense_amp_mux) * 2 * Vbitsense * vdd_sram_cell * number_cols_subarray * 4 * 
				number_activated_mats_horizontal_direction;
		}
		tstep = tau * log(v_bitline_precharge / (v_bitline_precharge - Vbitsense));
		dynWriteEnergy += (((number_cols_subarray * 4 / deg_bitline_muxing) / deg_senseamp_muxing) *
				number_activated_mats_horizontal_direction * Cbitline + 2 * C_drain_bit_mux) * vdd_sram_cell * vdd_sram_cell;
		//power->readOp.leakage = (Icell + Iport) * vdd_sram_cell;
		power->readOp.leakage = leakage_power_cc_inverters_sram_cell + 
			leakage_power_access_transistors_read_write_or_write_only_port_sram_cell + 
			leakage_power_access_transistors_read_write_or_write_only_port_sram_cell * 
			(RWP + EWP -1) + leakage_power_read_only_port_sram_cell * ERP;
	}
	
  
    /* take input rise time into account */
    m = v_wordline / inrisetime;
    if (tstep <= (0.5 * (v_wordline - v_th_mem_cell) / m))
	{
		Tbit = sqrt(2 * tstep * (v_wordline - v_th_mem_cell)/ m);
    }
    else
    {
        Tbit = tstep + (v_wordline - v_th_mem_cell) / (2 * m);
    }

	power->readOp.dynamic = dynRdEnergy;
	power->writeOp.dynamic = dynWriteEnergy;
    *outrisetime = 0;
	return(Tbit);
}



void delay_sense_amplifier(int number_cols_subarray, int RWP, int ERP, double inrisetime,double *outrisetime, powerDef *power, 
        dataout_htree_node *ptr_htree_node, int deg_bitline_muxing, int number_mats,
        int number_activated_mats_horizontal_direction,  double *delay, double *leak_power_sense_amps_closed_page_state, 
		double *leak_power_sense_amps_open_page_state)
{
    double c_load;
    int  number_sense_amps_subarray;
    double IsenseEn, IsenseN, IsenseP, Iiso;
    double lkgIdlePh, lkgReadPh, lkgWritePh;
    double lkgRead, lkgIdle;
    //v5.0
    double  tau;
    number_sense_amps_subarray = number_cols_subarray / deg_bitline_muxing;//in a subarray

    //Bitline circuitry leakage. 
    Iiso = simplified_pmos_leakage(Wiso, temper);
    IsenseEn = simplified_nmos_leakage(WsenseEn, temper);
    IsenseN  = simplified_nmos_leakage(WsenseN, temper);
    IsenseP  = simplified_pmos_leakage(WsenseP, temper);


    lkgIdlePh = IsenseEn;//+ 2*IoBufP;
    lkgWritePh = Iiso + IsenseEn;// + 2*IoBufP + 2*Ipch;
    lkgReadPh = Iiso + IsenseN + IsenseP;//+ IoBufN + IoBufP + 2*IsPch ;
    lkgRead = lkgReadPh * number_sense_amps_subarray * 4 * number_activated_mats_horizontal_direction + 
		lkgIdlePh * number_sense_amps_subarray * 4 *
		(number_mats - number_activated_mats_horizontal_direction);
	lkgIdle = lkgIdlePh * number_sense_amps_subarray * 4 * number_mats;

	*leak_power_sense_amps_closed_page_state = lkgIdlePh * vdd_periph_global * number_sense_amps_subarray * 4;
	*leak_power_sense_amps_open_page_state = lkgReadPh * vdd_periph_global * number_sense_amps_subarray * 4;
    // sense amplifier has to drive logic in "data out driver" and sense precharge load.
    // load seen by sense amp. New delay model for sense amp that is sensitive to both the output time 
    //constant as well as the magnitude of input differential voltage.
    *delay = 0;
    *outrisetime = 0;
    power->readOp.dynamic = 0;
    power->readOp.leakage = 0;
    power->writeOp.dynamic = 0;
    power->writeOp.leakage = 0;
    c_load = gatecap(WsenseP + WsenseN, 0) + draincap(WsenseN, NCH, 1, 0, width_cell * deg_bitline_muxing / (RWP + ERP)) + 
		draincap(WsenseP, PCH, 1, 0, width_cell * deg_bitline_muxing / (RWP + ERP)) +
		draincap(Wiso,PCH,1, 0, width_cell * deg_bitline_muxing / (RWP + ERP)) + 
		draincap(width_nmos_sense_amp_mux, NCH, 1, 0, width_cell * deg_bitline_muxing / (RWP + ERP));
    tau = c_load / Gm_sense_amp_latch;
    *delay = tau * log(vdd_periph_global / Vbitsense);
    power->readOp.dynamic = c_load * vdd_periph_global * vdd_periph_global * number_sense_amps_subarray * 4 * 
		number_activated_mats_horizontal_direction;
    power->readOp.leakage = lkgIdle * vdd_periph_global;
}

void delay_output_driver_at_subarray(int deg_bitline_muxing, int deg_sense_amp_muxing_level_1, int deg_sense_amp_muxing_level_2, int RWP, int ERP,
									 double inrisetime, double *outrisetime, powerDef *power,
									 dataout_htree_node *ptr_htree_node, int number_mats,
									 double *delay, double *delay_final_stage_subarray_output_driver)
{
    int j, flag_final_stage_subarray_output_driver;
    double c_load, rd, tf, this_delay, c_intrinsic, pmos_to_nmos_sizing_r;

    reset_powerDef(power);
    *delay = 0;
    *delay_final_stage_subarray_output_driver = 0;
    flag_final_stage_subarray_output_driver = 0;

	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
	//Delay of signal through pass-transistor of first level of sense-amp mux to input of inverter-buffer.
	rd = transreson(width_nmos_sense_amp_mux, NCH, 1);
	c_load = deg_sense_amp_muxing_level_1 * draincap(width_nmos_sense_amp_mux, NCH, 1, 0, width_cell * deg_bitline_muxing / (RWP + ERP)) + 
		gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0.0);
	tf = rd * c_load;
	this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
	*delay += this_delay;
	inrisetime = this_delay/(1.0 - 0.5);
	power->readOp.dynamic += c_load * 0.5 * vdd_periph_global * vdd_periph_global;
	power->readOp.leakage += 0;//for now, let leakage of the pass transistor be 0
	//Delay of signal through inverter-buffer to second level of sense-amp mux.
	//Internal delay of buffer
	rd = transreson(minimum_width_nmos, NCH, 1);
	c_load = draincap(minimum_width_nmos, NCH, 1, 1, DEFAULTHEIGHTCELL) + draincap(pmos_to_nmos_sizing_r * minimum_width_nmos, PCH, 1, 1, DEFAULTHEIGHTCELL) +
		gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0.0);
	tf = rd * c_load;
	this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
	*delay += this_delay;
	inrisetime = this_delay/(1.0 - 0.5);
	power->readOp.dynamic += c_load * 0.5 * vdd_periph_global * vdd_periph_global;
	power->readOp.leakage += cmos_ileakage(minimum_width_nmos, pmos_to_nmos_sizing_r * minimum_width_nmos, temper) * 0.5 * vdd_periph_global;
	//Inverter driving drain of pass transistor of second level of sense-amp mux.
	rd = transreson(minimum_width_nmos, NCH, 1);
	c_load = draincap(minimum_width_nmos, NCH, 1, 1, DEFAULTHEIGHTCELL) + draincap(pmos_to_nmos_sizing_r * minimum_width_nmos, PCH, 1, 1, DEFAULTHEIGHTCELL) +
		 draincap(width_nmos_sense_amp_mux, NCH, 1, 0, width_cell * deg_bitline_muxing * deg_sense_amp_muxing_level_1 / (RWP + ERP));
	tf = rd * c_load;
	this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
	*delay += this_delay;
	inrisetime = this_delay/(1.0 - 0.5);
	power->readOp.dynamic += c_load * 0.5 * vdd_periph_global * vdd_periph_global;
	power->readOp.leakage += cmos_ileakage(minimum_width_nmos, pmos_to_nmos_sizing_r * minimum_width_nmos, temper) * 0.5 * vdd_periph_global;
	////Delay of signal through pass-transistor of second level of sense-amp mux to the input of subarray output driver
	rd = transreson(width_nmos_sense_amp_mux, NCH, 1);
	c_load = deg_sense_amp_muxing_level_2 * draincap(width_nmos_sense_amp_mux, NCH, 1, 0, width_cell * deg_bitline_muxing * deg_sense_amp_muxing_level_1 / (RWP + ERP)) + gatecap(ptr_htree_node->width_n[0] + 
		ptr_htree_node->width_p[0] + ptr_htree_node->width_nor2_n + ptr_htree_node->width_nor2_p, 0.0);
	tf = rd * c_load;
	this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
	*delay += this_delay;
	inrisetime = this_delay/(1.0 - 0.5);
	power->readOp.dynamic += c_load * 0.5 * vdd_periph_global * vdd_periph_global;
	power->readOp.leakage += 0;//for now, let leakage of the pass transistor be 0


    for(j = 0; j < ptr_htree_node->number_gates; ++j){
        if(j == 0){//NAND2 gate
			rd = transreson(ptr_htree_node->width_n[j], NCH, 2);
			if(ptr_htree_node->number_gates ==2){
				c_load = gatecap(ptr_htree_node->width_p[j+1], 0.0);//NAND2 drives PMOS of output stage
			}
			else{
				c_load = gatecap(ptr_htree_node->width_n[j+1] + ptr_htree_node->width_p[j+1], 0.0);//NAND2 drives inverter
			}
            c_intrinsic = draincap(ptr_htree_node->width_n[j], NCH, 2, 1, DEFAULTHEIGHTCELL) + 
                2 * draincap(ptr_htree_node->width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL);
            tf = rd * (c_intrinsic + c_load);
            power->readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
            power->readOp.leakage += cmos_ileakage(ptr_htree_node->width_n[j], 
                    ptr_htree_node->width_p[j],  temper) * 0.5 * vdd_periph_global;
			power->readOp.leakage += cmos_ileakage(ptr_htree_node->width_nor2_n, 
					ptr_htree_node->width_nor2_p, temper) * 0.5 * vdd_periph_global;
        }
        else if(j == ptr_htree_node->number_gates - 1){//PMOS
			flag_final_stage_subarray_output_driver = 1;
			rd = transreson(ptr_htree_node->width_p[j], PCH, 1);
			c_load = ptr_htree_node->c_wire_load + ptr_htree_node->c_gate_load;
			c_intrinsic = draincap(ptr_htree_node->width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
				draincap(ptr_htree_node->width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
			tf = rd * (c_intrinsic + c_load) + ptr_htree_node->r_wire_load * 
				(ptr_htree_node->c_wire_load / 2 + ptr_htree_node->c_gate_load +
				draincap(ptr_htree_node->width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL) + 
				draincap(ptr_htree_node->width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL));
			power->readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
			power->readOp.leakage += cmos_ileakage(ptr_htree_node->width_n[j], 
				ptr_htree_node->width_p[j], temper) * 0.5 * vdd_periph_global;
			flag_final_stage_subarray_output_driver = 1;
		}
		else{//inverter
			rd = transreson(ptr_htree_node->width_n[j], NCH, 1);
			if(j == ptr_htree_node->number_gates - 2){//inverter driving PMOS of output stage
				c_load = gatecap(ptr_htree_node->width_p[j+1], 0.0);
			}
			else{//inverter driving inverter
				c_load = gatecap(ptr_htree_node->width_n[j+1] + ptr_htree_node->width_p[j+1], 0.0);
			}
			c_intrinsic = draincap(ptr_htree_node->width_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
				draincap(ptr_htree_node->width_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
			tf = rd * (c_intrinsic + c_load);
			power->readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
			power->readOp.leakage += cmos_ileakage(ptr_htree_node->width_n[j] + ptr_htree_node->width_n[j] / 2, 
				ptr_htree_node->width_p[j] + ptr_htree_node->width_p[j] /2, temper) * 0.5 * vdd_periph_global;
		}
        this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
        *delay += this_delay;
        if(flag_final_stage_subarray_output_driver){
            *delay_final_stage_subarray_output_driver = this_delay;
        }
        inrisetime = this_delay/(1.0 - 0.5);
    }

    *outrisetime = inrisetime;

}

void delay_routing_to_bank(
    int number_repeaters_htree_route_to_bank,
    double length_htree_route_to_bank,
    double sizing_repeater_htree_route_to_bank,
    double inrisetime,
    double *outrisetime,  
    double *delay,
    powerDef *power)
{
    double rd, c_intrinsic, c_load, r_wire, tf, this_delay, pmos_to_nmos_sizing_r;
    int i;
    *delay = 0;

	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
    //Add delay of cascade of inverters that drives the first repeater. FIX this.
    if(length_htree_route_to_bank > 0){
        for(i = 0; i < number_repeaters_htree_route_to_bank; ++i){
            rd = transreson(sizing_repeater_htree_route_to_bank * minimum_width_nmos, NCH, 1);
            c_intrinsic = draincap(sizing_repeater_htree_route_to_bank * pmos_to_nmos_sizing_r * minimum_width_nmos, PCH, 1, 1, DEFAULTHEIGHTCELL) + 
                draincap(sizing_repeater_htree_route_to_bank * minimum_width_nmos, NCH, 1, 1, DEFAULTHEIGHTCELL);
            c_load = sizing_repeater_htree_route_to_bank * gatecap(minimum_width_nmos +
				pmos_to_nmos_sizing_r * minimum_width_nmos, 0);
            //The last repeater actually sees the load at the input of the bank as well. FIX this.
            //if(i == number_repeaters_htree_route_to_bank - 1){
            //c_load = ptr_intcnt_seg->c_gate_load;
            //}

            r_wire = (length_htree_route_to_bank / number_repeaters_htree_route_to_bank) *
                wire_outside_mat_r_per_micron;
            tf = rd * c_intrinsic + (rd + r_wire) * c_load;
            this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
            *delay += this_delay;
            inrisetime = this_delay / (1.0 - 0.5);	
            power->readOp.dynamic += (c_intrinsic + c_load) * 0.5 *	vdd_periph_global * vdd_periph_global;
            power->readOp.leakage += cmos_ileakage(
                    sizing_repeater_htree_route_to_bank * minimum_width_nmos,
                    sizing_repeater_htree_route_to_bank * pmos_to_nmos_sizing_r * minimum_width_nmos,  temper) * 0.5 * vdd_periph_global;
		}
		//From Ron Ho's thesis, energy-delay optimal repeaters improve dynamic energy approximately by 
		//30% at the expense of approx 10% increase in delay. We simply apply this correction at the end here. 
		//Assuming that leakage also improves by 30%. Doing it like this not right. FIX this - arrive at these numbers by deriving sizing, number of
		//repeaters....
		//*delay = 1.1 * (*delay);
		//power->readOp.dynamic = 0.7 * power->readOp.dynamic;
		//power->readOp.leakage = 0.7 * power->readOp.leakage;
    }
    *outrisetime = inrisetime;
}


/*double precharge_delay(decoder *ptr_row_dec, double worddata)
{
    double Ceq, tf, pretime;
    int i;*/

    /* as discussed in the tech report, the delay is the delay of
       4 inverter delays (each with fanout of 4) plus the delay of
       the wordline */

    /*i = ptr_row_dec->number_gates - 1;
    Ceq = draincap (ptr_row_dec->width_decoder_n[i], NCH, 1) + draincap (ptr_row_dec->width_decoder_p[i], PCH, 1) +
        4 * gatecap (ptr_row_dec->width_decoder_n[i]+ ptr_row_dec->width_decoder_p[i], 0.0);
    tf = Ceq * transreson (ptr_row_dec->width_decoder_n[i], NCH, 1);
    pretime = 4 * horowitz (0.0, tf, 0.5, 0.5, RISE) + worddata;

    return (pretime);
}*/


void initialize_driver(driver *ptr_driver)
{
	int i;
	ptr_driver->delay = 0;
	ptr_driver->power.readOp.dynamic = 0;
	ptr_driver->power.readOp.leakage = 0;
	ptr_driver->power.writeOp.dynamic = 0;
	ptr_driver->power.writeOp.leakage = 0;
	ptr_driver->min_number_gates = 2;
	for(i = 0; i < MAX_NUMBER_GATES_STAGE; ++i){
		ptr_driver->width_n[i] = 0;
		ptr_driver->width_p[i] = 0;
	}
}

void compute_widths_driver(driver *ptr_driver)
{ 
	double c_load, f, F, c_input, pmos_to_nmos_sizing_r;
	int i;

	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
	c_load = ptr_driver->c_gate_load + ptr_driver->c_wire_load;
	ptr_driver->width_n[0] = minimum_width_nmos;
	ptr_driver->width_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
	F = c_load / gatecap(ptr_driver->width_n[0] + ptr_driver->width_p[0], 0);
	ptr_driver->number_gates = (int) (log(F) / log(fopt));
	f = pow(F, 1.0 / ptr_driver->number_gates);
	if(ptr_driver->number_gates%2 != 0){
            ++ptr_driver->number_gates;
	}
	if(ptr_driver->number_gates < ptr_driver->min_number_gates){
		ptr_driver->number_gates = ptr_driver->min_number_gates;
	}
	f = pow(F, 1.0 / ptr_driver->number_gates);

	i = ptr_driver->number_gates - 1;
	c_input = c_load /  f;
	ptr_driver->width_n[i] = (1.0 / 3.0) * c_input / gatecap(1, 0);
	ptr_driver->width_p[i] = 2 * ptr_driver->width_n[i];

	if(ptr_driver->width_n[i] > MAX_NMOS_WIDTH){
		c_load = gatecap(MAX_NMOS_WIDTH + 2 * MAX_NMOS_WIDTH, 0);
		F = c_load / gatecap(ptr_driver->width_n[0] + ptr_driver->width_p[0], 0);
		ptr_driver->number_gates = (int) (log(F) / log(fopt)) + 1;
		if(ptr_driver->number_gates%2 != 0){
				++ptr_driver->number_gates;
		}
		if(ptr_driver->number_gates < ptr_driver->min_number_gates){
			ptr_driver->number_gates = ptr_driver->min_number_gates;
		}
		f = pow(F, 1.0 / ptr_driver->number_gates);
		i = ptr_driver->number_gates - 1;
		ptr_driver->width_n[i] = MAX_NMOS_WIDTH;
		ptr_driver->width_p[i] = 2 * ptr_driver->width_n[i];
	}

	for(i = ptr_driver->number_gates - 2; i >= 1; --i){
		ptr_driver->width_n[i] = ptr_driver->width_n[i+1] / f;
		ptr_driver->width_p[i] = 2 * ptr_driver->width_n[i];
	}
}

void delay_driver(driver *ptr_driver, double inrisetime, double *outrisetime)
{
	int i;
    double rd, c_load, c_intrinsic, tf, this_delay;
    this_delay = 0;
	for(i = 0; i < ptr_driver->number_gates - 1; ++i){
		rd = transreson(ptr_driver->width_n[i], NCH, 1);
		c_load = gatecap(ptr_driver->width_n[i+1] + ptr_driver->width_p[i+1], 0.0);
		c_intrinsic = draincap(ptr_driver->width_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) +  
			draincap(ptr_driver->width_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
		tf = rd * (c_intrinsic + c_load);
		this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
		ptr_driver->delay += this_delay;
		inrisetime = this_delay / (1.0 - 0.5);
		ptr_driver->power.readOp.dynamic += (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
		ptr_driver->power.readOp.leakage += cmos_ileakage(ptr_driver->width_n[i], 
			ptr_driver->width_p[i], temper) * 0.5 * vdd_periph_global;
    }
	i = ptr_driver->number_gates - 1;
	c_load = ptr_driver->c_gate_load + ptr_driver->c_wire_load;
	rd = transreson(ptr_driver->width_n[i], NCH, 1);
	c_intrinsic = draincap(ptr_driver->width_p[i], PCH, 1, 1, DEFAULTHEIGHTCELL) +  
		draincap(ptr_driver->width_n[i], NCH, 1, 1, DEFAULTHEIGHTCELL);
	tf = rd * (c_intrinsic + c_load) + ptr_driver->r_wire_load * (ptr_driver->c_wire_load  / 2 +
		ptr_driver->c_gate_load);
	this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
	ptr_driver->delay += this_delay;
	*outrisetime = this_delay / (1.0 - 0.5);
	ptr_driver->power.readOp.dynamic += (c_intrinsic + c_load) * vdd_periph_global * vdd_periph_global;
	ptr_driver->power.readOp.leakage += cmos_ileakage(ptr_driver->width_n[i], ptr_driver->width_p[i],
		temper) * 0.5 * vdd_periph_global;
}


void initialize_crossbar(crossbar* ptr_crossbar, int number_input_ports, int number_output_ports, int number_signals_per_port, double c_output_line_load)
{
	double nand2_gate_cap, input_gate_cap, pmos_to_nmos_sizing_r;

	ptr_crossbar->number_input_ports = number_input_ports;
	ptr_crossbar->number_output_ports = number_output_ports;
	ptr_crossbar->number_signals_per_port = number_signals_per_port;
	ptr_crossbar->c_output_line_load = c_output_line_load;
    ptr_crossbar->min_number_gates = 2;
	ptr_crossbar->delay = 0;
	ptr_crossbar->power.readOp.dynamic = 0;
	ptr_crossbar->power.readOp.leakage = 0;
	ptr_crossbar->power.writeOp.dynamic = 0;
	ptr_crossbar->power.writeOp.leakage = 0;
	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();

	ptr_crossbar->width_output_line_tristate_buffer_n[0] = 2 * minimum_width_nmos;
	ptr_crossbar->width_output_line_tristate_buffer_p[0] = pmos_to_nmos_sizing_r * minimum_width_nmos;
	nand2_gate_cap = gatecap(ptr_crossbar->width_output_line_tristate_buffer_n[0] + ptr_crossbar->width_output_line_tristate_buffer_p[0], 0);
	input_gate_cap = gnor2 * gnmos * nand2_gate_cap / (gnand2 * gpmos);
	ptr_crossbar->width_output_line_tristate_buffer_nor2_n = (1 / (1 + 2 * pmos_to_nmos_sizing_r)) * input_gate_cap / gatecap(1, 0);
	if(ptr_crossbar->width_output_line_tristate_buffer_nor2_n < minimum_width_nmos){
		ptr_crossbar->width_output_line_tristate_buffer_nor2_n = minimum_width_nmos;
	}
	ptr_crossbar->width_output_line_tristate_buffer_nor2_p = 2 * pmos_to_nmos_sizing_r * ptr_crossbar->width_output_line_tristate_buffer_nor2_n;
}


compute_widths_crossbar(crossbar* ptr_crossbar)
{
	//Compute widths of tristate buffer driving output line
	double G, B, H, F, f, c_output_line_wire_load, c_load, c_input, pmos_to_nmos_sizing_r;
	int j;

	B = 1;
    G = gnand2 * gpmos;
	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
	c_output_line_wire_load = wire_outside_mat_pitch * ptr_crossbar->number_signals_per_port * ptr_crossbar->number_input_ports * wire_outside_mat_c_per_micron;
	c_load = ptr_crossbar->c_output_line_load + c_output_line_wire_load;
	H = c_load / gatecap(ptr_crossbar->width_output_line_tristate_buffer_n[0] + ptr_crossbar->width_output_line_tristate_buffer_p[0] , 0);
	F = G * B * H;
	ptr_crossbar->number_gates_output_line_tristate_buffer = (int) (log(F) / log(fopt));
	if(ptr_crossbar->number_gates_output_line_tristate_buffer%2 != 0){
		++ptr_crossbar->number_gates_output_line_tristate_buffer;
	}
	if(ptr_crossbar->number_gates_output_line_tristate_buffer < ptr_crossbar->min_number_gates){
		ptr_crossbar->number_gates_output_line_tristate_buffer = ptr_crossbar->min_number_gates;
	}
	f = pow(F, 1.0 / ptr_crossbar->number_gates_output_line_tristate_buffer);
	j = ptr_crossbar->number_gates_output_line_tristate_buffer - 1;
	ptr_crossbar->width_output_line_tristate_buffer_p[j] = gpmos * c_load /(f * gatecap(1, 0));
	if(ptr_crossbar->width_output_line_tristate_buffer_p[j] < pmos_to_nmos_sizing_r * minimum_width_nmos){
		ptr_crossbar->width_output_line_tristate_buffer_p[j] = pmos_to_nmos_sizing_r * minimum_width_nmos;
	}
	ptr_crossbar->width_output_line_tristate_buffer_n[j] = ptr_crossbar->width_output_line_tristate_buffer_p[j] / pmos_to_nmos_sizing_r;

	if(ptr_crossbar->width_output_line_tristate_buffer_p[j] > pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH){
		c_load = gatecap(pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH + MAX_NMOS_WIDTH, 0);
		F =  gnand2 * c_load / gatecap(ptr_crossbar->width_output_line_tristate_buffer_n[0] + ptr_crossbar->width_output_line_tristate_buffer_p[0], 0);
		ptr_crossbar->number_gates_output_line_tristate_buffer = (int) (log(F) / log(fopt)) + 1;
		if(ptr_crossbar->number_gates_output_line_tristate_buffer%2 != 0){
			++ptr_crossbar->number_gates_output_line_tristate_buffer;
		}
		if(ptr_crossbar->number_gates_output_line_tristate_buffer < ptr_crossbar->min_number_gates){
			ptr_crossbar->number_gates_output_line_tristate_buffer = ptr_crossbar->min_number_gates;
		}
		f = pow(F, 1.0 / ptr_crossbar->number_gates_output_line_tristate_buffer);
		j = ptr_crossbar->number_gates_output_line_tristate_buffer - 1;
		ptr_crossbar->width_output_line_tristate_buffer_p[j] = pmos_to_nmos_sizing_r * MAX_NMOS_WIDTH;
		ptr_crossbar->width_output_line_tristate_buffer_n[j] = ptr_crossbar->width_output_line_tristate_buffer_p[j] / pmos_to_nmos_sizing_r;
	}

	for(j = ptr_crossbar->number_gates_output_line_tristate_buffer - 2; j >= 1; --j){
		if(j == ptr_crossbar->number_gates_output_line_tristate_buffer - 2){
			c_input = gatecap(ptr_crossbar->width_output_line_tristate_buffer_p[j+1], 0) / f;
		}
		else{
			c_input = gatecap(ptr_crossbar->width_output_line_tristate_buffer_n[j+1] + ptr_crossbar->width_output_line_tristate_buffer_p[j+1], 0) / f;
		}
		ptr_crossbar->width_output_line_tristate_buffer_n[j] = (1 /( 1 + pmos_to_nmos_sizing_r)) * c_input / gatecap(1, 0);
		if(ptr_crossbar->width_output_line_tristate_buffer_n[j] < minimum_width_nmos){
			ptr_crossbar->width_output_line_tristate_buffer_n[j] = minimum_width_nmos;
		}
		ptr_crossbar->width_output_line_tristate_buffer_p[j]  = pmos_to_nmos_sizing_r  * ptr_crossbar->width_output_line_tristate_buffer_n[j];
	}

	//Compute widths of buffer driving input line of crossbar
	ptr_crossbar->crossbar_input_line_driver.c_gate_load =  ptr_crossbar->number_output_ports * gatecap(ptr_crossbar->width_output_line_tristate_buffer_n[0] + 
		ptr_crossbar->width_output_line_tristate_buffer_p[0] +	ptr_crossbar->width_output_line_tristate_buffer_nor2_n + ptr_crossbar->width_output_line_tristate_buffer_nor2_p, 0);
	ptr_crossbar->crossbar_input_line_driver.c_wire_load =  wire_outside_mat_pitch * ptr_crossbar->number_signals_per_port * ptr_crossbar->number_output_ports * wire_outside_mat_c_per_micron;
	ptr_crossbar->crossbar_input_line_driver.r_wire_load = wire_outside_mat_pitch * ptr_crossbar->number_signals_per_port * ptr_crossbar->number_output_ports * wire_outside_mat_r_per_micron;
	initialize_driver(&ptr_crossbar->crossbar_input_line_driver);
	compute_widths_driver(&ptr_crossbar->crossbar_input_line_driver);

}

delay_crossbar(crossbar* ptr_crossbar, double inrisetime, double *outrisetime)
{
	double rd, c_load, tf, c_intrinsic, c_wire_load, r_wire_load, this_delay, pmos_to_nmos_sizing_r;
	int j;

	ptr_crossbar->power.readOp.dynamic = 0;
	ptr_crossbar->power.readOp.leakage = 0;
	ptr_crossbar->power.writeOp.dynamic = 0;
	ptr_crossbar->power.writeOp.leakage = 0;
	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();

	//Delay in input line 
	delay_driver(&ptr_crossbar->crossbar_input_line_driver, inrisetime, outrisetime);
	ptr_crossbar->delay += ptr_crossbar->crossbar_input_line_driver.delay;
	ptr_crossbar->power.readOp.dynamic += ptr_crossbar->crossbar_input_line_driver.power.readOp.dynamic;
	ptr_crossbar->power.readOp.leakage += ptr_crossbar->crossbar_input_line_driver.power.readOp.leakage;

	//Delay in output line
	for(j = 0; j < ptr_crossbar->number_gates_output_line_tristate_buffer; ++j){
		if(j == 0){//NAND2 gate
			rd = transreson(ptr_crossbar->width_output_line_tristate_buffer_n[j], NCH, 2);
			if(ptr_crossbar->number_gates_output_line_tristate_buffer == 2){
				c_load = gatecap(ptr_crossbar->width_output_line_tristate_buffer_p[j+1], 0.0);//NAND2 driving PMOS output stage
			}
			else{
				c_load = gatecap(ptr_crossbar->width_output_line_tristate_buffer_p[j+1], 0.0);//NAND2 driving inverter
			}
			c_intrinsic = draincap(ptr_crossbar->width_output_line_tristate_buffer_n[j], NCH, 2, 1, DEFAULTHEIGHTCELL) + 
				2 * draincap(ptr_crossbar->width_output_line_tristate_buffer_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL);
			tf = rd * (c_intrinsic + c_load);
			ptr_crossbar->power.readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
		}
		else if(j == ptr_crossbar->number_gates_output_line_tristate_buffer - 1){//PMOS 
			rd = transreson(ptr_crossbar->width_output_line_tristate_buffer_p[j], PCH, 1);
			c_wire_load = wire_outside_mat_pitch * ptr_crossbar->number_signals_per_port * ptr_crossbar->number_input_ports * wire_outside_mat_c_per_micron;
			r_wire_load = wire_outside_mat_pitch * ptr_crossbar->number_signals_per_port * ptr_crossbar->number_input_ports * wire_outside_mat_r_per_micron;
			c_load =  c_wire_load + ptr_crossbar->c_output_line_load;
			c_intrinsic = draincap(ptr_crossbar->width_output_line_tristate_buffer_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) + 
				draincap(ptr_crossbar->width_output_line_tristate_buffer_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
			tf = rd * (c_intrinsic + c_load) + r_wire_load * (c_wire_load / 2 + ptr_crossbar->c_output_line_load +
				draincap(ptr_crossbar->width_output_line_tristate_buffer_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL) + 
				draincap(ptr_crossbar->width_output_line_tristate_buffer_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL));
			ptr_crossbar->power.readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
		}
		else{//inverter
			rd = transreson(ptr_crossbar->width_output_line_tristate_buffer_n[j], NCH, 1);
			if(j == ptr_crossbar->number_gates_output_line_tristate_buffer - 2){//inverter driving PMOS of output stage
				c_load = gatecap(ptr_crossbar->width_output_line_tristate_buffer_p[j+1], 0.0);
			}
			else{//inverter driving inverter
				c_load = gatecap(ptr_crossbar->width_output_line_tristate_buffer_n[j+1] + ptr_crossbar->width_output_line_tristate_buffer_p[j+1], 0.0);
			}
			c_intrinsic = draincap(ptr_crossbar->width_output_line_tristate_buffer_p[j], PCH, 1, 1, DEFAULTHEIGHTCELL) +
				draincap(ptr_crossbar->width_output_line_tristate_buffer_n[j], NCH, 1, 1, DEFAULTHEIGHTCELL);
			tf = rd * (c_intrinsic + c_load);
		ptr_crossbar->power.readOp.dynamic += (c_intrinsic + c_load) * 0.5 * vdd_periph_global * vdd_periph_global;
		}
		this_delay = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
		ptr_crossbar->delay += this_delay;
		inrisetime = this_delay/(1.0 - 0.5);
	}    
    *outrisetime = inrisetime;

	for(j = 0; j < ptr_crossbar->number_gates_output_line_tristate_buffer; ++j){
		if(j == 0){//NAND gate, NOR gate
			ptr_crossbar->power.readOp.leakage += cmos_ileakage(ptr_crossbar->width_output_line_tristate_buffer_n[j], 
				ptr_crossbar->width_output_line_tristate_buffer_p[j], temper) * 0.5 * vdd_periph_global;
			ptr_crossbar->power.readOp.leakage += cmos_ileakage(ptr_crossbar->width_output_line_tristate_buffer_nor2_n, 
				ptr_crossbar->width_output_line_tristate_buffer_nor2_p, temper) * 0.5 * vdd_periph_global;
		}
		else if(j == ptr_crossbar->number_gates_output_line_tristate_buffer - 1){//PMOS and NMOS output stage
			ptr_crossbar->power.readOp.leakage += cmos_ileakage(ptr_crossbar->width_output_line_tristate_buffer_n[j], 
				ptr_crossbar->width_output_line_tristate_buffer_p[j], temper) * 0.5 * vdd_periph_global;
		}
		else{//inverters in NAND2 and NOR2 paths. Assume that inverters in the NOR2 path 
			//half the width of corresp inverters in NAND2 path (because inverters in NOR2 path
			//drive NMOS of output stage compared to inverters in NAND2 path that drive PMOS of 
			//output stage)
			ptr_crossbar->power.readOp.leakage += cmos_ileakage(ptr_crossbar->width_output_line_tristate_buffer_n[j] + ptr_crossbar->width_output_line_tristate_buffer_n[j] / pmos_to_nmos_sizing_r,
				ptr_crossbar->width_output_line_tristate_buffer_p[j] + ptr_crossbar->width_output_line_tristate_buffer_p[j] / pmos_to_nmos_sizing_r, temper) * 
				0.5 * vdd_periph_global;
		}
	}
}





area_type area_crossbar(crossbar *ptr_crossbar)
{
	area_type crossb;
	crossb.height =  wire_outside_mat_pitch * ptr_crossbar->number_signals_per_port * ptr_crossbar->number_input_ports;
	crossb.width = wire_outside_mat_pitch * ptr_crossbar->number_signals_per_port * ptr_crossbar->number_output_ports;
	crossb.area = crossb.height * crossb.width;
	return(crossb);
}
/*======================================================================*/


void delay_fa_tag(int tagbits, int Ntbl, int number_rows_subarray, double *delay, powerDef *power)
{
	double Tagdrive1, Tagdrive2, Tag1, Tag2, Tag3, outrisetime;
    double Ceq, Rwire, tf, nextinputtime, c_intrinsic, rd, Cwire, c_gate_load;
     

	double Wdecdrivep, Wdecdriven, Wfadriven, Wfadrivep, Wfadrive2n, Wfadrive2p, Wfadecdrive1n, Wfadecdrive1p, 
		Wfadecdrive2n, Wfadecdrive2p, Wfadecdriven, Wfadecdrivep, Wfaprechn, Wfaprechp,
		Wdummyn, Wdummyinvn, Wdummyinvp, Wfainvn, Wfainvp, Waddrnandn, Waddrnandp,
		Wfanandn, Wfanandp, Wfanorn, Wfanorp, Wdecnandn, Wdecnandp;

	double FACwordmetal, FACbitmetal, FARbitmetal, FARwordmetal, dynPower;
	int Htagbits;


	FACwordmetal = cam_cell_width * wire_local_c_per_micron;
	FACbitmetal = cam_cell_height * wire_local_c_per_micron;
	FARwordmetal = cam_cell_width * wire_local_r_per_micron;
	FARbitmetal = cam_cell_height * wire_local_r_per_micron;

    dynPower = 0.0;

	
	Wdecdrivep = 450 * FEATURESIZE;//this was 360 micron for the 0.8 micron process
    Wdecdriven = 300 * FEATURESIZE;//this was 240 micron for the 0.8 micron process
	Wfadriven = 62.5 * FEATURESIZE;//this was 50 micron for the 0.8 micron process
	Wfadrivep = 125 * FEATURESIZE;//this was 100 micron for the 0.8 micron process
	Wfadrive2n = 250 * FEATURESIZE;//this was 200 micron for the 0.8 micron process
	Wfadrive2p = 500 * FEATURESIZE;//this was 400 micron for the 0.8 micron process
	Wfadecdrive1n = 6.25 * FEATURESIZE;//this was 5 micron for the 0.8 micron process
	Wfadecdrive1p = 12.5 * FEATURESIZE;//this was 10 micron for the 0.8 micron process
	Wfadecdrive2n = 25 * FEATURESIZE;//this was 20 micron for the 0.8 micron process
	Wfadecdrive2p = 50 * FEATURESIZE;//this was 40 micron for the 0.8 micron process	
	Wfadecdriven =  62.5 * FEATURESIZE;//this was 50 micron for the 0.8 micron process
	Wfadecdrivep =  125 * FEATURESIZE;//this was 100 micron for the 0.8 micron process
	Wfaprechn =  7.5 * FEATURESIZE;//this was 6 micron for the 0.8 micron process
	Wfaprechp = 12.5 * FEATURESIZE;//this was 10 micron for the 0.8 micron process
	Wdummyn =  12.5 * FEATURESIZE;//this was 10 micron for the 0.8 micron process
	Wdummyinvn = 75 * FEATURESIZE;//this was 60 micron for the 0.8 micron process	
	Wdummyinvp = 100 * FEATURESIZE;//this was 80 micron for the 0.8 micron process
	Wfainvn = 12.5 * FEATURESIZE;//this was 10 micron for the 0.8 micron process	
	Wfainvp = 25 * FEATURESIZE;//this was 20 micron for the 0.8 micron process	
	Waddrnandn = 62.5 * FEATURESIZE;//this was 50 micron for the 0.8 micron process	
	Waddrnandp = 62.5 * FEATURESIZE;//this was 50 micron for the 0.8 micron process	
	Wfanandn = 25 * FEATURESIZE;//this was 20 micron for the 0.8 micron process	
	Wfanandp = 37.5 * FEATURESIZE;//this was 30 micron for the 0.8 micron process
	Wfanorn = 6.25 * FEATURESIZE;//this was 5 micron for the 0.8 micron process	
	Wfanorp = 12.5 * FEATURESIZE;//this was 10 micron for the 0.8 micron process
	Wdecnandn =  12.5 * FEATURESIZE;//this was 10 micron for the 0.8 micron process	
	Wdecnandp =  37.5 * FEATURESIZE;//this was 30 micron for the 0.8 micron process

	Htagbits = (int)(ceil ((double) (tagbits) / 2.0));

	/* First stage */
	nextinputtime = 0;
	Ceq = draincap(Wfadecdrive2p, PCH, 1, 1, DEFAULTHEIGHTCELL) + draincap(Wfadecdrive2n, NCH, 1, 1, DEFAULTHEIGHTCELL) + gatecap(Wfadecdrivep + Wfadecdriven, 0);
	tf = Ceq * transreson(Wfadecdrive2n, NCH, 1);
	Tagdrive1 = horowitz(nextinputtime, tf, VSINV, VTHFA1, FALL);
	nextinputtime = Tagdrive1 / VTHFA1;
	dynPower += Ceq * vdd_periph_global * vdd_periph_global * tagbits * Ntbl;
	
	rd = transreson(Wfadecdrivep, PCH, 1);
	c_intrinsic = draincap(Wfadecdrivep, PCH, 1, 1, DEFAULTHEIGHTCELL) + draincap(Wfadecdriven, NCH, 1, 1, DEFAULTHEIGHTCELL);
	c_gate_load = gatecap(Wdummyn, 0) * 2 * (number_rows_subarray + 1);
	Cwire = FACbitmetal * 2 * (number_rows_subarray + 1);
	Rwire = FARbitmetal * (number_rows_subarray + 1);
	tf = rd * (c_intrinsic + Ceq) + Rwire * (Cwire / 2 + c_gate_load);
	Tagdrive2 = horowitz(nextinputtime, tf, VTHFA1, VTHFA2, RISE);
	nextinputtime = Tagdrive2 / (1 - VTHFA2);
    dynPower += (c_intrinsic + Cwire + c_gate_load) * vdd_periph_global * vdd_periph_global * tagbits * Ntbl;

	/* second stage */
	rd =  transreson(Wdummyn, NCH, 2);
    c_intrinsic = Htagbits * 2 * draincap (Wdummyn, NCH, 2, 1, DEFAULTHEIGHTCELL) + draincap (Wfaprechp, PCH, 1, 1, DEFAULTHEIGHTCELL);
	Cwire = FACwordmetal * Htagbits;
	Rwire = FARwordmetal * Htagbits;
	c_gate_load = gatecap (Waddrnandn + Waddrnandp, 0);
	tf = rd * (c_intrinsic + Ceq) + Rwire * (Cwire / 2 + c_gate_load);
    Tag1 = horowitz(nextinputtime, tf, VTHFA2, VTHFA3, FALL);
	nextinputtime = Tag1 / VTHFA3;
	dynPower += Ceq * vdd_periph_global * vdd_periph_global * number_rows_subarray * Ntbl;

	/* third stage */
	rd = transreson(Waddrnandn, NCH, 2);
	c_intrinsic = draincap (Waddrnandn, NCH, 2, 1, DEFAULTHEIGHTCELL) + 2 * draincap (Waddrnandp, PCH, 1, 1, DEFAULTHEIGHTCELL);
	c_gate_load = gatecap(Wdummyinvn + Wdummyinvp, 0);
	tf = rd * (c_intrinsic + c_gate_load);
	Tag2 = horowitz(nextinputtime, tf, VTHFA3, VTHFA4, RISE);
	nextinputtime = Tag2 / (1 - VTHFA4);
	dynPower += Ceq * vdd_periph_global * vdd_periph_global * number_rows_subarray * Ntbl;

	/* fourth stage */
	rd = transreson(Wdummyinvn, NCH, 1);
	c_intrinsic = draincap(Wdummyinvn, NCH, 1, 1, DEFAULTHEIGHTCELL);
	Cwire = FACwordmetal * Htagbits +  FACbitmetal * number_rows_subarray;
	Rwire = FARwordmetal * Htagbits +  FARbitmetal * number_rows_subarray;
	c_gate_load = gatecap(Wfanorn + Wfanorp, 0);
	tf = rd * (c_intrinsic + Cwire) + Rwire * (Cwire / 2 + c_gate_load);
	Tag3 = horowitz (nextinputtime, tf, VTHFA4, VTHFA5, FALL);
	outrisetime = Tag3 / VTHFA5;
	dynPower += (c_intrinsic + Cwire + c_gate_load) * vdd_periph_global * vdd_periph_global;

	*delay = Tagdrive1 + Tagdrive2 + Tag1 + Tag2 + Tag3;
	power->readOp.dynamic = dynPower;
}


/*======================================================================*/

int calculate_time(parameter_type *parameters, double *NSubbanks, int is_tag, int pure_ram, double Nspd, int Ndwl, 
        int Ndbl, int Ndcm, int Ndsam_level_1, int Ndsam_level_2, mem_array *ptr_array, int flag_results_populate,
        results_mem_array *ptr_results, final_results *ptr_fin_res, array_edge_to_bank_edge_htree_sizing *ptr_arr_edge_to_bank_edge_htree_sizing, 
		bank_htree_sizing *ptr_bnk_htree_sizing)
{
    arearesult_type arearesult_temp;

    double length_wire_htree_node[MAX_NUMBER_GATES_STAGE];

    predecoder_block row_predec_blk_1, row_predec_blk_2,  bit_mux_predec_blk_1, bit_mux_predec_blk_2,
        senseamp_mux_level_1_predec_blk_1, senseamp_mux_level_1_predec_blk_2, senseamp_mux_level_2_predec_blk_1, senseamp_mux_level_2_predec_blk_2, dummy_way_select_predec_blk_1, 
		dummy_way_select_predec_blk_2;

    decoder row_dec, bit_mux_dec, senseamp_mux_level_1_dec, senseamp_mux_level_2_dec;

	driver bitline_precharge_eq_driver;

    predecoder_block_driver row_predec_blk_driver_1, row_predec_blk_driver_2, bit_mux_predec_blk_driver_1, 
        bit_mux_predec_blk_driver_2, senseamp_mux_level_1_predec_blk_driver_1, senseamp_mux_level_1_predec_blk_driver_2,
		senseamp_mux_level_2_predec_blk_driver_1, senseamp_mux_level_2_predec_blk_driver_2,
		way_select_driver_1, dummy_way_select_driver_2;

    addr_datain_htree_node vertical_addr_din_htree_node[MAX_NUMBER_HTREE_NODES], 
                   horizontal_addr_din_htree_node[MAX_NUMBER_HTREE_NODES];
    dataout_htree_node dout_htree_node[MAX_NUMBER_HTREE_NODES], 
                   subarray_output_htree_node;
    powerDef tot_power_addr_vertical_htree, tot_power_datain_vertical_htree, tot_power_bitlines, 
        tot_power_sense_amps, tot_power_subarray_output_drivers, 
        tot_power_dataout_vertical_htree, tot_power_comparators, tot_power_crossbar;

    powerDef tot_power, tot_power_row_predecode_block_drivers,
             tot_power_bit_mux_predecode_block_drivers, 
             tot_power_senseamp_mux_level_1_predecode_block_drivers, tot_power_senseamp_mux_level_2_predecode_block_drivers,
             tot_power_row_predecode_blocks, tot_power_bit_mux_predecode_blocks,
             tot_power_senseamp_mux_level_1_predecode_blocks, tot_power_senseamp_mux_level_2_predecode_blocks, tot_power_row_decoders, 
             tot_power_bit_mux_decoders, tot_power_senseamp_mux_level_1_decoders, tot_power_senseamp_mux_level_2_decoders,
			 tot_power_bitlines_precharge_eq_driver;

	
    double access_time = 0;
    double bitline_data = 0.0;
    powerDef sense_amp_data_power,  bitline_data_power;
    double cycle_time = 0.0, precharge_del = 0.0;
    double outrisetime = 0.0, inrisetime = 0.0;
    double Tpre;
    double writeback_delay;
    int number_rows_subarray, number_cols_subarray, deg_bitline_muxing, deg_senseamp_muxing_level_1_non_associativity;


    double outrisetime_nand2_row_decode_path_1, outrisetime_nand3_row_decode_path_1,
           outrisetime_nand2_bit_mux_decode_path_1, outrisetime_nand3_bit_mux_decode_path_1,
           outrisetime_nand2_senseamp_mux_level_1_decode_path_1, outrisetime_nand3_senseamp_mux_level_1_decode_path_1,
           outrisetime_nand2_row_decode_path_2, outrisetime_nand3_row_decode_path_2,
           outrisetime_nand2_bit_mux_decode_path_2, outrisetime_nand3_bit_mux_decode_path_2,
           outrisetime_nand2_senseamp_mux_level_1_decode_path_2, outrisetime_nand3_senseamp_mux_level_1_decode_path_2,
		   outrisetime_nand2_senseamp_mux_level_2_decode_path_1, outrisetime_nand3_senseamp_mux_level_2_decode_path_1,
		   outrisetime_nand2_senseamp_mux_level_2_decode_path_2, outrisetime_nand3_senseamp_mux_level_2_decode_path_2;

    double delay_before_row_decoder_nand2_path_1, delay_before_row_decoder_nand3_path_1,
           delay_before_row_decoder_nand2_path_2, delay_before_row_decoder_nand3_path_2,
           delay_before_bit_mux_decoder_nand2_path_1, delay_before_bit_mux_decoder_nand3_path_1,
           delay_before_bit_mux_decoder_nand2_path_2, delay_before_bit_mux_decoder_nand3_path_2,
           delay_before_senseamp_mux_level_1_decoder_nand2_path_1, delay_before_senseamp_mux_level_1_decoder_nand3_path_1,
           delay_before_senseamp_mux_level_1_decoder_nand2_path_2, delay_before_senseamp_mux_level_1_decoder_nand3_path_2,
		   delay_before_senseamp_mux_level_2_decoder_nand2_path_1, delay_before_senseamp_mux_level_2_decoder_nand3_path_1,
           delay_before_senseamp_mux_level_2_decoder_nand2_path_2, delay_before_senseamp_mux_level_2_decoder_nand3_path_2;

    double c_wordline_driver_load, c_gate_load_bit_mux_decoder_output, c_wire_load_bit_mux_decoder_output, c_load_bit_mux_decoder_output,
           c_gate_load_senseamp_mux_level_1_decoder_output, c_wire_load_senseamp_mux_level_1_decoder_output, c_load_senseamp_mux_level_1_decoder_output,
		   c_gate_load_senseamp_mux_level_2_decoder_output, c_wire_load_senseamp_mux_level_2_decoder_output, c_load_senseamp_mux_level_2_decoder_output,
           r_wire_wordline_driver_output, r_wire_bit_mux_decoder_output, r_wire_senseamp_mux_decoder_output,
           c_wire_row_predecode_block_output, r_wire_row_predecode_block_output,
           c_wire_bit_mux_predecode_block_output, r_wire_bit_mux_predecode_block_output, 
           c_wire_senseamp_mux_level_1_predecode_block_output, r_wire_senseamp_mux_predecode_block_output, c_wire_senseamp_mux_level_2_predecode_block_output;

    double row_dec_outrisetime, bit_mux_dec_outrisetime, senseamp_mux_level_1_dec_outrisetime, senseamp_mux_level_2_dec_outrisetime;

    double delay_addr_din_vertical_htree, delay_dout_vertical_htree, delay_before_subarray_output_driver,
           delay_from_subarray_output_driver_to_output;


    double max_delay_before_row_decoder, max_delay_before_bit_mux_decoder, 
		max_delay_before_senseamp_mux_level_1_decoder, delay_within_mat_before_row_decoder,
		delay_within_mat_before_bit_mux_decoder, delay_within_mat_before_senseamp_mux_level_1_decoder,
		max_delay_before_senseamp_mux_level_2_decoder, delay_within_mat_before_senseamp_mux_level_2_decoder;

    double row_dec_inrisetime, bit_mux_dec_inrisetime, senseamp_mux_level_1_dec_inrisetime, senseamp_mux_level_2_dec_inrisetime;

    double delay_data_access_row_path, delay_data_access_col_path, delay_data_access_senseamp_mux_level_1_path, delay_data_access_senseamp_mux_level_2_path,
           temp_delay_data_access_path, delay_data_access_path; 

    int number_addr_bits_nand2_row_decode_path_1, number_addr_bits_nand3_row_decode_path_1, 
        number_addr_bits_nand2_row_decode_path_2, number_addr_bits_nand3_row_decode_path_2,
        number_addr_bits_nand2_bit_mux_decode_path_1, number_addr_bits_nand3_bit_mux_decode_path_1,
        number_addr_bits_nand2_bit_mux_decode_path_2, number_addr_bits_nand3_bit_mux_decode_path_2,
        number_addr_bits_nand2_senseamp_mux_level_1_decode_path_1, number_addr_bits_nand3_senseamp_mux_level_1_decode_path_1,
        number_addr_bits_nand2_senseamp_mux_level_1_decode_path_2, number_addr_bits_nand3_senseamp_mux_level_1_decode_path_2,
		number_addr_bits_nand2_senseamp_mux_level_2_decode_path_1, number_addr_bits_nand3_senseamp_mux_level_2_decode_path_1,
        number_addr_bits_nand2_senseamp_mux_level_2_decode_path_2, number_addr_bits_nand3_senseamp_mux_level_2_decode_path_2;

    powerDef power_addr_datain_htree, power_dout_htree, power_output_drivers_at_subarray;

    int number_addr_bits_mat, number_datain_bits_mat, number_dataout_bits_mat, 
        number_subarrays, number_mats, number_sense_amps_subarray,
	    number_output_drivers_subarray,
        number_way_select_signals_mat = 0;

    area_type subarray, mat, bank, all_banks;

    point_to_point_interconnect_segment horizontal_addr_intcnt_segment_within_bank,
                                        horizontal_datain_intcnt_segment_within_bank;
    double  delay_dout_horizontal_htree;

    int number_subarrays_horizontal_direction, number_subarrays_vertical_direction, 
		number_vertical_htree_nodes, number_horizontal_htree_nodes, number_tristate_horizontal_htree_nodes,
        number_mats_horizontal_direction, number_mats_vertical_direction, 
        number_activated_mats_horizontal_direction, way_select = 0;
    int number_decode_gates_driven_per_predecode_output, 
        number_addr_bits_row_decode, number_addr_bits_bit_mux_decode, 
        number_addr_bits_senseamp_mux_level_1_decode_non_associativity,  number_addr_bits_senseamp_mux_level_2_decode, number_subbanks, 
        number_subbanks_decode, number_addr_bits_routed_to_bank,
        number_comparator_bits_routed_to_bank, number_data_bits_routed_to_bank, 
        number_bits_routed_to_bank, number_dataout_bits_subbank, number_datain_bits_subbank;

    double length_htree_route_to_bank;

    double vertical_htree_seg_length, horizontal_htree_seg_length, delay_addr_din_horizontal_htree;
    powerDef power_addr_datain_horizontal_htree;
	powerDef power_addr_datain_horizontal_htree_node, power_addr_datain_vertical_htree_node, power_dout_vertical_htree_node;


    int rem, tagbits,  k, htree_seg_multiplier;
    double Cbitrow_drain_cap, Cbitline;
    double delay_route_to_bank, wordline_data, delay_subarray_output_driver, delay_final_stage_subarray_output_driver,
           delay_sense_amp,  multisubbank_interleave_cycle_time;
    powerDef tot_power_addr_horizontal_htree, tot_power_datain_horizontal_htree,
             tot_power_dataout_horizontal_htree, //tot_power_comparators,
             tot_power_routing_to_bank;
    double comparator_delay;
    powerDef comparator_power, power_routing_to_bank;

    double area_all_dataramcells;

    double c_load, rd, c_intrinsic, tf, wordline_reset_delay;
	double dummy_precharge_outrisetime;

	double r_bitline_precharge, r_bitline, bitline_restore_delay;

	double temp, dram_array_availability;

	double leakage_power_cc_inverters_sram_cell, leakage_power_access_transistors_read_write_port_sram_cell,
			leakage_power_read_only_port_sram_cell, length_htree_segment;

	double horizontal_htree_input_load, htree_output_load;
	double gatecapval, draincapval;
	int number_redundant_mats;
	double per_bitline_read_energy;
	double capacity_per_stacked_die_layer;
	double t_rcd = 0, cas_latency = 0, precharge_delay = 0;
	double c_crossbar_output_line_load;
	crossbar crossbar_instance;
	double dyn_read_energy_from_closed_page;
    double dyn_read_energy_from_open_page;
	double leak_power_subbank_closed_page;
	double leak_power_subbank_open_page;
	double leak_power_request_and_reply_networks;
	double leak_power_sense_amps_closed_page_state;
	double leak_power_sense_amps_open_page_state;
	double dyn_read_energy_remaining_words_in_burst;

	int number_addr_bits_routed_to_bank_for_activate, number_addr_bits_routed_to_bank_for_read_or_write, number_addr_bits_routed_to_mat_for_activate,
		number_addr_bits_routed_to_mat_for_read_or_write;
	double activate_energy, routing_to_bank_for_activate_energy, horizontal_htree_routing_energy_for_activate, vertical_htree_routing_energy_for_activate,
		read_energy, routing_addr_to_bank_for_read_or_write_energy, routing_datain_bits_to_bank_energy_for_write, horizontal_addr_htree_routing_energy_for_read_or_write, 
		vertical_addr_htree_routing_energy_for_read_or_write, vertical_dataout_htree_routing_energy_for_read, horizontal_dataout_htree_energy_for_read, write_energy, 
		horizontal_datain_htree_routing_energy_for_write, vertical_datain_htree_routing_energy_for_write, precharge_energy;
	double delay_fa_decoder, pmos_to_nmos_sizing_r;
	powerDef power_fa_decoder;
	double delay_request_network, delay_inside_mat, delay_reply_network;

	capacity_per_stacked_die_layer = parameters->cache_size / NUMBER_STACKED_DIE_LAYERS;

	if(parameters->fully_assoc){
		if(Ndwl != 1) {goto partition_not_valid;} //Ndwl is fixed to 1 for FA 
		if(Ndcm != 1) {goto partition_not_valid;} //Ndcm is fixed to 1 for FA
		if((Nspd < 1)||(Nspd > 1)) {goto partition_not_valid;} //Nspd is fixed to 1 for FA
		if(Ndsam_level_1 != 1) {goto partition_not_valid;} //Ndsam_level_1 is fixed to one
		if(Ndsam_level_2 != 1) {goto partition_not_valid;} //Ndsam_level_2 is fixed to one
		if(Ndbl < 2){goto partition_not_valid;}
	}
    if(((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4))&&(!is_tag)&&(Ndcm > 1)){goto partition_not_valid;}//For DRAM data array, Ndcm has to be 1
	//If it's not an FA tag/data array, Ndwl should be at least two and Ndbl should be at least two because an array is assumed to have at least one mat. And a mat
	//is formed out of two horizontal subarrays and two vertical subarrays
    if((!parameters->fully_assoc)&&(Ndwl == 1)) {goto partition_not_valid;}
    if((!parameters->fully_assoc)&&(Ndbl == 1)) {goto partition_not_valid;}
    tagbits = 0;//if data array, let tagbits = 0
	if(is_tag){
        if(parameters->force_tag == 1){
			tagbits = parameters->tag_size;
        }
        else{
			if(parameters->fully_assoc){
				tagbits = ADDRESS_BITS + EXTRA_TAG_BITS- (int)(logtwo((double)parameters->block_size));
			}
			else{
				tagbits = ADDRESS_BITS + EXTRA_TAG_BITS - (int)logtwo((double)(capacity_per_stacked_die_layer)) + 
					(int)(ceil(logtwo((double)(parameters->tag_associativity)))) - (int)(logtwo(*NSubbanks));
			}
        }
        rem = tagbits%4;
        if(rem != 0){
            tagbits = tagbits + 4 - rem;
        }
		if(parameters->fully_assoc){
			number_rows_subarray = capacity_per_stacked_die_layer / (parameters->block_size * Ndbl);
			number_cols_subarray = (int)((tagbits * Nspd / Ndwl) + EPSILON);
		}
		else{
			number_rows_subarray = (int)(capacity_per_stacked_die_layer/ (parameters->number_banks *
				parameters->block_size * parameters->tag_associativity * Ndbl * Nspd) + EPSILON);
			number_cols_subarray = (int)((tagbits * parameters->tag_associativity * Nspd / Ndwl) + EPSILON);
		}
    }
    else{
		if(parameters->fully_assoc){
			number_rows_subarray = (int) (capacity_per_stacked_die_layer) / (parameters->block_size * Ndbl);
			number_cols_subarray  = 8 * parameters->block_size;
		}
		else{
			number_rows_subarray = (int)(capacity_per_stacked_die_layer / (parameters->number_banks * 
				parameters->block_size * parameters->data_associativity * Ndbl * Nspd) + EPSILON);
			number_cols_subarray = (int)((8 * parameters->block_size * parameters->data_associativity * Nspd / Ndwl) + EPSILON);
		}
    }		
    if((!parameters->fully_assoc)&&(number_rows_subarray < MINSUBARRAYROWS)) {goto partition_not_valid;}
	if(number_rows_subarray == 0) {goto partition_not_valid;}
    if(number_rows_subarray > MAXSUBARRAYROWS) {goto partition_not_valid;}
    if(number_cols_subarray < MINSUBARRAYCOLS) {goto partition_not_valid;}
    if(number_cols_subarray > MAXSUBARRAYCOLS) {goto partition_not_valid;}
    number_subarrays = Ndwl * Ndbl;	
    if((!parameters->fully_assoc)&&(number_subarrays < 4)) {goto partition_not_valid;}//number of subarrays is at least 4 i.e. at least one mat.
    //if(number_subarrays > MAXSUBARRAYS) {goto partition_not_valid;}

	//Calculate wire parameters
	if(is_tag){
		height_cell = BitHeight_sram + 2 * wire_local_pitch * (parameters->num_readwrite_ports - 1 + 
			parameters->num_read_ports);
		width_cell = BitWidth_sram + 2 * wire_local_pitch * (parameters->num_readwrite_ports - 1 + 
			(parameters->num_read_ports - parameters->num_single_ended_read_ports)) + 
			wire_local_pitch * parameters->num_single_ended_read_ports;
	}
	else{
		if((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)){
			height_cell = BitHeight_dram;
			width_cell = BitWidth_dram;
		}
		else{
			height_cell = BitHeight_sram + 2 * wire_local_pitch * (parameters->num_write_ports + 
				parameters->num_readwrite_ports - 1 + parameters->num_read_ports);
			width_cell = BitWidth_sram + 2 * wire_local_pitch * (parameters->num_readwrite_ports - 1 + 
				(parameters->num_read_ports - parameters->num_single_ended_read_ports) + 
				parameters->num_write_ports) + wire_local_pitch * parameters->num_single_ended_read_ports;
		}
	}

	Cbitmetal = height_cell * wire_local_c_per_micron;
	Cwordmetal = width_cell * wire_local_c_per_micron;
	Rbitmetal = height_cell * wire_local_r_per_micron;
	Rwordmetal = width_cell * wire_local_r_per_micron;

    if((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)){
		deg_bitline_muxing = 1;
		if(ram_cell_tech_flavor == 4){
			Cbitline = number_rows_subarray * Cbitmetal;
			Vbitsense = (vdd_dram_cell/2) * c_dram_cell /(c_dram_cell + Cbitline);
			if(Vbitsense < VBITSENSEMIN) goto partition_not_valid;//Sense amp input signal is smaller that minimum allowable sense amp input signal
			Vbitsense = VBITSENSEMIN;//In any case, we fix sense amp input signal to a constant value
			dram_refresh_period = 64e-3;
		}
		else{
			is_cell = 1;
			Cbitrow_drain_cap = draincap(Wmemcella_dram, NCH, 1, 0, width_cell) / 2.0;
			is_cell = 0;
			Cbitline = number_rows_subarray * Cbitrow_drain_cap + number_rows_subarray * 
				Cbitmetal;
			Vbitsense = (vdd_dram_cell/2) * c_dram_cell /(c_dram_cell + Cbitline);
			if(Vbitsense < VBITSENSEMIN) goto partition_not_valid;//Sense amp input signal is smaller that minimum allowable sense amp input signal
			Vbitsense = VBITSENSEMIN;//In any case, we fix sense amp input signal to a constant value
			//v_storage_worst = vdd_dram_cell / 2 - VBITSENSEMIN * (c_dram_cell + Cbitline) / c_dram_cell;
			//dram_refresh_period = 1.1 * c_dram_cell * v_storage_worst / I_off_dram_cell_worst_case_length_temp;
			dram_refresh_period = 0.9 * c_dram_cell * VDD_STORAGE_LOSS_FRACTION_WORST * vdd_dram_cell / I_off_dram_cell_worst_case_length_temp;
		}
    }
    else{//SRAM
        deg_bitline_muxing = Ndcm;
		is_cell = 1; 
		Cbitrow_drain_cap = draincap(Wmemcella_sram, NCH, 1, 0, width_cell) / 2.0;	/* due to shared contact */
		is_cell = 0; 
		Cbitline = number_rows_subarray * (Cbitrow_drain_cap + Cbitmetal);
		dram_refresh_period = 0;
    }
    number_subarrays_horizontal_direction = Ndwl;
    number_subarrays_vertical_direction = Ndbl;
	if(parameters->fully_assoc){
		number_mats_horizontal_direction = 1;
		number_mats_vertical_direction = MAX(number_subarrays_vertical_direction / 2, 1);
		number_mats = number_mats_horizontal_direction * number_mats_vertical_direction;
		number_dataout_bits_mat = 8 * parameters->block_size;
	}
	else{
		number_mats_horizontal_direction = number_subarrays_horizontal_direction / 2;
		number_mats_vertical_direction = number_subarrays_vertical_direction / 2;
		number_mats = number_mats_horizontal_direction * number_mats_vertical_direction;
		number_dataout_bits_mat = MAX(4 * number_cols_subarray / (deg_bitline_muxing * Ndsam_level_1 * Ndsam_level_2), 1);
	}
    if(!(parameters->fully_assoc&&is_tag)&&(number_dataout_bits_mat < 4)) {goto partition_not_valid;}
   

	if(!is_tag){
		if(is_main_mem){
			number_dataout_bits_subbank = INTERNAL_PREFETCH_WIDTH * parameters->nr_bits_out;
			deg_senseamp_muxing_level_1_non_associativity = Ndsam_level_1;
		}
		else{
			if(parameters->fast_access == 1){
				number_dataout_bits_subbank = parameters->nr_bits_out * parameters->data_associativity;
				deg_senseamp_muxing_level_1_non_associativity = Ndsam_level_1;
			}
			else{
				if(!parameters->fully_assoc){
					number_dataout_bits_subbank = parameters->nr_bits_out;
					deg_senseamp_muxing_level_1_non_associativity = MAX(Ndsam_level_1 / parameters->data_associativity, 1);
					if(Ndsam_level_1 < parameters->data_associativity) {goto partition_not_valid;}
				}
				else{
					number_dataout_bits_subbank = 8 * parameters->block_size;
					deg_senseamp_muxing_level_1_non_associativity = 1;
				}
			}
		}
	}
    else{
       	number_dataout_bits_subbank = tagbits * parameters->tag_associativity;
		if(!parameters->fully_assoc&&(number_dataout_bits_mat < tagbits)) {goto partition_not_valid;}
        deg_senseamp_muxing_level_1_non_associativity = Ndsam_level_1;
    }

	if(parameters->fully_assoc){
		number_activated_mats_horizontal_direction = 1;
	}
	else{
		number_activated_mats_horizontal_direction = number_dataout_bits_subbank / number_dataout_bits_mat;//number_mats_horizontal_direction;
	}
  
	if(number_activated_mats_horizontal_direction == 0) {goto partition_not_valid;}
	if(is_tag){
		if(parameters->fully_assoc){
			number_dataout_bits_mat = 0;
			number_dataout_bits_subbank = 0;
		}
		else{
			number_dataout_bits_mat = parameters->tag_associativity / number_activated_mats_horizontal_direction;
			number_dataout_bits_subbank = number_activated_mats_horizontal_direction * number_dataout_bits_mat;
		}
	}
	if(((!parameters->cache)&&(is_main_mem))||((PAGE_MODE == 1)&&((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)))){
		if(number_activated_mats_horizontal_direction * number_dataout_bits_mat * Ndsam_level_1 * Ndsam_level_2 != PAGE_SIZE_BITS){
			goto partition_not_valid;
		}
	}

	if((!is_tag)&&(parameters->cache)&&(number_activated_mats_horizontal_direction * number_dataout_bits_mat * Ndsam_level_1 * Ndsam_level_2 < parameters->nr_bits_out * BURST_LENGTH * parameters->data_associativity)){
		goto partition_not_valid;
	}

	if(number_activated_mats_horizontal_direction > number_mats_horizontal_direction) {goto partition_not_valid;}

 	if(!is_tag){
		if(parameters->fast_access == 1){
			number_datain_bits_mat = number_dataout_bits_mat / parameters->data_associativity;
		}
		else{
			number_datain_bits_mat = number_dataout_bits_mat;
		}
		number_datain_bits_subbank = number_datain_bits_mat * number_activated_mats_horizontal_direction;
	}
	else{
		number_datain_bits_mat = tagbits;
		number_datain_bits_subbank = number_activated_mats_horizontal_direction * number_datain_bits_mat;
	}
	
	if(parameters->fully_assoc){
		number_addr_bits_row_decode = 0;
	}
	else{
		number_addr_bits_row_decode = (int)(logbasetwo((double)(number_rows_subarray)));
	}
    
    number_addr_bits_bit_mux_decode = (int)(logbasetwo((double)(deg_bitline_muxing)));
    number_addr_bits_senseamp_mux_level_1_decode_non_associativity = 
        (int)(logbasetwo((double)(deg_senseamp_muxing_level_1_non_associativity)));
	number_addr_bits_senseamp_mux_level_2_decode = 
        (int)(logbasetwo((double)(Ndsam_level_2)));
    number_subbanks = number_mats / number_activated_mats_horizontal_direction;
    number_subbanks_decode = (int)(logbasetwo((double)(number_subbanks)));
    number_addr_bits_mat = number_addr_bits_row_decode + number_addr_bits_bit_mux_decode +
        number_addr_bits_senseamp_mux_level_1_decode_non_associativity + number_addr_bits_senseamp_mux_level_2_decode;
    number_addr_bits_routed_to_bank = number_addr_bits_mat + number_subbanks_decode;
    number_comparator_bits_routed_to_bank = 0;
    if((!is_tag)&&(!pure_ram)){//data array of cache
        number_comparator_bits_routed_to_bank = parameters->data_associativity;
    }
    if(is_tag){
        number_data_bits_routed_to_bank = tagbits + parameters->data_associativity;//input to tag
        //array= tagbits, output from tag array = parameters->data_associativity number of comparator
        //bits for set-associative cache. parameters->data_associativity = 1 valid bit for direct-mapped
        //cache or sequential-access cache.
    }
    else{
        number_data_bits_routed_to_bank = parameters->nr_bits_out * 2;//datain and dataout
    }
    number_bits_routed_to_bank = number_addr_bits_routed_to_bank + number_data_bits_routed_to_bank +
        number_comparator_bits_routed_to_bank;

    number_sense_amps_subarray = number_cols_subarray / deg_bitline_muxing;
	number_output_drivers_subarray = number_sense_amps_subarray / (Ndsam_level_1 * Ndsam_level_2);
	if((!is_tag)&&(parameters->data_associativity > 1)&&(!parameters->fast_access)){
        way_select = parameters->data_associativity;
        number_way_select_signals_mat = parameters->data_associativity;
    }		

    if((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)){
        is_access_transistor = 1;
        c_wordline_driver_load = (gatecappass(Wmemcella_dram, BitWidth_dram) + Cwordmetal) * 	number_cols_subarray;
        is_access_transistor = 0;
    }
    else{
        is_sram_cell = 1;
        c_wordline_driver_load = (gatecappass(Wmemcella_sram,(BitWidth_sram-2*Wmemcella_sram)/2.0) + gatecappass(Wmemcella_sram,
                    (BitWidth_sram-2*Wmemcella_sram)/2.0) + Cwordmetal) * number_cols_subarray;
        is_sram_cell = 0;
    }

	//Add ECC adjustment to all data signals that traverse on H-trees.
	number_dataout_bits_mat += (int) (ceil(number_dataout_bits_mat / NUMBER_BITS_PER_ECC_BIT));
	number_datain_bits_mat += (int) (ceil(number_datain_bits_mat / NUMBER_BITS_PER_ECC_BIT));
	number_data_bits_routed_to_bank += (int) (ceil(number_data_bits_routed_to_bank / NUMBER_BITS_PER_ECC_BIT));
	number_bits_routed_to_bank += (int) (ceil(number_bits_routed_to_bank / NUMBER_BITS_PER_ECC_BIT));
	number_datain_bits_subbank += (int) (ceil(number_datain_bits_subbank / NUMBER_BITS_PER_ECC_BIT));
	number_dataout_bits_subbank += (int) (ceil(number_dataout_bits_subbank / NUMBER_BITS_PER_ECC_BIT));


	
    reset_powerDef(&tot_power);
    reset_powerDef(&tot_power_routing_to_bank);
    reset_powerDef(&tot_power_addr_horizontal_htree);
    reset_powerDef(&tot_power_datain_horizontal_htree);
    reset_powerDef(&tot_power_dataout_horizontal_htree);
    reset_powerDef(&tot_power_addr_vertical_htree);
	reset_powerDef(&tot_power_datain_vertical_htree);
    reset_powerDef(&tot_power_row_predecode_block_drivers);
    reset_powerDef(&tot_power_bit_mux_predecode_block_drivers);
    reset_powerDef(&tot_power_senseamp_mux_level_1_predecode_block_drivers);
	reset_powerDef(&tot_power_senseamp_mux_level_2_predecode_block_drivers);
    reset_powerDef(&tot_power_row_predecode_blocks);
    reset_powerDef(&tot_power_bit_mux_predecode_blocks);
    reset_powerDef(&tot_power_senseamp_mux_level_1_predecode_blocks);
	reset_powerDef(&tot_power_senseamp_mux_level_2_predecode_blocks);
    reset_powerDef(&tot_power_row_decoders);
    reset_powerDef(&tot_power_bit_mux_decoders);
    reset_powerDef(&tot_power_senseamp_mux_level_1_decoders);
	reset_powerDef(&tot_power_senseamp_mux_level_2_decoders);
    reset_powerDef(&tot_power_bitlines);
	reset_powerDef(&tot_power_sense_amps);
    reset_powerDef(&tot_power_subarray_output_drivers);
    reset_powerDef(&tot_power_dataout_vertical_htree);
    reset_powerDef(&tot_power_comparators);
	reset_powerDef(&tot_power_crossbar);
    refresh_power = 0;
	horizontal_htree_routing_energy_for_activate = 0;
	horizontal_addr_htree_routing_energy_for_read_or_write = 0;
	horizontal_datain_htree_routing_energy_for_write = 0;
	horizontal_dataout_htree_energy_for_read = 0;
	vertical_htree_routing_energy_for_activate = 0;
	vertical_addr_htree_routing_energy_for_read_or_write = 0;
	vertical_datain_htree_routing_energy_for_write = 0;

	inrisetime = 0;
	rd = transreson(1, NCH, 1);
	pmos_to_nmos_sizing_r = pmos_to_nmos_sizing_ratio();
    c_load = gatecap(1 + pmos_to_nmos_sizing_r, 0.0);
    tf = rd * c_load;
	kinv = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
	KLOAD = 1;
	draincapval = draincap(1, NCH, 1, 0, DEFAULTHEIGHTCELL) + 
		draincap(pmos_to_nmos_sizing_r, PCH, 1, 0, DEFAULTHEIGHTCELL);
	gatecapval = gatecap(4 * (1 + pmos_to_nmos_sizing_r), 0.0);
	c_load = KLOAD * (draincap(1, NCH, 1, 0, DEFAULTHEIGHTCELL) + 
		draincap(2.4, PCH, 1, 0, DEFAULTHEIGHTCELL) + gatecap(4 * (1 + pmos_to_nmos_sizing_r), 0.0));
	tf = rd * c_load;
	FO4 = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
	
	gatecapval = gatecap(1 * (1 + pmos_to_nmos_sizing_r), 0.0);
	c_load = KLOAD * (draincap(1, NCH, 1, 0, DEFAULTHEIGHTCELL) + 
		draincap(pmos_to_nmos_sizing_r, PCH, 1, 0, DEFAULTHEIGHTCELL) + gatecap(1 * (1 + pmos_to_nmos_sizing_r), 0.0));
	tf = rd * c_load;
	FO1 = horowitz(inrisetime, tf, 0.5, 0.5, RISE);
	unit_length_wire_delay = wire_inside_mat_r_per_micron * wire_inside_mat_c_per_micron / 2;
	normalized_unit_length_wire_delay = unit_length_wire_delay / FO4;
	
	if(parameters->fully_assoc&&is_tag){
		subarray = area_fa_subarray(tagbits, number_rows_subarray,  parameters->num_readwrite_ports,parameters->num_read_ports, parameters->num_write_ports,
			parameters->num_single_ended_read_ports);
		area_all_dataramcells = cam_cell_height * cam_cell_width * number_rows_subarray * number_cols_subarray * number_subarrays *
			parameters->number_banks;
	}
	else{
		subarray = subarraymem_area(number_rows_subarray, number_cols_subarray, number_subarrays,
            parameters->num_readwrite_ports,parameters->num_read_ports, parameters->num_write_ports,
            parameters->num_single_ended_read_ports);
		area_all_dataramcells = height_cell * width_cell * number_rows_subarray * number_cols_subarray * number_subarrays *
			parameters->number_banks;
	}
    	
    height_subarray = subarray.height;
    width_subarray = subarray.width;
	

	//number_vertical_htree_nodes = 1 when number_mats_vertical_direction = 1 or 2
	if(number_mats_vertical_direction > 1){
		number_vertical_htree_nodes = (int) (logbasetwo((double)(number_mats_vertical_direction / 2))) + 1;
	}
	else{//number_mats_vertical_direction = 1
		number_vertical_htree_nodes = 1;
	}
    number_horizontal_htree_nodes = (int) (logbasetwo((double)(number_mats_horizontal_direction))) + 1;
	number_tristate_horizontal_htree_nodes = number_horizontal_htree_nodes - ((int) (logbasetwo((double)(number_activated_mats_horizontal_direction))) + 1);
    compute_widths_subarray_output_driver(&subarray_output_htree_node, number_vertical_htree_nodes);

	if(deg_bitline_muxing > 1){
		c_gate_load_bit_mux_decoder_output = (4 * number_cols_subarray / deg_bitline_muxing) * gatecap(width_nmos_bit_mux, 0);
		c_wire_load_bit_mux_decoder_output = 2 * number_cols_subarray * wire_inside_mat_c_per_micron * width_cell;
		c_load_bit_mux_decoder_output = c_gate_load_bit_mux_decoder_output + c_wire_load_bit_mux_decoder_output;
	}
	else{
		c_gate_load_bit_mux_decoder_output = 0;
		c_wire_load_bit_mux_decoder_output = 0;
		c_load_bit_mux_decoder_output = 0;
	}

	if(Ndsam_level_1 > 1){
		c_gate_load_senseamp_mux_level_1_decoder_output = (4 * number_sense_amps_subarray / Ndsam_level_1) * gatecap(width_nmos_sense_amp_mux, 0);
		c_wire_load_senseamp_mux_level_1_decoder_output = 2 * number_cols_subarray * wire_inside_mat_c_per_micron * width_cell;
		c_load_senseamp_mux_level_1_decoder_output = c_gate_load_senseamp_mux_level_1_decoder_output + c_wire_load_senseamp_mux_level_1_decoder_output;
	}
	else{
		c_gate_load_senseamp_mux_level_1_decoder_output = 0;
		c_wire_load_senseamp_mux_level_1_decoder_output = 0;
		c_load_senseamp_mux_level_1_decoder_output = 0;
	}

	if(Ndsam_level_2 > 1){
		c_gate_load_senseamp_mux_level_2_decoder_output = (4 * number_sense_amps_subarray / (Ndsam_level_1 * Ndsam_level_2)) * gatecap(width_nmos_sense_amp_mux, 0);
		c_wire_load_senseamp_mux_level_2_decoder_output = 2 * number_cols_subarray * wire_inside_mat_c_per_micron * width_cell;
		c_load_senseamp_mux_level_2_decoder_output = c_gate_load_senseamp_mux_level_2_decoder_output + c_wire_load_senseamp_mux_level_2_decoder_output;
	}
	else{
		c_gate_load_senseamp_mux_level_2_decoder_output = 0;
		c_wire_load_senseamp_mux_level_2_decoder_output = 0;
		c_load_senseamp_mux_level_2_decoder_output = 0;
	}

    r_wire_wordline_driver_output = number_cols_subarray * Rbitmetal;
    r_wire_bit_mux_decoder_output = number_cols_subarray * wire_inside_mat_r_per_micron * width_cell / 2;
    r_wire_senseamp_mux_decoder_output = number_cols_subarray * wire_inside_mat_r_per_micron * width_cell / 2;

	//Initialize row decoder, bitline mux decoder and sense amp mux decoder circuits
	is_wordline_transistor = 1;
	if(parameters->fully_assoc){
		initialize_decoder(1, 0, c_wordline_driver_load, r_wire_wordline_driver_output, &row_dec);
	}
	else{
		initialize_decoder(number_rows_subarray, 0, c_wordline_driver_load, r_wire_wordline_driver_output, &row_dec);
	}
	is_wordline_transistor = 0;
	if((parameters->fully_assoc)&&(!is_tag)){
		row_dec.flag_decoder_exists = 1;
	}
    initialize_decoder(deg_bitline_muxing, 0, c_load_bit_mux_decoder_output, r_wire_bit_mux_decoder_output, &bit_mux_dec);
    initialize_decoder(deg_senseamp_muxing_level_1_non_associativity, way_select, c_load_senseamp_mux_level_1_decoder_output, r_wire_senseamp_mux_decoder_output, &senseamp_mux_level_1_dec);
	initialize_decoder(Ndsam_level_2, 0, c_load_senseamp_mux_level_2_decoder_output, r_wire_senseamp_mux_decoder_output, &senseamp_mux_level_2_dec);

	//Compute widths of transistors in row decoder, bitline mux decoder and sense amp mux decoder circuits
	is_wordline_transistor = 1;
    compute_widths_decoder(parameters->fully_assoc, &row_dec);
	is_wordline_transistor = 0;
    compute_widths_decoder(parameters->fully_assoc, &bit_mux_dec);
    compute_widths_decoder(parameters->fully_assoc, &senseamp_mux_level_1_dec);
	compute_widths_decoder(parameters->fully_assoc, &senseamp_mux_level_2_dec);

    c_wire_row_predecode_block_output = 2 * number_rows_subarray * wire_inside_mat_c_per_micron * height_cell;
    r_wire_row_predecode_block_output = number_rows_subarray * wire_inside_mat_r_per_micron * height_cell / 2;
    c_wire_bit_mux_predecode_block_output = 0;
    r_wire_bit_mux_predecode_block_output = 0;
    c_wire_senseamp_mux_level_1_predecode_block_output = 0;
	c_wire_senseamp_mux_level_2_predecode_block_output = 0;
    r_wire_senseamp_mux_predecode_block_output = 0;

    number_decode_gates_driven_per_predecode_output = 4;//Because of wordline decoders in 4 subarrays
	//Initialize row predecode, bitline mux predecode and sense amp mux predecode blocks. Also initialize dummy way-select predecode blocks - these blocks
	//do not really exist
	if(parameters->fully_assoc){
		initialize_predecoder_blocks(1, &row_predec_blk_1, &row_predec_blk_2, &row_dec,
            c_wire_row_predecode_block_output, r_wire_row_predecode_block_output, number_decode_gates_driven_per_predecode_output);
	}
	else{
		initialize_predecoder_blocks(number_rows_subarray, &row_predec_blk_1, &row_predec_blk_2, &row_dec,
			c_wire_row_predecode_block_output, r_wire_row_predecode_block_output, number_decode_gates_driven_per_predecode_output);
	}
    number_decode_gates_driven_per_predecode_output = 1;
    initialize_predecoder_blocks(deg_bitline_muxing, &bit_mux_predec_blk_1, &bit_mux_predec_blk_2, &bit_mux_dec, 
            c_wire_bit_mux_predecode_block_output, r_wire_bit_mux_predecode_block_output, 
            number_decode_gates_driven_per_predecode_output);
    number_decode_gates_driven_per_predecode_output = 1;
    initialize_predecoder_blocks(deg_senseamp_muxing_level_1_non_associativity, &senseamp_mux_level_1_predec_blk_1, &senseamp_mux_level_1_predec_blk_2,
            &senseamp_mux_level_1_dec, c_wire_senseamp_mux_level_1_predecode_block_output, r_wire_senseamp_mux_predecode_block_output, 
            number_decode_gates_driven_per_predecode_output);
	initialize_predecoder_blocks(1, &dummy_way_select_predec_blk_1, &dummy_way_select_predec_blk_2,
            &senseamp_mux_level_1_dec, 0, 0, 0);
	initialize_predecoder_blocks(Ndsam_level_2, &senseamp_mux_level_2_predec_blk_1, &senseamp_mux_level_2_predec_blk_2,
            &senseamp_mux_level_2_dec, c_wire_senseamp_mux_level_2_predecode_block_output, r_wire_senseamp_mux_predecode_block_output, 
            number_decode_gates_driven_per_predecode_output);

	//Compute widths of transistors in row predecode, bitline mux predecode and sense amp mux predecode blocks
    compute_widths_predecoder_block(&row_predec_blk_1);
    compute_widths_predecoder_block(&row_predec_blk_2);
    compute_widths_predecoder_block(&bit_mux_predec_blk_1);
    compute_widths_predecoder_block(&bit_mux_predec_blk_2);
    compute_widths_predecoder_block(&senseamp_mux_level_1_predec_blk_1);
    compute_widths_predecoder_block(&senseamp_mux_level_1_predec_blk_2);
	compute_widths_predecoder_block(&senseamp_mux_level_2_predec_blk_1);
    compute_widths_predecoder_block(&senseamp_mux_level_2_predec_blk_2);

    //Initialize row predecode block drivers, bitline mux predecode block drivers, sense amp mux predecode block drivers and way-select drivers. 
	//These drivers are at the leaves of the vertical H-trees of the array
	if(parameters->fully_assoc){
		initialize_predecoder_block_drivers(1, 0, 0, &row_predec_blk_driver_1,
			&row_predec_blk_driver_2, &row_predec_blk_1, &row_predec_blk_2,	&row_dec);
	}
	else{
		initialize_predecoder_block_drivers(number_rows_subarray, 0, 0, &row_predec_blk_driver_1,
			&row_predec_blk_driver_2, &row_predec_blk_1, &row_predec_blk_2,	&row_dec);
	}
    initialize_predecoder_block_drivers(deg_bitline_muxing, 0, 0, &bit_mux_predec_blk_driver_1,
            &bit_mux_predec_blk_driver_2, &bit_mux_predec_blk_1, &bit_mux_predec_blk_2,	&bit_mux_dec);
    initialize_predecoder_block_drivers(deg_senseamp_muxing_level_1_non_associativity, 0, 0, &senseamp_mux_level_1_predec_blk_driver_1,
            &senseamp_mux_level_1_predec_blk_driver_2, &senseamp_mux_level_1_predec_blk_1, &senseamp_mux_level_1_predec_blk_2,	&senseamp_mux_level_1_dec);
	initialize_predecoder_block_drivers(1, 1, way_select, &way_select_driver_1,
            &dummy_way_select_driver_2, &dummy_way_select_predec_blk_1, &dummy_way_select_predec_blk_2, 
			&senseamp_mux_level_1_dec);
	initialize_predecoder_block_drivers(Ndsam_level_2, 0, 0, &senseamp_mux_level_2_predec_blk_driver_1,
            &senseamp_mux_level_2_predec_blk_driver_2, &senseamp_mux_level_2_predec_blk_1, &senseamp_mux_level_2_predec_blk_2,	&senseamp_mux_level_2_dec);

	//Compute widths of transistors in row predecode block drivers, bitline mux predecode block drivers, sense amp mux predecode block and 
	//way-select drivers. 
	compute_widths_predecoder_block_driver(&row_predec_blk_driver_1, &row_predec_blk_1, &row_dec, 0);
    compute_widths_predecoder_block_driver(&row_predec_blk_driver_2, &row_predec_blk_2, &row_dec, 0);
    compute_widths_predecoder_block_driver(&bit_mux_predec_blk_driver_1, &bit_mux_predec_blk_1, &bit_mux_dec, 0);
    compute_widths_predecoder_block_driver(&bit_mux_predec_blk_driver_2, &bit_mux_predec_blk_2, &bit_mux_dec, 0);
    compute_widths_predecoder_block_driver(&senseamp_mux_level_1_predec_blk_driver_1, &senseamp_mux_level_1_predec_blk_1, &senseamp_mux_level_1_dec, 0);
    compute_widths_predecoder_block_driver(&senseamp_mux_level_1_predec_blk_driver_2, &senseamp_mux_level_1_predec_blk_2, &senseamp_mux_level_1_dec, 0);
	compute_widths_predecoder_block_driver(&way_select_driver_1, &dummy_way_select_predec_blk_1, &senseamp_mux_level_1_dec, way_select);
	compute_widths_predecoder_block_driver(&senseamp_mux_level_2_predec_blk_driver_1, &senseamp_mux_level_2_predec_blk_1, &senseamp_mux_level_2_dec, 0);
    compute_widths_predecoder_block_driver(&senseamp_mux_level_2_predec_blk_driver_2, &senseamp_mux_level_2_predec_blk_2, &senseamp_mux_level_2_dec, 0);



	bitline_precharge_eq_driver.c_gate_load = gatecap(2 * width_pmos_bitline_precharge +
		width_pmos_bitline_equalization, 0);
	bitline_precharge_eq_driver.c_wire_load = number_cols_subarray * width_cell * 
		wire_outside_mat_c_per_micron;
	bitline_precharge_eq_driver.r_wire_load = number_cols_subarray * width_cell * 
		wire_outside_mat_r_per_micron;
	//Compute widths of transistors in driver that drives bitline precharge and equalization transistors
	initialize_driver(&bitline_precharge_eq_driver);
	compute_widths_driver(&bitline_precharge_eq_driver);

    //Calculate area of a mat
	mat = area_mat(parameters->fully_assoc, is_tag, tagbits, number_rows_subarray, number_cols_subarray, 
            number_subarrays, deg_bitline_muxing, deg_senseamp_muxing_level_1_non_associativity, Ndsam_level_1, Ndsam_level_2,
			number_addr_bits_mat, number_datain_bits_mat, number_dataout_bits_mat,
            number_way_select_signals_mat, parameters,
            &row_predec_blk_1, &row_predec_blk_2, &bit_mux_predec_blk_1, &bit_mux_predec_blk_2, 
            &senseamp_mux_level_1_predec_blk_1, &senseamp_mux_level_1_predec_blk_2, 
			&senseamp_mux_level_2_predec_blk_1, &senseamp_mux_level_2_predec_blk_2,
			&dummy_way_select_predec_blk_1, &row_dec, &bit_mux_dec, &senseamp_mux_level_1_dec, &senseamp_mux_level_2_dec,
            &row_predec_blk_driver_1, &row_predec_blk_driver_2, &bit_mux_predec_blk_driver_1,
            &bit_mux_predec_blk_driver_2, &senseamp_mux_level_1_predec_blk_driver_1, &senseamp_mux_level_1_predec_blk_driver_2,
			&senseamp_mux_level_2_predec_blk_driver_1, &senseamp_mux_level_2_predec_blk_driver_2,
            &way_select_driver_1, &subarray_output_htree_node);
    height_mat = mat.height;
    width_mat = mat.width;
	horizontal_htree_seg_length = width_mat / 2;
	vertical_htree_seg_length = height_mat / 2;

	if(!REPEATERS_IN_HTREE_SEGMENTS){//No repeaters in the H-tree segments
		initialize_addr_datain_htree(horizontal_addr_din_htree_node, 
					number_horizontal_htree_nodes, horizontal_htree_seg_length, 
					&delay_addr_din_horizontal_htree, 
					&power_addr_datain_horizontal_htree, 
					length_wire_htree_node);

		compute_widths_addr_datain_htree(horizontal_addr_din_htree_node, 
					number_horizontal_htree_nodes);

		initialize_addr_datain_htree(vertical_addr_din_htree_node, number_vertical_htree_nodes, 
				vertical_htree_seg_length, &delay_addr_din_vertical_htree, 
				&power_addr_datain_htree, length_wire_htree_node);	

		compute_widths_addr_datain_htree(vertical_addr_din_htree_node, number_vertical_htree_nodes);

		initialize_dataout_htree(dout_htree_node, number_vertical_htree_nodes, &delay_dout_vertical_htree, 
								 &power_dout_htree, length_wire_htree_node);

		compute_widths_dataout_htree(dout_htree_node, number_vertical_htree_nodes);
	}
	else{//There are repeaters in the H-tree segments
		initialize_addr_datain_htree_with_repeaters(
			&horizontal_addr_datain_htree_at_mat_interval, &delay_addr_din_horizontal_htree, 
			&power_addr_datain_horizontal_htree, 2 * horizontal_htree_seg_length);

		initialize_addr_datain_htree_with_repeaters(
			&vertical_addr_datain_htree_at_mat_interval, &delay_addr_din_vertical_htree, 
			&power_addr_datain_htree, 2 * vertical_htree_seg_length);
	}


	//Calculate area of a bank
    bank = area_single_bank(number_rows_subarray, is_tag, parameters, &arearesult_temp, 
            number_horizontal_htree_nodes, number_vertical_htree_nodes, number_tristate_horizontal_htree_nodes,
            number_mats_horizontal_direction, 
            number_mats_vertical_direction, number_activated_mats_horizontal_direction,
            number_addr_bits_mat, number_way_select_signals_mat, tagbits, 
            number_datain_bits_mat, number_dataout_bits_mat,
			number_datain_bits_subbank, number_dataout_bits_subbank,
            horizontal_addr_din_htree_node, vertical_addr_din_htree_node, 
            dout_htree_node, &horizontal_addr_intcnt_segment_within_bank, 
            &horizontal_datain_intcnt_segment_within_bank, ptr_bnk_htree_sizing,
            &row_predec_blk_1, &row_predec_blk_2, &bit_mux_predec_blk_1, 
            &bit_mux_predec_blk_2, &senseamp_mux_level_1_predec_blk_1, &senseamp_mux_level_1_predec_blk_2, 
			&senseamp_mux_level_2_predec_blk_1, &senseamp_mux_level_2_predec_blk_2,
            &row_dec, &bit_mux_dec, &senseamp_mux_level_1_dec, &senseamp_mux_level_2_dec, &row_predec_blk_driver_1, 
            &row_predec_blk_driver_2, &bit_mux_predec_blk_driver_1,
            &bit_mux_predec_blk_driver_2, &senseamp_mux_level_1_predec_blk_driver_1, 
            &senseamp_mux_level_1_predec_blk_driver_2, &senseamp_mux_level_2_predec_blk_driver_1, 
            &senseamp_mux_level_2_predec_blk_driver_2, &tot_power, 
            &tot_power_row_predecode_block_drivers, 
            &tot_power_bit_mux_predecode_block_drivers, 
            &tot_power_senseamp_mux_level_1_predecode_block_drivers, &tot_power_senseamp_mux_level_2_predecode_block_drivers,
            &tot_power_row_predecode_blocks,
            &tot_power_bit_mux_predecode_blocks,
            &tot_power_senseamp_mux_level_1_predecode_blocks, &tot_power_senseamp_mux_level_2_predecode_blocks, &tot_power_row_decoders,
            &tot_power_bit_mux_decoders, &tot_power_senseamp_mux_level_1_decoders, &tot_power_senseamp_mux_level_2_decoders);

	//Calculate area of all banks
	all_banks = area_all_banks(parameters->number_banks, bank.height, bank.width, 
		number_bits_routed_to_bank, &length_htree_route_to_bank, number_mats_vertical_direction, is_main_mem,
		number_addr_bits_routed_to_bank, number_data_bits_routed_to_bank);	

	number_redundant_mats = parameters->number_banks * number_mats / NUMBER_MATS_PER_REDUNDANT_MAT;
	if(number_redundant_mats > 0){
		//Arrange redundant mats horizontally
		all_banks.area = all_banks.height * all_banks.width + 
			height_mat * width_mat * number_redundant_mats;
		all_banks.height = all_banks.area / all_banks.width;
	}
 
	reset_powerDef(&power_routing_to_bank);
	inrisetime = 0;
	horizontal_htree_input_load = gatecap(ptr_bnk_htree_sizing->nand2_buffer_width_n[0] +
		ptr_bnk_htree_sizing->nand2_buffer_width_p[0], 0);
	delay_route_to_bank = 0;
	if(!is_tag){
		length_htree_route_to_bank += LENGTH_INTERCONNECT_FROM_BANK_TO_CROSSBAR;
	}

	delay_array_edge_to_bank_edge_htree(ptr_arr_edge_to_bank_edge_htree_sizing, length_htree_route_to_bank, horizontal_htree_input_load, 
		&delay_route_to_bank, inrisetime, &outrisetime, &power_routing_to_bank);

	c_crossbar_output_line_load = gatecap(ptr_arr_edge_to_bank_edge_htree_sizing->opt_sizing * minimum_width_nmos + pmos_to_nmos_sizing_r * 
		ptr_arr_edge_to_bank_edge_htree_sizing->opt_sizing * minimum_width_nmos, 0);
	initialize_crossbar(&crossbar_instance, NUMBER_INPUT_PORTS_CROSSBAR, NUMBER_OUTPUT_PORTS_CROSSBAR, NUMBER_SIGNALS_PER_PORT_CROSSBAR, c_crossbar_output_line_load);
	if((IS_CROSSBAR)&&(!is_tag)){
		compute_widths_crossbar(&crossbar_instance);
		inrisetime = 0;
		delay_crossbar(&crossbar_instance, inrisetime, &outrisetime);
		area_crossbar(&crossbar_instance);
	}

	delay_route_to_bank += FO4 * (NUMBER_STACKED_DIE_LAYERS - 1) + crossbar_instance.delay;

    inrisetime = 0;
	if(!REPEATERS_IN_HTREE_SEGMENTS){
		delay_addr_datain_htree(horizontal_addr_din_htree_node, number_horizontal_htree_nodes, 
			inrisetime, &outrisetime, &delay_addr_din_horizontal_htree);
		inrisetime = 0;
		delay_addr_datain_htree(vertical_addr_din_htree_node, number_vertical_htree_nodes, inrisetime, &outrisetime, 
            &delay_addr_din_vertical_htree);
		inrisetime = 0;
	}
	else{    
		htree_output_load = gatecap(ptr_bnk_htree_sizing->nand2_buffer_width_n[0] +
		ptr_bnk_htree_sizing->nand2_buffer_width_p[0], 0);
		delay_addr_datain_htree_with_repeaters(ptr_bnk_htree_sizing, &horizontal_addr_datain_htree_at_mat_interval, 
			htree_output_load, number_horizontal_htree_nodes, 1, &delay_addr_din_horizontal_htree,
			inrisetime, &outrisetime);

		inrisetime = 0;
		htree_output_load = gatecap(minimum_width_nmos + pmos_to_nmos_sizing_r * minimum_width_nmos, 0);
		delay_addr_datain_htree_with_repeaters(ptr_bnk_htree_sizing, &vertical_addr_datain_htree_at_mat_interval, 
			htree_output_load, number_vertical_htree_nodes, BROADCAST_ADDR_DATAIN_OVER_VERTICAL_HTREES, &delay_addr_din_vertical_htree,
			inrisetime, &outrisetime);
		inrisetime = 0;
	}

	delay_dout_horizontal_htree = delay_addr_din_horizontal_htree;

	reset_powerDef(&power_fa_decoder);
	if((parameters->fully_assoc)&&(is_tag)){//Fully-associative cache tag decoder delay
		delay_fa_tag(tagbits, Ndbl, number_rows_subarray, &delay_fa_decoder, &power_fa_decoder);
	}

    delay_predecoder_block_driver(&row_predec_blk_driver_1, inrisetime, inrisetime, 
            &outrisetime_nand2_row_decode_path_1, &outrisetime_nand3_row_decode_path_1);
    delay_predecoder_block_driver(&row_predec_blk_driver_2, inrisetime, inrisetime,
            &outrisetime_nand2_row_decode_path_2, &outrisetime_nand3_row_decode_path_2);
    delay_predecoder_block_driver(&bit_mux_predec_blk_driver_1, inrisetime, inrisetime, 
            &outrisetime_nand2_bit_mux_decode_path_1, &outrisetime_nand3_bit_mux_decode_path_1);
    delay_predecoder_block_driver(&bit_mux_predec_blk_driver_2, inrisetime, inrisetime, 
            &outrisetime_nand2_bit_mux_decode_path_2, &outrisetime_nand3_bit_mux_decode_path_2);
    delay_predecoder_block_driver(&senseamp_mux_level_1_predec_blk_driver_1, inrisetime, inrisetime, 
            &outrisetime_nand2_senseamp_mux_level_1_decode_path_1, &outrisetime_nand3_senseamp_mux_level_1_decode_path_1);
    delay_predecoder_block_driver(&senseamp_mux_level_1_predec_blk_driver_2, inrisetime, inrisetime, 
            &outrisetime_nand2_senseamp_mux_level_1_decode_path_2, &outrisetime_nand3_senseamp_mux_level_1_decode_path_2);
	delay_predecoder_block_driver(&senseamp_mux_level_2_predec_blk_driver_1, inrisetime, inrisetime, 
            &outrisetime_nand2_senseamp_mux_level_2_decode_path_1, &outrisetime_nand3_senseamp_mux_level_2_decode_path_1);
    delay_predecoder_block_driver(&senseamp_mux_level_2_predec_blk_driver_2, inrisetime, inrisetime, 
            &outrisetime_nand2_senseamp_mux_level_2_decode_path_2, &outrisetime_nand3_senseamp_mux_level_2_decode_path_2);

    delay_predecoder_block(&row_predec_blk_1, outrisetime_nand2_row_decode_path_1,
            outrisetime_nand3_row_decode_path_1, &outrisetime_nand2_row_decode_path_1,
            &outrisetime_nand3_row_decode_path_1);
    delay_predecoder_block(&row_predec_blk_2, outrisetime_nand2_row_decode_path_2,
            outrisetime_nand3_row_decode_path_2, &outrisetime_nand2_row_decode_path_2,
            &outrisetime_nand3_row_decode_path_2);
    delay_predecoder_block(&bit_mux_predec_blk_1, outrisetime_nand2_bit_mux_decode_path_1,
            outrisetime_nand3_bit_mux_decode_path_1, &outrisetime_nand2_bit_mux_decode_path_1,
            &outrisetime_nand3_bit_mux_decode_path_1);
    delay_predecoder_block(&bit_mux_predec_blk_2, outrisetime_nand2_bit_mux_decode_path_2,
            outrisetime_nand3_bit_mux_decode_path_2, &outrisetime_nand2_bit_mux_decode_path_2,
            &outrisetime_nand3_bit_mux_decode_path_2);
    delay_predecoder_block(&senseamp_mux_level_1_predec_blk_1, outrisetime_nand2_senseamp_mux_level_1_decode_path_1,
            outrisetime_nand3_senseamp_mux_level_1_decode_path_1, &outrisetime_nand2_senseamp_mux_level_1_decode_path_1,
            &outrisetime_nand3_senseamp_mux_level_1_decode_path_1);
    delay_predecoder_block(&senseamp_mux_level_1_predec_blk_2, outrisetime_nand2_senseamp_mux_level_1_decode_path_2,
            outrisetime_nand3_senseamp_mux_level_1_decode_path_2, &outrisetime_nand2_senseamp_mux_level_1_decode_path_2,
            &outrisetime_nand3_senseamp_mux_level_1_decode_path_2);
	delay_predecoder_block(&senseamp_mux_level_2_predec_blk_1, outrisetime_nand2_senseamp_mux_level_2_decode_path_1,
            outrisetime_nand3_senseamp_mux_level_2_decode_path_1, &outrisetime_nand2_senseamp_mux_level_2_decode_path_1,
            &outrisetime_nand3_senseamp_mux_level_2_decode_path_1);
    delay_predecoder_block(&senseamp_mux_level_2_predec_blk_2, outrisetime_nand2_senseamp_mux_level_2_decode_path_2,
            outrisetime_nand3_senseamp_mux_level_2_decode_path_2, &outrisetime_nand2_senseamp_mux_level_2_decode_path_2,
            &outrisetime_nand3_senseamp_mux_level_2_decode_path_2);

    delay_before_row_decoder_nand2_path_1 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree +
        row_predec_blk_driver_1.delay_nand2_path + row_predec_blk_1.delay_nand2_path;
    delay_before_row_decoder_nand3_path_1 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        row_predec_blk_driver_1.delay_nand3_path + row_predec_blk_1.delay_nand3_path;
    delay_before_row_decoder_nand2_path_2 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree +
        row_predec_blk_driver_2.delay_nand2_path + row_predec_blk_2.delay_nand2_path;
    delay_before_row_decoder_nand3_path_2 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        row_predec_blk_driver_2.delay_nand3_path + row_predec_blk_2.delay_nand3_path;

    max_delay_before_row_decoder = delay_before_row_decoder_nand2_path_1;
    row_dec_inrisetime = outrisetime_nand2_row_decode_path_1;
    if(delay_before_row_decoder_nand3_path_1 > max_delay_before_row_decoder){
        max_delay_before_row_decoder = delay_before_row_decoder_nand3_path_1;
        row_dec_inrisetime = outrisetime_nand3_row_decode_path_1;
    }
    if(delay_before_row_decoder_nand2_path_2 > max_delay_before_row_decoder){
        max_delay_before_row_decoder = delay_before_row_decoder_nand2_path_2;
        row_dec_inrisetime = outrisetime_nand2_row_decode_path_2;
    }
    if(delay_before_row_decoder_nand3_path_2 > max_delay_before_row_decoder){
        max_delay_before_row_decoder = delay_before_row_decoder_nand3_path_2;
        row_dec_inrisetime = outrisetime_nand3_row_decode_path_2;
    }

    delay_before_bit_mux_decoder_nand2_path_1 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        bit_mux_predec_blk_driver_1.delay_nand2_path + bit_mux_predec_blk_1.delay_nand2_path;
    delay_before_bit_mux_decoder_nand3_path_1 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree +
        bit_mux_predec_blk_driver_1.delay_nand3_path + bit_mux_predec_blk_1.delay_nand3_path;
    delay_before_bit_mux_decoder_nand2_path_2 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree +	
        bit_mux_predec_blk_driver_2.delay_nand2_path + bit_mux_predec_blk_2.delay_nand2_path;
    delay_before_bit_mux_decoder_nand3_path_2 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        bit_mux_predec_blk_driver_2.delay_nand3_path + bit_mux_predec_blk_2.delay_nand3_path;

    max_delay_before_bit_mux_decoder = delay_before_bit_mux_decoder_nand2_path_1;
    bit_mux_dec_inrisetime = outrisetime_nand2_bit_mux_decode_path_1;
    if(delay_before_bit_mux_decoder_nand3_path_1 > max_delay_before_bit_mux_decoder){
        max_delay_before_bit_mux_decoder = delay_before_bit_mux_decoder_nand3_path_1;
        bit_mux_dec_inrisetime = outrisetime_nand3_bit_mux_decode_path_1;
    }
    if(delay_before_bit_mux_decoder_nand2_path_2 > max_delay_before_bit_mux_decoder){
        max_delay_before_bit_mux_decoder = delay_before_bit_mux_decoder_nand2_path_2;
        bit_mux_dec_inrisetime = outrisetime_nand2_bit_mux_decode_path_2;
    }
    if(delay_before_bit_mux_decoder_nand3_path_2 > max_delay_before_bit_mux_decoder){
        max_delay_before_bit_mux_decoder = delay_before_bit_mux_decoder_nand3_path_2;
        bit_mux_dec_inrisetime = outrisetime_nand3_bit_mux_decode_path_2;
    }

    delay_before_senseamp_mux_level_1_decoder_nand2_path_1 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        senseamp_mux_level_1_predec_blk_driver_1.delay_nand2_path + senseamp_mux_level_1_predec_blk_1.delay_nand2_path;
    delay_before_senseamp_mux_level_1_decoder_nand3_path_1 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        senseamp_mux_level_1_predec_blk_driver_1.delay_nand3_path + senseamp_mux_level_1_predec_blk_1.delay_nand3_path;
    delay_before_senseamp_mux_level_1_decoder_nand2_path_2 = delay_route_to_bank +
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        senseamp_mux_level_1_predec_blk_driver_2.delay_nand2_path + senseamp_mux_level_1_predec_blk_2.delay_nand2_path;
    delay_before_senseamp_mux_level_1_decoder_nand3_path_2 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        senseamp_mux_level_1_predec_blk_driver_2.delay_nand3_path + senseamp_mux_level_1_predec_blk_2.delay_nand3_path;
	delay_before_senseamp_mux_level_2_decoder_nand2_path_1 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        senseamp_mux_level_2_predec_blk_driver_1.delay_nand2_path + senseamp_mux_level_2_predec_blk_1.delay_nand2_path;
    delay_before_senseamp_mux_level_2_decoder_nand3_path_1 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        senseamp_mux_level_2_predec_blk_driver_1.delay_nand3_path + senseamp_mux_level_2_predec_blk_1.delay_nand3_path;
    delay_before_senseamp_mux_level_2_decoder_nand2_path_2 = delay_route_to_bank +
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        senseamp_mux_level_2_predec_blk_driver_2.delay_nand2_path + senseamp_mux_level_2_predec_blk_2.delay_nand2_path;
    delay_before_senseamp_mux_level_2_decoder_nand3_path_2 = delay_route_to_bank + 
        delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + 
        senseamp_mux_level_2_predec_blk_driver_2.delay_nand3_path + senseamp_mux_level_2_predec_blk_2.delay_nand3_path;

    max_delay_before_senseamp_mux_level_1_decoder = delay_before_senseamp_mux_level_1_decoder_nand2_path_1;
    senseamp_mux_level_1_dec_inrisetime = outrisetime_nand2_senseamp_mux_level_1_decode_path_1;
    if(delay_before_senseamp_mux_level_1_decoder_nand3_path_1 > max_delay_before_senseamp_mux_level_1_decoder){
        max_delay_before_senseamp_mux_level_1_decoder = delay_before_senseamp_mux_level_1_decoder_nand3_path_1;
        senseamp_mux_level_1_dec_inrisetime = outrisetime_nand3_senseamp_mux_level_1_decode_path_1;
    }
    if(delay_before_senseamp_mux_level_1_decoder_nand2_path_2 > max_delay_before_senseamp_mux_level_1_decoder){
        max_delay_before_senseamp_mux_level_1_decoder = delay_before_senseamp_mux_level_1_decoder_nand2_path_2;
        senseamp_mux_level_1_dec_inrisetime = outrisetime_nand2_senseamp_mux_level_1_decode_path_2;
    }
    if(delay_before_senseamp_mux_level_1_decoder_nand3_path_2 > max_delay_before_senseamp_mux_level_1_decoder){
        max_delay_before_senseamp_mux_level_1_decoder = delay_before_senseamp_mux_level_1_decoder_nand3_path_2;
        senseamp_mux_level_1_dec_inrisetime = outrisetime_nand3_senseamp_mux_level_1_decode_path_2;
    }

	max_delay_before_senseamp_mux_level_2_decoder = delay_before_senseamp_mux_level_2_decoder_nand2_path_1;
    senseamp_mux_level_2_dec_inrisetime = outrisetime_nand2_senseamp_mux_level_2_decode_path_1;
    if(delay_before_senseamp_mux_level_2_decoder_nand3_path_1 > max_delay_before_senseamp_mux_level_2_decoder){
        max_delay_before_senseamp_mux_level_2_decoder = delay_before_senseamp_mux_level_2_decoder_nand3_path_1;
        senseamp_mux_level_2_dec_inrisetime = outrisetime_nand3_senseamp_mux_level_2_decode_path_1;
    }
    if(delay_before_senseamp_mux_level_2_decoder_nand2_path_2 > max_delay_before_senseamp_mux_level_2_decoder){
        max_delay_before_senseamp_mux_level_2_decoder = delay_before_senseamp_mux_level_2_decoder_nand2_path_2;
        senseamp_mux_level_2_dec_inrisetime = outrisetime_nand2_senseamp_mux_level_2_decode_path_2;
    }
    if(delay_before_senseamp_mux_level_2_decoder_nand3_path_2 > max_delay_before_senseamp_mux_level_2_decoder){
        max_delay_before_senseamp_mux_level_2_decoder = delay_before_senseamp_mux_level_2_decoder_nand3_path_2;
        senseamp_mux_level_2_dec_inrisetime = outrisetime_nand3_senseamp_mux_level_2_decode_path_2;
    }


	is_wordline_transistor = 1;
    delay_decoder(&row_dec, row_dec_inrisetime, &row_dec_outrisetime);
	is_wordline_transistor = 0;
    delay_decoder(&bit_mux_dec, bit_mux_dec_inrisetime, &bit_mux_dec_outrisetime);
    delay_decoder(&senseamp_mux_level_1_dec, senseamp_mux_level_1_dec_inrisetime, &senseamp_mux_level_1_dec_outrisetime);
	delay_decoder(&senseamp_mux_level_2_dec, senseamp_mux_level_2_dec_inrisetime, &senseamp_mux_level_2_dec_outrisetime);

    Tpre = max_delay_before_row_decoder + row_dec.delay;
    reset_powerDef(&bitline_data_power);
	leakage_power_cc_inverters_sram_cell = 0;
	leakage_power_access_transistors_read_write_port_sram_cell = 0;
	leakage_power_read_only_port_sram_cell = 0;
    bitline_data = bitline_delay(number_rows_subarray, number_cols_subarray, number_subarrays, 
            row_dec_outrisetime, &outrisetime, &bitline_data_power, &per_bitline_read_energy, deg_bitline_muxing, Ndsam_level_1 * Ndsam_level_2,
            number_activated_mats_horizontal_direction, &writeback_delay, 
			parameters->num_readwrite_ports, parameters->num_read_ports, parameters->num_write_ports);

    wordline_data = row_dec.delay;
    inrisetime = outrisetime;

    reset_powerDef(&sense_amp_data_power);
	delay_sense_amplifier(number_cols_subarray, parameters->num_readwrite_ports, parameters->num_read_ports, inrisetime, &outrisetime, &sense_amp_data_power, 
            &subarray_output_htree_node, deg_bitline_muxing, number_mats, number_activated_mats_horizontal_direction, 
            &delay_sense_amp, &leak_power_sense_amps_closed_page_state, &leak_power_sense_amps_open_page_state);
    inrisetime = outrisetime;
    reset_powerDef(&power_output_drivers_at_subarray);
    delay_output_driver_at_subarray(deg_bitline_muxing, Ndsam_level_1, Ndsam_level_2, parameters->num_readwrite_ports, parameters->num_read_ports,
		inrisetime, &outrisetime, &power_output_drivers_at_subarray, &subarray_output_htree_node, number_mats, &delay_subarray_output_driver,
            &delay_final_stage_subarray_output_driver);
	if(!REPEATERS_IN_HTREE_SEGMENTS){
		delay_dataout_vertical_htree(dout_htree_node, number_vertical_htree_nodes, inrisetime, &outrisetime, &delay_dout_vertical_htree,
            &power_dout_htree);
		inrisetime = 0;
	}
	else{
		delay_datout_vertical_htree_with_repeaters(ptr_bnk_htree_sizing, &vertical_addr_datain_htree_at_mat_interval,
			number_vertical_htree_nodes, &delay_dout_vertical_htree, inrisetime, &outrisetime);
		inrisetime = 0;
	}

    delay_data_access_row_path =  max_delay_before_row_decoder + row_dec.delay + bitline_data + 
        delay_sense_amp +  delay_subarray_output_driver + delay_dout_vertical_htree + 
        delay_dout_horizontal_htree + delay_route_to_bank;
    delay_data_access_col_path = max_delay_before_bit_mux_decoder + bit_mux_dec.delay +	delay_sense_amp +  
        delay_subarray_output_driver + delay_dout_vertical_htree + delay_dout_horizontal_htree + 
        delay_route_to_bank;
    delay_data_access_senseamp_mux_level_1_path = max_delay_before_senseamp_mux_level_1_decoder + senseamp_mux_level_1_dec.delay + 
        delay_subarray_output_driver + 	delay_dout_vertical_htree + delay_dout_horizontal_htree + 
        delay_route_to_bank;
	delay_data_access_senseamp_mux_level_2_path = max_delay_before_senseamp_mux_level_2_decoder + senseamp_mux_level_2_dec.delay + 
        delay_subarray_output_driver + 	delay_dout_vertical_htree + delay_dout_horizontal_htree + 
        delay_route_to_bank;
    temp_delay_data_access_path = MAX(delay_data_access_row_path, delay_data_access_col_path);
    delay_data_access_path = MAX(temp_delay_data_access_path, MAX(delay_data_access_senseamp_mux_level_1_path, delay_data_access_senseamp_mux_level_2_path));
    delay_before_subarray_output_driver = delay_data_access_path - 
        (delay_subarray_output_driver + delay_dout_vertical_htree + delay_dout_horizontal_htree + 
         delay_route_to_bank);
    delay_from_subarray_output_driver_to_output = delay_subarray_output_driver + delay_dout_vertical_htree +
        delay_dout_horizontal_htree + delay_route_to_bank;

	if((is_tag)&&(parameters->fully_assoc)){//delay of fully-associative tag decoder
		access_time = delay_route_to_bank + delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree + delay_fa_decoder;
	}
	else if(parameters->fully_assoc){//delay of fully-associative data array
		access_time = row_dec.delay + bitline_data +  delay_sense_amp +  delay_subarray_output_driver + delay_dout_vertical_htree + 
			delay_dout_horizontal_htree + delay_route_to_bank;;
	}
	else{
		access_time = delay_data_access_path;
	}
	if(is_main_mem){
		t_rcd = max_delay_before_row_decoder + row_dec.delay + bitline_data + delay_sense_amp;
		cas_latency = MAX(max_delay_before_senseamp_mux_level_1_decoder + senseamp_mux_level_1_dec.delay, max_delay_before_senseamp_mux_level_2_decoder + senseamp_mux_level_2_dec.delay) + 
			delay_subarray_output_driver + delay_dout_vertical_htree + delay_dout_horizontal_htree +  
			delay_route_to_bank;
		access_time = t_rcd + cas_latency;
		/*access_time = max_delay_before_row_decoder + row_dec.delay + bitline_data + 
        delay_sense_amp + MAX(max_delay_before_bit_mux_decoder + bit_mux_dec.delay, 
		max_delay_before_senseamp_mux_decoder + senseamp_mux_dec.delay) + 
		delay_subarray_output_driver + delay_dout_vertical_htree + delay_dout_horizontal_htree +  
		delay_route_to_bank;*/
	}


    reset_powerDef(&comparator_power);
    if((is_tag)&&(!parameters->fully_assoc)){
        delay_comparator(tagbits, parameters->tag_associativity, inrisetime, &outrisetime,
                &comparator_delay, &comparator_power);
        access_time += comparator_delay;
    }
    else{
        comparator_delay = 0;
    }


	if(!((is_tag)&&(parameters->fully_assoc))){
    delay_driver(&bitline_precharge_eq_driver, 0, &dummy_precharge_outrisetime);
	k = row_dec.number_gates - 1;
	is_wordline_transistor = 1;
	rd = transreson(row_dec.width_decoder_n[k], NCH, 1);
	c_intrinsic = draincap(row_dec.width_decoder_p[k], PCH, 1, 1, 4 * height_cell) + 
		draincap(row_dec.width_decoder_n[k], NCH, 1, 1, 4 * height_cell);
	is_wordline_transistor = 0;
	c_load = row_dec.c_load_decoder_output;
	tf = rd * (c_intrinsic + c_load) + row_dec.r_wire_decoder_output * c_load / 2;
	wordline_reset_delay = horowitz(0, tf, 0.5, 0.5, RISE);
	r_bitline_precharge = transreson(width_pmos_bitline_precharge, PCH, 1);
	r_bitline = number_rows_subarray * Rbitmetal;
    if((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)){
		bitline_restore_delay = bitline_precharge_eq_driver.delay + 
			2.3 * (r_bitline_precharge * Cbitline + r_bitline * Cbitline / 2);
        temp = wordline_data + bitline_data + delay_sense_amp + writeback_delay +
			wordline_reset_delay + bitline_restore_delay;//temp stores random cycle time
    }
    else{
		bitline_restore_delay = bitline_precharge_eq_driver.delay + 
			log((Vbitpre_sram - 0.1 * Vbitsense) / (Vbitpre_sram - Vbitsense)) * (r_bitline_precharge * Cbitline + 
			r_bitline * Cbitline / 2);
		temp = wordline_data + bitline_data + wordline_reset_delay + delay_sense_amp + bitline_restore_delay;	
    }
	}
	else{
		temp = delay_fa_decoder;
	}
	delay_within_mat_before_row_decoder = max_delay_before_row_decoder - 
		(delay_route_to_bank + delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree);
	delay_within_mat_before_bit_mux_decoder = max_delay_before_bit_mux_decoder - 
			(delay_route_to_bank + delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree);
	delay_within_mat_before_senseamp_mux_level_1_decoder = max_delay_before_senseamp_mux_level_1_decoder -
		(delay_route_to_bank + delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree);
	delay_within_mat_before_senseamp_mux_level_2_decoder = max_delay_before_senseamp_mux_level_2_decoder - 
			(delay_route_to_bank + delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree);
	temp = MAX(temp, delay_within_mat_before_row_decoder);
	temp = MAX(temp, delay_within_mat_before_bit_mux_decoder);
	temp = MAX(temp, delay_within_mat_before_senseamp_mux_level_1_decoder);
	temp = MAX(temp, delay_within_mat_before_senseamp_mux_level_2_decoder);
	temp = MAX(temp, horizontal_addr_datain_htree_at_mat_interval.max_delay_between_buffers);
	temp = MAX(temp, vertical_addr_datain_htree_at_mat_interval.max_delay_between_buffers);
	cycle_time = temp;

	
	temp = max_delay_before_row_decoder;
	//temp = MAX(max_delay_before_row_decoder, max_delay_before_bit_mux_decoder);
	//temp = MAX(temp, max_delay_before_senseamp_mux_level_1_decoder);
	//temp = MAX(temp, max_delay_before_senseamp_mux_level_2_decoder);
	temp = MAX(temp, delay_subarray_output_driver + delay_dout_vertical_htree + delay_dout_horizontal_htree +
		delay_route_to_bank);
	//multisubbank_interleave_cycle_time = MIN(temp, cycle_time);
	multisubbank_interleave_cycle_time = temp;

	delay_request_network = max_delay_before_row_decoder;
	delay_inside_mat = wordline_data + bitline_data + delay_sense_amp;
	delay_reply_network = delay_subarray_output_driver + delay_dout_vertical_htree + delay_dout_horizontal_htree + delay_route_to_bank;

	if(is_main_mem){
		multisubbank_interleave_cycle_time = delay_route_to_bank;
		//precharge_delay = delay_route_to_bank +  delay_addr_din_horizontal_htree + 
			//delay_addr_din_vertical_htree + wordline_reset_delay + bitline_restore_delay;
		precharge_delay = delay_route_to_bank +  delay_addr_din_horizontal_htree + 
			delay_addr_din_vertical_htree + writeback_delay + wordline_reset_delay + bitline_restore_delay;
		cycle_time = access_time + precharge_delay;
		/*cycle_time = max_delay_before_row_decoder + row_dec.delay + bitline_data + 
        delay_sense_amp + MAX(max_delay_before_bit_mux_decoder + bit_mux_dec.delay, 
		max_delay_before_senseamp_mux_decoder + senseamp_mux_dec.delay) + 
		delay_subarray_output_driver + delay_dout_vertical_htree + delay_dout_horizontal_htree +  
		delay_route_to_bank + wordline_reset_delay + writeback_delay + bitline_restore_delay*/;
	}

	if((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)){
		dram_array_availability = (1 - number_rows_subarray * cycle_time / dram_refresh_period) * 100;
	}
	else{
		dram_array_availability = 0;
	}

	number_addr_bits_routed_to_bank_for_activate = number_addr_bits_row_decode + number_subbanks_decode;
	number_addr_bits_routed_to_bank_for_read_or_write = number_addr_bits_mat - number_addr_bits_row_decode + number_subbanks_decode;
	number_addr_bits_routed_to_mat_for_activate = number_addr_bits_row_decode;
	number_addr_bits_routed_to_mat_for_read_or_write = number_addr_bits_mat - number_addr_bits_row_decode;
	//Calculate dynamic energy per access. Note that the name of the variables have "power" in them but readOp.dynamic is actually energy. readop.leakage is power. 
   if(!is_tag){
		tot_power_routing_to_bank.readOp.dynamic = power_routing_to_bank.readOp.dynamic *
			(number_addr_bits_routed_to_bank + number_data_bits_routed_to_bank / 2 +
			number_comparator_bits_routed_to_bank);
		tot_power_routing_to_bank.writeOp.dynamic = tot_power_routing_to_bank.readOp.dynamic;
		tot_power_crossbar.readOp.dynamic = number_dataout_bits_subbank * crossbar_instance.power.readOp.dynamic;
		routing_to_bank_for_activate_energy = number_addr_bits_routed_to_bank_for_activate * power_routing_to_bank.readOp.dynamic;
		routing_addr_to_bank_for_read_or_write_energy = number_addr_bits_routed_to_bank_for_read_or_write * power_routing_to_bank.readOp.dynamic;
		routing_datain_bits_to_bank_energy_for_write = (number_data_bits_routed_to_bank / 2) * power_routing_to_bank.readOp.dynamic;
	}
	else{
		tot_power_routing_to_bank.readOp.dynamic = power_routing_to_bank.readOp.dynamic *
			(number_addr_bits_routed_to_bank + tagbits + parameters->data_associativity);
		tot_power_routing_to_bank.writeOp.dynamic = power_routing_to_bank.writeOp.dynamic *
			(number_addr_bits_routed_to_bank + tagbits);
	}
    tot_power.readOp.dynamic += tot_power_routing_to_bank.readOp.dynamic;
	tot_power.readOp.dynamic += tot_power_crossbar.readOp.dynamic;
	
	//Add energy consumed in the horizontal H-trees within a bank
    htree_seg_multiplier = 1;
	length_htree_segment = pow(2, number_horizontal_htree_nodes - 1) * 
		horizontal_addr_datain_htree_at_mat_interval.mat_dimension / 2;
	for(k = 0; k < number_horizontal_htree_nodes; ++k){
		power_addr_datain_htree_node(&horizontal_addr_din_htree_node[k], 
			&power_addr_datain_horizontal_htree_node);
		if(REPEATERS_IN_HTREE_SEGMENTS){
			power_addr_datain_htree_node_at_mat_interval(ptr_bnk_htree_sizing, &horizontal_addr_datain_htree_at_mat_interval, 
				length_htree_segment, number_horizontal_htree_nodes, k, &power_addr_datain_horizontal_htree_node);
		}
        tot_power_addr_horizontal_htree.readOp.dynamic +=
            (number_addr_bits_mat + number_way_select_signals_mat) * 
			power_addr_datain_horizontal_htree_node.readOp.dynamic * htree_seg_multiplier;
        tot_power_datain_horizontal_htree.readOp.dynamic += BURST_LENGTH * number_datain_bits_mat * 
			number_mats_horizontal_direction *	power_addr_datain_horizontal_htree_node.readOp.dynamic;
        tot_power_dataout_horizontal_htree.readOp.dynamic += BURST_LENGTH * number_dataout_bits_mat * 
            number_mats_horizontal_direction *	power_addr_datain_horizontal_htree_node.readOp.dynamic;
		horizontal_htree_routing_energy_for_activate += number_addr_bits_routed_to_mat_for_activate * power_addr_datain_horizontal_htree_node.readOp.dynamic *
			htree_seg_multiplier;
		horizontal_addr_htree_routing_energy_for_read_or_write += number_addr_bits_routed_to_mat_for_read_or_write * power_addr_datain_horizontal_htree_node.readOp.dynamic * 
			htree_seg_multiplier;
		horizontal_datain_htree_routing_energy_for_write += number_datain_bits_mat * power_addr_datain_horizontal_htree_node.readOp.dynamic * 
			htree_seg_multiplier;
		horizontal_dataout_htree_energy_for_read += number_dataout_bits_mat * power_addr_datain_horizontal_htree_node.readOp.dynamic * 
			htree_seg_multiplier;
        htree_seg_multiplier *= 2;
		length_htree_segment /= 2;
    }

	tot_power.readOp.dynamic += tot_power_addr_horizontal_htree.readOp.dynamic +
         + tot_power_dataout_horizontal_htree.readOp.dynamic;	

	//Add energy consumed in address/datain vertical htree
	htree_seg_multiplier = 1;
	length_htree_segment = pow(2, number_vertical_htree_nodes - 1) * 
		vertical_addr_datain_htree_at_mat_interval.mat_dimension / 2;
	for(k = 0; k < number_vertical_htree_nodes; ++k){
		power_addr_datain_htree_node(&vertical_addr_din_htree_node[k], &power_addr_datain_vertical_htree_node);
		if(REPEATERS_IN_HTREE_SEGMENTS){
			power_addr_datain_htree_node_at_mat_interval(ptr_bnk_htree_sizing, &vertical_addr_datain_htree_at_mat_interval, 
				length_htree_segment, number_vertical_htree_nodes, k, &power_addr_datain_vertical_htree_node);
		}
        tot_power_addr_vertical_htree.readOp.dynamic +=  
			(number_addr_bits_mat + number_way_select_signals_mat) * 
			power_addr_datain_vertical_htree_node.readOp.dynamic * htree_seg_multiplier * 
			number_activated_mats_horizontal_direction;
        tot_power_datain_vertical_htree.readOp.dynamic += BURST_LENGTH * number_datain_bits_mat * 
			power_addr_datain_vertical_htree_node.readOp.dynamic * htree_seg_multiplier * 	
			number_activated_mats_horizontal_direction;
		vertical_htree_routing_energy_for_activate += number_addr_bits_routed_to_mat_for_activate * 
			power_addr_datain_vertical_htree_node.readOp.dynamic * htree_seg_multiplier * 
			number_activated_mats_horizontal_direction;
		vertical_addr_htree_routing_energy_for_read_or_write += number_addr_bits_routed_to_mat_for_read_or_write * 
			power_addr_datain_vertical_htree_node.readOp.dynamic * htree_seg_multiplier * 
			number_activated_mats_horizontal_direction;
		vertical_datain_htree_routing_energy_for_write += number_datain_bits_mat * 
			power_addr_datain_vertical_htree_node.readOp.dynamic * htree_seg_multiplier * 
			number_activated_mats_horizontal_direction;
		if(BROADCAST_ADDR_DATAIN_OVER_VERTICAL_HTREES){
			htree_seg_multiplier *= 2;
		}
		else{
			htree_seg_multiplier = 1;
		}
		length_htree_segment /= 2;
    }

	if((number_mats_vertical_direction > 1)&&(BROADCAST_ADDR_DATAIN_OVER_VERTICAL_HTREES)){
		tot_power_addr_vertical_htree.readOp.dynamic *= 2; 
		tot_power_datain_vertical_htree.readOp.dynamic *= 2;
	}
	
	tot_power.readOp.dynamic += tot_power_addr_vertical_htree.readOp.dynamic;

    //Add energy consumed in predecoder drivers
    number_addr_bits_nand2_row_decode_path_1 = 
        row_predec_blk_driver_1.number_parallel_instances_driving_1_nand2_load +
        row_predec_blk_driver_1.number_parallel_instances_driving_2_nand2_load +
        row_predec_blk_driver_1.number_parallel_instances_driving_4_nand2_load;
    number_addr_bits_nand3_row_decode_path_1 = 
        row_predec_blk_driver_1.number_parallel_instances_driving_2_nand3_load +
        row_predec_blk_driver_1.number_parallel_instances_driving_8_nand3_load;
    number_addr_bits_nand2_row_decode_path_2 = 
        row_predec_blk_driver_2.number_parallel_instances_driving_1_nand2_load +
        row_predec_blk_driver_2.number_parallel_instances_driving_2_nand2_load +
        row_predec_blk_driver_2.number_parallel_instances_driving_4_nand2_load;
    number_addr_bits_nand3_row_decode_path_2 = 
        row_predec_blk_driver_2.number_parallel_instances_driving_2_nand3_load +
        row_predec_blk_driver_2.number_parallel_instances_driving_8_nand3_load;
    number_addr_bits_nand2_bit_mux_decode_path_1 = 
        bit_mux_predec_blk_driver_1.number_parallel_instances_driving_1_nand2_load +
        bit_mux_predec_blk_driver_1.number_parallel_instances_driving_2_nand2_load +
        bit_mux_predec_blk_driver_1.number_parallel_instances_driving_4_nand2_load;
    number_addr_bits_nand3_bit_mux_decode_path_1 = 
        bit_mux_predec_blk_driver_1.number_parallel_instances_driving_2_nand3_load +
        bit_mux_predec_blk_driver_1.number_parallel_instances_driving_8_nand3_load;
    number_addr_bits_nand2_bit_mux_decode_path_2 = 
        bit_mux_predec_blk_driver_2.number_parallel_instances_driving_1_nand2_load +
        bit_mux_predec_blk_driver_2.number_parallel_instances_driving_2_nand2_load +
        bit_mux_predec_blk_driver_2.number_parallel_instances_driving_4_nand2_load;
    number_addr_bits_nand3_bit_mux_decode_path_2 = 
        bit_mux_predec_blk_driver_2.number_parallel_instances_driving_2_nand3_load +
        bit_mux_predec_blk_driver_2.number_parallel_instances_driving_8_nand3_load;
    number_addr_bits_nand2_senseamp_mux_level_1_decode_path_1 = 
        senseamp_mux_level_1_predec_blk_driver_1.number_parallel_instances_driving_1_nand2_load +
        senseamp_mux_level_1_predec_blk_driver_1.number_parallel_instances_driving_2_nand2_load +
        senseamp_mux_level_1_predec_blk_driver_1.number_parallel_instances_driving_4_nand2_load;
    number_addr_bits_nand3_senseamp_mux_level_1_decode_path_1 = 
        senseamp_mux_level_1_predec_blk_driver_1.number_parallel_instances_driving_2_nand3_load +
        senseamp_mux_level_1_predec_blk_driver_1.number_parallel_instances_driving_8_nand3_load;
    number_addr_bits_nand2_senseamp_mux_level_1_decode_path_2 = 
        senseamp_mux_level_1_predec_blk_driver_2.number_parallel_instances_driving_1_nand2_load +
        senseamp_mux_level_1_predec_blk_driver_2.number_parallel_instances_driving_2_nand2_load +
        senseamp_mux_level_1_predec_blk_driver_2.number_parallel_instances_driving_4_nand2_load;
    number_addr_bits_nand3_senseamp_mux_level_1_decode_path_2 = 
        senseamp_mux_level_1_predec_blk_driver_2.number_parallel_instances_driving_2_nand3_load +
        senseamp_mux_level_1_predec_blk_driver_2.number_parallel_instances_driving_8_nand3_load;
	 number_addr_bits_nand2_senseamp_mux_level_2_decode_path_1 = 
        senseamp_mux_level_2_predec_blk_driver_1.number_parallel_instances_driving_1_nand2_load +
        senseamp_mux_level_2_predec_blk_driver_1.number_parallel_instances_driving_2_nand2_load +
        senseamp_mux_level_2_predec_blk_driver_1.number_parallel_instances_driving_4_nand2_load;
    number_addr_bits_nand3_senseamp_mux_level_2_decode_path_1 = 
        senseamp_mux_level_2_predec_blk_driver_1.number_parallel_instances_driving_2_nand3_load +
        senseamp_mux_level_2_predec_blk_driver_1.number_parallel_instances_driving_8_nand3_load;
    number_addr_bits_nand2_senseamp_mux_level_2_decode_path_2 = 
        senseamp_mux_level_2_predec_blk_driver_2.number_parallel_instances_driving_1_nand2_load +
        senseamp_mux_level_2_predec_blk_driver_2.number_parallel_instances_driving_2_nand2_load +
        senseamp_mux_level_2_predec_blk_driver_2.number_parallel_instances_driving_4_nand2_load;
    number_addr_bits_nand3_senseamp_mux_level_2_decode_path_2 = 
        senseamp_mux_level_2_predec_blk_driver_2.number_parallel_instances_driving_2_nand3_load +
        senseamp_mux_level_2_predec_blk_driver_2.number_parallel_instances_driving_8_nand3_load;

    tot_power_row_predecode_block_drivers.readOp.dynamic = 
        (number_addr_bits_nand2_row_decode_path_1 *	row_predec_blk_driver_1.power_nand2_path.readOp.dynamic + 
         number_addr_bits_nand3_row_decode_path_1 * row_predec_blk_driver_1.power_nand3_path.readOp.dynamic +
         number_addr_bits_nand2_row_decode_path_2 *	row_predec_blk_driver_2.power_nand2_path.readOp.dynamic + 
         number_addr_bits_nand3_row_decode_path_2 * row_predec_blk_driver_2.power_nand3_path.readOp.dynamic) *
        number_activated_mats_horizontal_direction;

    tot_power_bit_mux_predecode_block_drivers.readOp.dynamic  = 
        (number_addr_bits_nand2_bit_mux_decode_path_1 *	bit_mux_predec_blk_driver_1.power_nand2_path.readOp.dynamic + 
         number_addr_bits_nand3_bit_mux_decode_path_1 * bit_mux_predec_blk_driver_1.power_nand3_path.readOp.dynamic +
         number_addr_bits_nand2_bit_mux_decode_path_2 *	bit_mux_predec_blk_driver_2.power_nand2_path.readOp.dynamic + 
         number_addr_bits_nand3_bit_mux_decode_path_2 * bit_mux_predec_blk_driver_2.power_nand3_path.readOp.dynamic) *
        number_activated_mats_horizontal_direction;

    tot_power_senseamp_mux_level_1_predecode_block_drivers.readOp.dynamic = 
		(number_addr_bits_nand2_senseamp_mux_level_1_decode_path_1 * senseamp_mux_level_1_predec_blk_driver_1.power_nand2_path.readOp.dynamic + 
		number_addr_bits_nand3_senseamp_mux_level_1_decode_path_1 * senseamp_mux_level_1_predec_blk_driver_1.power_nand3_path.readOp.dynamic + 
		number_addr_bits_nand2_senseamp_mux_level_1_decode_path_2 * senseamp_mux_level_1_predec_blk_driver_2.power_nand2_path.readOp.dynamic + 
		number_addr_bits_nand3_senseamp_mux_level_1_decode_path_2 * senseamp_mux_level_1_predec_blk_driver_2.power_nand3_path.readOp.dynamic) *
		number_activated_mats_horizontal_direction;

	tot_power_senseamp_mux_level_2_predecode_block_drivers.readOp.dynamic = 
		(number_addr_bits_nand2_senseamp_mux_level_2_decode_path_1 * senseamp_mux_level_2_predec_blk_driver_1.power_nand2_path.readOp.dynamic + 
		number_addr_bits_nand3_senseamp_mux_level_2_decode_path_1 * senseamp_mux_level_2_predec_blk_driver_1.power_nand3_path.readOp.dynamic + 
		number_addr_bits_nand2_senseamp_mux_level_2_decode_path_2 * senseamp_mux_level_2_predec_blk_driver_2.power_nand2_path.readOp.dynamic + 
		number_addr_bits_nand3_senseamp_mux_level_2_decode_path_2 * senseamp_mux_level_2_predec_blk_driver_2.power_nand3_path.readOp.dynamic) *
		number_activated_mats_horizontal_direction;

    tot_power.readOp.dynamic += tot_power_row_predecode_block_drivers.readOp.dynamic +
        tot_power_bit_mux_predecode_block_drivers.readOp.dynamic +
        tot_power_senseamp_mux_level_1_predecode_block_drivers.readOp.dynamic +
		tot_power_senseamp_mux_level_2_predecode_block_drivers.readOp.dynamic;

    //Add energy consumed in predecode blocks
    tot_power_row_predecode_blocks.readOp.dynamic = 
        (row_predec_blk_1.power_nand2_path.readOp.dynamic + row_predec_blk_1.power_nand3_path.readOp.dynamic +
         row_predec_blk_1.power_second_level.readOp.dynamic + row_predec_blk_2.power_nand2_path.readOp.dynamic + 
         row_predec_blk_2.power_nand3_path.readOp.dynamic +	row_predec_blk_2.power_second_level.readOp.dynamic) *
        number_activated_mats_horizontal_direction;

    tot_power_bit_mux_predecode_blocks.readOp.dynamic =
        (bit_mux_predec_blk_1.power_nand2_path.readOp.dynamic +	bit_mux_predec_blk_1.power_nand3_path.readOp.dynamic +
         bit_mux_predec_blk_1.power_second_level.readOp.dynamic + bit_mux_predec_blk_2.power_nand2_path.readOp.dynamic +
         bit_mux_predec_blk_2.power_nand3_path.readOp.dynamic +	bit_mux_predec_blk_2.power_second_level.readOp.dynamic) *
        number_activated_mats_horizontal_direction;

    tot_power_senseamp_mux_level_1_predecode_blocks.readOp.dynamic =
            (senseamp_mux_level_1_predec_blk_1.power_nand2_path.readOp.dynamic + senseamp_mux_level_1_predec_blk_1.power_nand3_path.readOp.dynamic +
             senseamp_mux_level_1_predec_blk_1.power_second_level.readOp.dynamic + senseamp_mux_level_1_predec_blk_2.power_nand2_path.readOp.dynamic + 
             senseamp_mux_level_1_predec_blk_2.power_nand3_path.readOp.dynamic + senseamp_mux_level_1_predec_blk_2.power_second_level.readOp.dynamic) *
			 number_activated_mats_horizontal_direction;

	tot_power_senseamp_mux_level_2_predecode_blocks.readOp.dynamic =
            (senseamp_mux_level_2_predec_blk_1.power_nand2_path.readOp.dynamic + senseamp_mux_level_2_predec_blk_1.power_nand3_path.readOp.dynamic +
             senseamp_mux_level_2_predec_blk_1.power_second_level.readOp.dynamic + senseamp_mux_level_2_predec_blk_2.power_nand2_path.readOp.dynamic + 
             senseamp_mux_level_2_predec_blk_2.power_nand3_path.readOp.dynamic + senseamp_mux_level_2_predec_blk_2.power_second_level.readOp.dynamic) *
			 number_activated_mats_horizontal_direction;
   
    tot_power.readOp.dynamic += tot_power_row_predecode_blocks.readOp.dynamic +
        tot_power_bit_mux_predecode_blocks.readOp.dynamic +	tot_power_senseamp_mux_level_1_predecode_blocks.readOp.dynamic +
		tot_power_senseamp_mux_level_2_predecode_blocks.readOp.dynamic;

    //Add energy consumed in decoders
	if((parameters->fully_assoc)&&(is_tag)){//Fully-associative cache tag array decoding energy is stored in tot_power_row_decoders
		tot_power_row_decoders.readOp.dynamic = power_fa_decoder.readOp.dynamic;
	}
	else if(parameters->fully_assoc){
		tot_power_row_decoders.readOp.dynamic = row_dec.power.readOp.dynamic * number_activated_mats_horizontal_direction;
	}
	else{
		tot_power_row_decoders.readOp.dynamic = row_dec.power.readOp.dynamic * 	4 * number_activated_mats_horizontal_direction;
	}


    //If DRAM, add contribution of power spent in row predecoder drivers, blocks and decoders to refresh power
    if((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)){
        refresh_power += (tot_power_row_predecode_block_drivers.readOp.dynamic  +
		tot_power_row_predecode_blocks.readOp.dynamic + row_dec.power.readOp.dynamic) * 
		number_rows_subarray * number_subarrays /  dram_refresh_period;
		refresh_power += per_bitline_read_energy * number_cols_subarray * number_rows_subarray * number_subarrays / dram_refresh_period;
    }

    tot_power_bit_mux_decoders.readOp.dynamic = bit_mux_dec.power.readOp.dynamic * 
		number_activated_mats_horizontal_direction;

   tot_power_senseamp_mux_level_1_decoders.readOp.dynamic = senseamp_mux_level_1_dec.power.readOp.dynamic *  number_activated_mats_horizontal_direction;

    tot_power_senseamp_mux_level_2_decoders.readOp.dynamic = senseamp_mux_level_2_dec.power.readOp.dynamic * number_activated_mats_horizontal_direction;

   tot_power.readOp.dynamic += tot_power_row_decoders.readOp.dynamic + tot_power_bit_mux_decoders.readOp.dynamic + 
	   tot_power_senseamp_mux_level_1_decoders.readOp.dynamic + tot_power_senseamp_mux_level_2_decoders.readOp.dynamic;;

   if(!(parameters->fully_assoc&&is_tag)){//If fully associative cache and tag array, don't add the following components of energy
	   //Add energy consumed in bitlines
    tot_power_bitlines.readOp.dynamic = bitline_data_power.readOp.dynamic;
	tot_power_bitlines.writeOp.dynamic = bitline_data_power.writeOp.dynamic;
    tot_power.readOp.dynamic += tot_power_bitlines.readOp.dynamic;
	
	//Add energy consumed in the precharge and equalization driver
	   if(parameters->fully_assoc){//Fully-associative data array
		   tot_power_bitlines_precharge_eq_driver.readOp.dynamic = bitline_precharge_eq_driver.power.readOp.dynamic *
			   number_activated_mats_horizontal_direction;
	   }
	   else{
		   tot_power_bitlines_precharge_eq_driver.readOp.dynamic = bitline_precharge_eq_driver.power.readOp.dynamic *
			   4 * number_activated_mats_horizontal_direction;
	   }
	   tot_power.readOp.dynamic += tot_power_bitlines_precharge_eq_driver.readOp.dynamic;


    //Add energy consumed in sense amplifiers
    tot_power_sense_amps.readOp.dynamic = sense_amp_data_power.readOp.dynamic;
    tot_power.readOp.dynamic += tot_power_sense_amps.readOp.dynamic;

    //Add energy consumed in subarray output driver circuitry
    tot_power_subarray_output_drivers.readOp.dynamic = power_output_drivers_at_subarray.readOp.dynamic * 
        number_dataout_bits_mat * number_activated_mats_horizontal_direction;
    tot_power.readOp.dynamic += tot_power_subarray_output_drivers.readOp.dynamic;
   }

    //Add energy consumed in vertical dataout htree
	if(!REPEATERS_IN_HTREE_SEGMENTS){
		tot_power_dataout_vertical_htree.readOp.dynamic = BURST_LENGTH * number_dataout_bits_mat * 
			number_activated_mats_horizontal_direction * power_dout_htree.readOp.dynamic;
	}
	else{
		length_htree_segment = pow(2, number_vertical_htree_nodes - 1) * 
			vertical_addr_datain_htree_at_mat_interval.mat_dimension / 2;
		for(k = 0; k < number_vertical_htree_nodes; ++k){
			power_dataout_htree_node_at_mat_interval(ptr_bnk_htree_sizing, &vertical_addr_datain_htree_at_mat_interval, 
				length_htree_segment, k, &power_dout_vertical_htree_node);
			tot_power_dataout_vertical_htree.readOp.dynamic += BURST_LENGTH * number_dataout_bits_mat * 
				power_dout_vertical_htree_node.readOp.dynamic *	number_activated_mats_horizontal_direction;
			vertical_dataout_htree_routing_energy_for_read = number_dataout_bits_mat * power_dout_vertical_htree_node.readOp.dynamic * 
				number_activated_mats_horizontal_direction;
			length_htree_segment /= 2;
		}
	}

	tot_power.readOp.dynamic += tot_power_dataout_vertical_htree.readOp.dynamic;

    tot_power_comparators.readOp.dynamic = comparator_power.readOp.dynamic *
		number_activated_mats_horizontal_direction;
    tot_power.readOp.dynamic += tot_power_comparators.readOp.dynamic;

	//Calculate total write energy per access
	tot_power.writeOp.dynamic = tot_power.readOp.dynamic - tot_power_bitlines.readOp.dynamic +
		tot_power_bitlines.writeOp.dynamic - tot_power_sense_amps.readOp.dynamic - tot_power_routing_to_bank.readOp.dynamic +
		tot_power_routing_to_bank.writeOp.dynamic - tot_power_dataout_horizontal_htree.readOp.dynamic +
		tot_power_datain_horizontal_htree.readOp.dynamic - tot_power_dataout_vertical_htree.readOp.dynamic +
		tot_power_datain_vertical_htree.readOp.dynamic;

	dyn_read_energy_from_closed_page = tot_power.readOp.dynamic;

	dyn_read_energy_from_open_page = tot_power.readOp.dynamic -  tot_power_row_predecode_blocks.readOp.dynamic -
		tot_power_row_decoders.readOp.dynamic -	tot_power_bitlines_precharge_eq_driver.readOp.dynamic - tot_power_sense_amps.readOp.dynamic;

	dyn_read_energy_remaining_words_in_burst = (MAX((BURST_LENGTH / INTERNAL_PREFETCH_WIDTH), 1) - 1) * (tot_power_senseamp_mux_level_1_predecode_blocks.readOp.dynamic  +
		tot_power_senseamp_mux_level_2_predecode_blocks.readOp.dynamic + tot_power_senseamp_mux_level_1_decoders.readOp.dynamic +
		tot_power_senseamp_mux_level_2_decoders.readOp.dynamic + tot_power_subarray_output_drivers.readOp.dynamic + tot_power_dataout_vertical_htree.readOp.dynamic +
		tot_power_routing_to_bank.readOp.dynamic);


	dyn_read_energy_from_closed_page += dyn_read_energy_remaining_words_in_burst;
	dyn_read_energy_from_open_page += dyn_read_energy_remaining_words_in_burst;


	if(!is_tag){
		tot_power.readOp.dynamic = dyn_read_energy_from_closed_page;
		tot_power.writeOp.dynamic = dyn_read_energy_from_closed_page -  tot_power_bitlines.readOp.dynamic + tot_power_bitlines.writeOp.dynamic - tot_power_sense_amps.readOp.dynamic 
			+ (tot_power_routing_to_bank.writeOp.dynamic  - tot_power_routing_to_bank.readOp.dynamic - tot_power_dataout_horizontal_htree.readOp.dynamic +	
			tot_power_datain_horizontal_htree.readOp.dynamic -	tot_power_dataout_vertical_htree.readOp.dynamic + tot_power_datain_vertical_htree.readOp.dynamic) * 
			MAX((BURST_LENGTH / INTERNAL_PREFETCH_WIDTH), 1);
	}


	activate_energy = routing_to_bank_for_activate_energy + horizontal_htree_routing_energy_for_activate + tot_power_row_predecode_block_drivers.readOp.dynamic +
		tot_power_row_predecode_blocks.readOp.dynamic + tot_power_row_decoders.readOp.dynamic + tot_power_sense_amps.readOp.dynamic;
	read_energy = BURST_LENGTH * (routing_addr_to_bank_for_read_or_write_energy + horizontal_addr_htree_routing_energy_for_read_or_write + vertical_addr_htree_routing_energy_for_read_or_write + 
			 tot_power_senseamp_mux_level_1_predecode_block_drivers.readOp.dynamic +
			tot_power_senseamp_mux_level_2_predecode_block_drivers.readOp.dynamic + tot_power_senseamp_mux_level_1_predecode_blocks.readOp.dynamic +
			tot_power_senseamp_mux_level_2_predecode_blocks.readOp.dynamic +  tot_power_senseamp_mux_level_1_decoders.readOp.dynamic + 
			tot_power_senseamp_mux_level_2_decoders.readOp.dynamic + tot_power_subarray_output_drivers.readOp.dynamic + vertical_dataout_htree_routing_energy_for_read +
			horizontal_dataout_htree_energy_for_read + routing_datain_bits_to_bank_energy_for_write);
	write_energy = BURST_LENGTH * (routing_addr_to_bank_for_read_or_write_energy +  horizontal_addr_htree_routing_energy_for_read_or_write + vertical_addr_htree_routing_energy_for_read_or_write +
			 routing_datain_bits_to_bank_energy_for_write + horizontal_datain_htree_routing_energy_for_write +
			vertical_datain_htree_routing_energy_for_write +	tot_power_senseamp_mux_level_1_predecode_block_drivers.readOp.dynamic +
			tot_power_senseamp_mux_level_2_predecode_block_drivers.readOp.dynamic + tot_power_senseamp_mux_level_1_predecode_blocks.readOp.dynamic +
			tot_power_senseamp_mux_level_2_predecode_blocks.readOp.dynamic +  tot_power_senseamp_mux_level_1_decoders.readOp.dynamic + 	
			tot_power_senseamp_mux_level_2_decoders.readOp.dynamic);
	precharge_energy =  bitline_data_power.readOp.dynamic + tot_power_bitlines_precharge_eq_driver.readOp.dynamic;


    //Calculate leakage power
    tot_power_routing_to_bank.readOp.leakage += power_routing_to_bank.readOp.leakage *
		number_bits_routed_to_bank * (parameters->num_readwrite_ports + parameters->num_read_ports +
		parameters->num_write_ports);
    tot_power.readOp.leakage += tot_power_routing_to_bank.readOp.leakage;

	tot_power_crossbar.readOp.leakage = crossbar_instance.power.readOp.leakage * NUMBER_INPUT_PORTS_CROSSBAR * NUMBER_OUTPUT_PORTS_CROSSBAR * 
		NUMBER_SIGNALS_PER_PORT_CROSSBAR;
	tot_power.readOp.leakage += tot_power_crossbar.readOp.leakage ;
    
	htree_seg_multiplier = 1;
	length_htree_segment = pow(2, number_horizontal_htree_nodes - 1) * 
		horizontal_addr_datain_htree_at_mat_interval.mat_dimension / 2;
	for(k = 0; k < number_horizontal_htree_nodes; ++k){
		power_addr_datain_htree_node(&horizontal_addr_din_htree_node[k],
			&power_addr_datain_horizontal_htree_node);
		if(REPEATERS_IN_HTREE_SEGMENTS){
			power_addr_datain_htree_node_at_mat_interval(ptr_bnk_htree_sizing, &horizontal_addr_datain_htree_at_mat_interval, 
				length_htree_segment, number_horizontal_htree_nodes, k, &power_addr_datain_horizontal_htree_node);
		}
        tot_power_addr_horizontal_htree.readOp.leakage +=
            (number_addr_bits_mat + number_way_select_signals_mat) * 
			power_addr_datain_horizontal_htree_node.readOp.leakage * htree_seg_multiplier *
			(parameters->num_readwrite_ports + parameters->num_read_ports +
			parameters->num_write_ports);
        tot_power_datain_horizontal_htree.readOp.leakage += number_datain_bits_mat * 
			number_mats_horizontal_direction * 
			power_addr_datain_horizontal_htree_node.readOp.leakage * (parameters->num_readwrite_ports + 
			parameters->num_write_ports);
        tot_power_dataout_horizontal_htree.readOp.leakage += number_dataout_bits_mat * 
            number_mats_horizontal_direction * power_addr_datain_horizontal_htree_node.readOp.leakage *
			(parameters->num_readwrite_ports + parameters->num_read_ports);
        htree_seg_multiplier *= 2;
		length_htree_segment /= 2;
    }

    tot_power.readOp.leakage += tot_power_addr_horizontal_htree.readOp.leakage + 
		tot_power_datain_horizontal_htree.readOp.leakage +
		tot_power_dataout_horizontal_htree.readOp.leakage;

	htree_seg_multiplier = 1;
	length_htree_segment = pow(2, number_vertical_htree_nodes - 1) * 
		vertical_addr_datain_htree_at_mat_interval.mat_dimension / 2;
	for(k = 0; k < number_vertical_htree_nodes; ++k){
		power_addr_datain_htree_node(&vertical_addr_din_htree_node[k], &power_addr_datain_vertical_htree_node);
		if(REPEATERS_IN_HTREE_SEGMENTS){
			power_addr_datain_htree_node_at_mat_interval(ptr_bnk_htree_sizing, &vertical_addr_datain_htree_at_mat_interval, 
				length_htree_segment, number_vertical_htree_nodes, k, &power_addr_datain_vertical_htree_node);
		}
        tot_power_addr_vertical_htree.readOp.leakage +=
            (number_addr_bits_mat + number_way_select_signals_mat) * 
			power_addr_datain_vertical_htree_node.readOp.leakage * htree_seg_multiplier * 
			number_mats_horizontal_direction * (parameters->num_readwrite_ports + 
			parameters->num_read_ports + parameters->num_write_ports);
        tot_power_datain_vertical_htree.readOp.leakage += number_datain_bits_mat * 
			power_addr_datain_vertical_htree_node.readOp.leakage * htree_seg_multiplier * 
			number_mats_horizontal_direction * (parameters->num_readwrite_ports + 
			parameters->num_write_ports);
		htree_seg_multiplier *= 2;
		length_htree_segment /= 2;
    }

	if(number_mats_vertical_direction > 1){
		tot_power_addr_vertical_htree.readOp.leakage *= 2; 
		tot_power_datain_vertical_htree.readOp.leakage *= 2;
	}
	
	tot_power.readOp.leakage += tot_power_addr_vertical_htree.readOp.leakage +
		tot_power_datain_vertical_htree.readOp.leakage;

	if(!REPEATERS_IN_HTREE_SEGMENTS){
		if(number_mats_vertical_direction > 1){
			tot_power_dataout_vertical_htree.readOp.leakage = number_dataout_bits_mat * 
				number_mats_horizontal_direction *	2 * power_dout_htree.readOp.leakage *
				(parameters->num_readwrite_ports + parameters->num_read_ports);
		}
		else{//number_mats_vertical_direction = 1
			tot_power_dataout_vertical_htree.readOp.leakage = number_dataout_bits_mat * 
				number_mats_horizontal_direction *	1 * power_dout_htree.readOp.leakage * 
				(parameters->num_readwrite_ports + parameters->num_read_ports);
		}
	}
	else{
		htree_seg_multiplier = 1;
		length_htree_segment = pow(2, number_vertical_htree_nodes - 1) * 
			vertical_addr_datain_htree_at_mat_interval.mat_dimension / 2;
		for(k = 0; k < number_vertical_htree_nodes; ++k){
			power_dataout_htree_node_at_mat_interval(ptr_bnk_htree_sizing, &vertical_addr_datain_htree_at_mat_interval, 
				length_htree_segment, k, &power_dout_vertical_htree_node);
			tot_power_dataout_vertical_htree.readOp.leakage += number_dataout_bits_mat * 
				power_dout_vertical_htree_node.readOp.leakage * htree_seg_multiplier * 
				number_mats_horizontal_direction;
			htree_seg_multiplier *= 2;
			length_htree_segment /= 2;
		}
		if(number_mats_vertical_direction > 1){
			tot_power_dataout_vertical_htree.readOp.leakage *= 	2 * (parameters->num_readwrite_ports + 
				parameters->num_read_ports);
		}
		else{//number_mats_vertical_direction = 1
			tot_power_dataout_vertical_htree.readOp.leakage *= 	1 * (parameters->num_readwrite_ports + 
				parameters->num_read_ports);
		}
	}
    tot_power.readOp.leakage += tot_power_dataout_vertical_htree.readOp.leakage;

	if(!(parameters->fully_assoc&&is_tag)){//If fully associative cache and tag array, don't add the following components of leakage power
		tot_power_bitlines.readOp.leakage = bitline_data_power.readOp.leakage *
			number_rows_subarray * number_cols_subarray * number_subarrays; //This is actually leakage in the memory cells.
		tot_power.readOp.leakage += tot_power_bitlines.readOp.leakage;

		tot_power_bitlines_precharge_eq_driver.readOp.leakage = 
			bitline_precharge_eq_driver.power.readOp.leakage * number_subarrays;
		tot_power.readOp.leakage += tot_power_bitlines_precharge_eq_driver.readOp.leakage;

		tot_power_sense_amps.readOp.leakage = sense_amp_data_power.readOp.leakage * 
			(parameters->num_readwrite_ports + parameters->num_read_ports);
		tot_power.readOp.leakage += tot_power_sense_amps.readOp.leakage;

		tot_power_subarray_output_drivers.readOp.leakage = power_output_drivers_at_subarray.readOp.leakage *
			number_output_drivers_subarray * number_subarrays * 
			(parameters->num_readwrite_ports + parameters->num_read_ports);
		tot_power.readOp.leakage += tot_power_subarray_output_drivers.readOp.leakage;
	}

    tot_power_comparators.readOp.leakage = comparator_power.readOp.leakage *  
		number_dataout_bits_mat * number_mats * (parameters->num_readwrite_ports + 
			 parameters->num_read_ports);
    tot_power.readOp.leakage += tot_power_comparators.readOp.leakage;

    //If DRAM, add refresh power to total leakage
    if((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)){
        tot_power.readOp.leakage += refresh_power;
    }

	if(is_main_mem){
		tot_power.readOp.leakage += MAIN_MEM_PER_CHIP_STANDBY_CURRENT_mA * 1e-3 * vdd_periph_global / parameters->number_banks;
    }
	

	leak_power_subbank_closed_page = ((tot_power_row_predecode_blocks.readOp.leakage + tot_power_bit_mux_predecode_blocks.readOp.leakage + 
		tot_power_senseamp_mux_level_1_predecode_blocks.readOp.leakage + tot_power_senseamp_mux_level_2_predecode_blocks.readOp.leakage +
		tot_power_row_decoders.readOp.leakage + tot_power_bit_mux_decoders.readOp.leakage + tot_power_senseamp_mux_level_1_decoders.readOp.leakage +
		tot_power_senseamp_mux_level_2_decoders.readOp.leakage) / number_mats + leak_power_sense_amps_closed_page_state) * number_activated_mats_horizontal_direction;

	leak_power_subbank_open_page = ((tot_power_row_predecode_blocks.readOp.leakage + tot_power_bit_mux_predecode_blocks.readOp.leakage + 
		tot_power_senseamp_mux_level_1_predecode_blocks.readOp.leakage + tot_power_senseamp_mux_level_2_predecode_blocks.readOp.leakage +
		tot_power_row_decoders.readOp.leakage + tot_power_bit_mux_decoders.readOp.leakage + tot_power_senseamp_mux_level_1_decoders.readOp.leakage +
		tot_power_senseamp_mux_level_2_decoders.readOp.leakage) / number_mats + leak_power_sense_amps_open_page_state) * number_activated_mats_horizontal_direction;

	leak_power_request_and_reply_networks  = tot_power_routing_to_bank.readOp.leakage + tot_power_crossbar.readOp.leakage +
		tot_power_addr_horizontal_htree.readOp.leakage + tot_power_datain_horizontal_htree.readOp.leakage +
		tot_power_dataout_horizontal_htree.readOp.leakage + tot_power_addr_vertical_htree.readOp.leakage +
		tot_power_datain_vertical_htree.readOp.leakage + tot_power_dataout_vertical_htree.readOp.leakage;


    if(flag_results_populate){
        ptr_results->Ndwl = Ndwl;
        ptr_results->Ndbl = Ndbl;
        ptr_results->Nspd = Nspd;
        ptr_results->deg_bitline_muxing = deg_bitline_muxing;
        ptr_results->Ndsam_level_1 = Ndsam_level_1;
		ptr_results->Ndsam_level_2 = Ndsam_level_2;
        ptr_results->number_activated_mats_horizontal_direction = number_activated_mats_horizontal_direction;
		ptr_results->number_subbanks = number_mats / number_activated_mats_horizontal_direction;
		ptr_results->page_size_in_bits = number_dataout_bits_mat * number_activated_mats_horizontal_direction * Ndsam_level_1 * Ndsam_level_2;
        ptr_results->delay_route_to_bank = delay_route_to_bank;
		ptr_results->delay_crossbar = crossbar_instance.delay;
        ptr_results->delay_addr_din_horizontal_htree = delay_addr_din_horizontal_htree;
        ptr_results->delay_addr_din_vertical_htree = delay_addr_din_vertical_htree;
        ptr_results->delay_row_predecode_driver_and_block = max_delay_before_row_decoder -
            (delay_route_to_bank + delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree);
        ptr_results->delay_row_decoder = row_dec.delay;
        ptr_results->delay_bitlines = bitline_data;
        ptr_results->delay_sense_amp = delay_sense_amp;
        ptr_results->delay_subarray_output_driver = delay_subarray_output_driver;
        ptr_results->delay_bit_mux_predecode_driver_and_block = max_delay_before_bit_mux_decoder -
            (delay_route_to_bank + delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree);
        ptr_results->delay_bit_mux_decoder = bit_mux_dec.delay;
        ptr_results->delay_senseamp_mux_level_1_predecode_driver_and_block = max_delay_before_senseamp_mux_level_1_decoder -
            (delay_route_to_bank + delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree);
		ptr_results->delay_senseamp_mux_level_2_predecode_driver_and_block = max_delay_before_senseamp_mux_level_2_decoder -
            (delay_route_to_bank + delay_addr_din_horizontal_htree + delay_addr_din_vertical_htree);
        ptr_results->delay_senseamp_mux_level_1_decoder = senseamp_mux_level_1_dec.delay;
		ptr_results->delay_senseamp_mux_level_2_decoder = senseamp_mux_level_2_dec.delay;
        ptr_results->delay_dout_vertical_htree = delay_dout_vertical_htree;
        ptr_results->delay_dout_horizontal_htree = delay_dout_horizontal_htree;
        ptr_results->delay_comparator = comparator_delay;
        ptr_results->access_time = access_time;
        ptr_results->cycle_time = cycle_time;
        ptr_results->multisubbank_interleave_cycle_time = multisubbank_interleave_cycle_time;
		ptr_results->delay_request_network = delay_request_network;
		ptr_results->delay_inside_mat = delay_inside_mat;
		ptr_results->delay_reply_network = delay_reply_network;
		ptr_results->trcd = t_rcd;
	    ptr_results->cas_latency = cas_latency;
		ptr_results->precharge_delay = precharge_delay;
		ptr_results->dram_refresh_period = dram_refresh_period;
		ptr_results->dram_array_availability = dram_array_availability;
        copy_powerDef(&ptr_results->power_routing_to_bank, tot_power_routing_to_bank);
        copy_powerDef(&ptr_results->power_addr_horizontal_htree, 
                tot_power_addr_horizontal_htree);
        copy_powerDef(&ptr_results->power_datain_horizontal_htree, 
                tot_power_datain_horizontal_htree);
        copy_powerDef(&ptr_results->power_dataout_horizontal_htree, 
                tot_power_dataout_horizontal_htree);
        copy_powerDef(&ptr_results->power_addr_vertical_htree, tot_power_addr_vertical_htree);
		copy_powerDef(&ptr_results->power_datain_vertical_htree, tot_power_datain_vertical_htree);
        copy_powerDef(&ptr_results->power_row_predecoder_drivers, tot_power_row_predecode_block_drivers);
        copy_powerDef(&ptr_results->power_row_predecoder_blocks, tot_power_row_predecode_blocks);
        copy_powerDef(&ptr_results->power_row_decoders, tot_power_row_decoders);
        copy_powerDef(&ptr_results->power_bit_mux_predecoder_drivers, tot_power_bit_mux_predecode_block_drivers);
        copy_powerDef(&ptr_results->power_bit_mux_predecoder_blocks, tot_power_bit_mux_predecode_blocks);
        copy_powerDef(&ptr_results->power_bit_mux_decoders, tot_power_bit_mux_decoders);
        copy_powerDef(&ptr_results->power_senseamp_mux_level_1_predecoder_drivers, tot_power_senseamp_mux_level_1_predecode_block_drivers);
        copy_powerDef(&ptr_results->power_senseamp_mux_level_1_predecoder_blocks, tot_power_senseamp_mux_level_1_predecode_blocks);
        copy_powerDef(&ptr_results->power_senseamp_mux_level_1_decoders, tot_power_senseamp_mux_level_1_decoders);
		copy_powerDef(&ptr_results->power_senseamp_mux_level_2_predecoder_drivers, tot_power_senseamp_mux_level_2_predecode_block_drivers);
        copy_powerDef(&ptr_results->power_senseamp_mux_level_2_predecoder_blocks, tot_power_senseamp_mux_level_2_predecode_blocks);
        copy_powerDef(&ptr_results->power_senseamp_mux_level_2_decoders, tot_power_senseamp_mux_level_2_decoders);
        copy_powerDef(&ptr_results->power_bitlines, tot_power_bitlines);
        copy_powerDef(&ptr_results->power_sense_amps, tot_power_sense_amps);
		copy_powerDef(&ptr_results->power_prechg_eq_drivers, tot_power_bitlines_precharge_eq_driver);
        copy_powerDef(&ptr_results->power_output_drivers_at_subarray, tot_power_subarray_output_drivers);
        copy_powerDef(&ptr_results->power_dataout_vertical_htree, tot_power_dataout_vertical_htree);
        copy_powerDef(&ptr_results->power_comparators, tot_power_comparators);
		copy_powerDef(&ptr_results->power_crossbar, tot_power_crossbar);
        copy_powerDef(&ptr_results->total_power, tot_power);
		ptr_results->dyn_read_energy_from_closed_page = dyn_read_energy_from_closed_page;
		ptr_results->dyn_read_energy_from_open_page = dyn_read_energy_from_open_page;
		ptr_results->leak_power_subbank_closed_page = leak_power_subbank_closed_page;
		ptr_results->leak_power_subbank_open_page = leak_power_subbank_open_page;
		ptr_results->leak_power_request_and_reply_networks = leak_power_request_and_reply_networks;
        ptr_results->area = all_banks.height * all_banks.width * 1e-6;//in mm2
        ptr_results->all_banks_height = all_banks.height;
        ptr_results->all_banks_width = all_banks.width;		
        ptr_results->bank_height = bank.height;
        ptr_results->bank_width = bank.width;
        ptr_results->subarray_memory_cell_area_height = subarray.height;
        ptr_results->subarray_memory_cell_area_width = subarray.width;
        ptr_results->mat_height = mat.height;
        ptr_results->mat_width = mat.width;
        ptr_results->routing_area_height_within_bank = bank.height - number_mats_vertical_direction * 
            mat.height;
		ptr_results->routing_area_width_within_bank = bank.width - number_mats_horizontal_direction * 
            mat.width;
        ptr_results->area_efficiency = area_all_dataramcells * 100 / 
            (all_banks.height * all_banks.width);
        ptr_results->perc_power_dyn_routing_to_bank = 
            ptr_results->power_routing_to_bank.readOp.dynamic * 100 / 
            ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_addr_horizontal_htree = 
            ptr_results->power_addr_horizontal_htree.readOp.dynamic * 100 / 
            ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_dataout_horizontal_htree = 
            ptr_results->power_dataout_horizontal_htree.readOp.dynamic * 100 / 
            ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_addr_vertical_htree = 
            ptr_results->power_addr_vertical_htree.readOp.dynamic * 100 /	ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_row_predecoder_drivers =
            ptr_results->power_row_predecoder_drivers.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_row_predecoder_blocks =
            ptr_results->power_row_predecoder_blocks.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_row_decoders =
            ptr_results->power_row_decoders.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_bit_mux_predecoder_drivers =
            ptr_results->power_bit_mux_predecoder_drivers.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_bit_mux_predecoder_blocks =
            ptr_results->power_bit_mux_predecoder_blocks.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_bit_mux_decoders =
            ptr_results->power_bit_mux_decoders.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_senseamp_mux_level_1_predecoder_drivers = 
            ptr_results->power_senseamp_mux_level_1_predecoder_drivers.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_senseamp_mux_level_1_predecoder_blocks =
            ptr_results->power_senseamp_mux_level_1_predecoder_blocks.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_senseamp_mux_level_1_decoders =
            ptr_results->power_senseamp_mux_level_1_decoders.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
		ptr_results->perc_power_dyn_senseamp_mux_level_2_predecoder_drivers = 
            ptr_results->power_senseamp_mux_level_2_predecoder_drivers.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_senseamp_mux_level_2_predecoder_blocks =
            ptr_results->power_senseamp_mux_level_2_predecoder_blocks.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_senseamp_mux_level_2_decoders =
            ptr_results->power_senseamp_mux_level_2_decoders.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_bitlines = 
            ptr_results->power_bitlines.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_sense_amps =
            ptr_results->power_sense_amps.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
		ptr_results->perc_power_dyn_prechg_eq_drivers =
			ptr_results->power_prechg_eq_drivers.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_subarray_output_drivers =
            ptr_results->power_output_drivers_at_subarray.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_dataout_vertical_htree =
            ptr_results->power_dataout_vertical_htree.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
        ptr_results->perc_power_dyn_comparators =
            ptr_results->power_comparators.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
		ptr_results->perc_power_dyn_crossbar =
            ptr_results->power_crossbar.readOp.dynamic * 100 / ptr_fin_res->power.readOp.dynamic;
		ptr_results->activate_energy = activate_energy;
		ptr_results->read_energy = read_energy;
		ptr_results->write_energy = write_energy;
		ptr_results->precharge_energy = precharge_energy;

		ptr_results->perc_power_dyn_spent_outside_mats = ptr_results->perc_power_dyn_routing_to_bank + ptr_results->perc_power_dyn_addr_horizontal_htree +
			ptr_results->perc_power_dyn_addr_vertical_htree + ptr_results->perc_power_dyn_dataout_vertical_htree +
			ptr_results->perc_power_dyn_dataout_horizontal_htree;


        ptr_results->perc_power_leak_routing_to_bank = 
            ptr_results->power_routing_to_bank.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_addr_horizontal_htree = 
            ptr_results->power_addr_horizontal_htree.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_datain_horizontal_htree = 
            ptr_results->power_datain_horizontal_htree.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_dataout_horizontal_htree = 
            ptr_results->power_dataout_horizontal_htree.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_addr_vertical_htree = 
            ptr_results->power_addr_vertical_htree.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
		ptr_results->perc_power_leak_datain_vertical_htree = 
            ptr_results->power_datain_vertical_htree.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_row_predecoder_drivers =
            ptr_results->power_row_predecoder_drivers.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_row_predecoder_blocks =
            ptr_results->power_row_predecoder_blocks.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_row_decoders =
            ptr_results->power_row_decoders.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_bit_mux_predecoder_drivers =
            ptr_results->power_bit_mux_predecoder_drivers.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_bit_mux_predecoder_blocks =
            ptr_results->power_bit_mux_predecoder_blocks.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_bit_mux_decoders =
            ptr_results->power_bit_mux_decoders.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_senseamp_mux_level_1_predecoder_drivers = 
            ptr_results->power_senseamp_mux_level_1_predecoder_drivers.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_senseamp_mux_level_1_predecoder_blocks =
            ptr_results->power_senseamp_mux_level_1_predecoder_blocks.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_senseamp_mux_level_1_decoders =
            ptr_results->power_senseamp_mux_level_1_decoders.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
		ptr_results->perc_power_leak_senseamp_mux_level_2_predecoder_drivers = 
            ptr_results->power_senseamp_mux_level_2_predecoder_drivers.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_senseamp_mux_level_2_predecoder_blocks =
            ptr_results->power_senseamp_mux_level_2_predecoder_blocks.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_senseamp_mux_level_2_decoders =
            ptr_results->power_senseamp_mux_level_2_decoders.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_bitlines = 
            ptr_results->power_bitlines.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_sense_amps =
            ptr_results->power_sense_amps.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
		ptr_results->perc_power_leak_prechg_eq_drivers =
			ptr_results->power_prechg_eq_drivers.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_subarray_output_drivers =
            ptr_results->power_output_drivers_at_subarray.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_dataout_vertical_htree =
            ptr_results->power_dataout_vertical_htree.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->perc_power_leak_comparators =
            ptr_results->power_comparators.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
		ptr_results->perc_power_leak_crossbar =
            ptr_results->power_crossbar.readOp.leakage * 100 / ptr_fin_res->power.readOp.leakage;
        ptr_results->refresh_power = refresh_power;
		ptr_results->perc_leak_mats = ptr_results->perc_power_leak_row_predecoder_drivers +
			ptr_results->perc_power_leak_row_predecoder_blocks + ptr_results->perc_power_leak_row_decoders +
			ptr_results->perc_power_leak_bit_mux_predecoder_drivers + ptr_results->perc_power_leak_bit_mux_predecoder_blocks +
			ptr_results->perc_power_leak_bit_mux_decoders + ptr_results->perc_power_leak_senseamp_mux_level_1_predecoder_drivers +
			ptr_results->perc_power_leak_senseamp_mux_level_2_predecoder_drivers +
			ptr_results->perc_power_leak_senseamp_mux_level_1_predecoder_blocks +
			ptr_results->perc_power_leak_senseamp_mux_level_1_decoders + 
			ptr_results->perc_power_leak_senseamp_mux_level_2_predecoder_blocks +
			ptr_results->perc_power_leak_senseamp_mux_level_2_decoders + ptr_results->perc_power_leak_bitlines +
			ptr_results->perc_power_leak_sense_amps + ptr_results->perc_power_leak_subarray_output_drivers +
			ptr_results->perc_power_leak_comparators;
		ptr_results->perc_active_mats = (double) (number_activated_mats_horizontal_direction) * 100 / (double) (number_mats);
    }
    else{
        ptr_array->Ndwl = Ndwl;
        ptr_array->Ndbl = Ndbl;
        ptr_array->Nspd = Nspd;
        ptr_array->deg_bitline_muxing = deg_bitline_muxing;
        ptr_array->Ndsam_level_1 = Ndsam_level_1;
		ptr_array->Ndsam_level_2 = Ndsam_level_2;
        ptr_array->access_time = access_time;
        ptr_array->cycle_time = cycle_time;
        ptr_array->multisubbank_interleave_cycle_time = multisubbank_interleave_cycle_time;
        ptr_array->area_ram_cells = area_all_dataramcells;
        ptr_array->area = all_banks.height * all_banks.width;
		ptr_array->height = all_banks.height;
		ptr_array->width = all_banks.width;
        copy_powerDef(&ptr_array->power, tot_power);
        ptr_array->delay_senseamp_mux_decoder = MAX(max_delay_before_senseamp_mux_level_1_decoder + senseamp_mux_level_1_dec.delay,
			max_delay_before_senseamp_mux_level_2_decoder + senseamp_mux_level_2_dec.delay);
        ptr_array->delay_before_subarray_output_driver = delay_before_subarray_output_driver;
        ptr_array->delay_from_subarray_output_driver_to_output = delay_from_subarray_output_driver_to_output;
    }

    return(TRUE);
partition_not_valid:
    return(FALSE);
}


void do_it(result_type *result, arearesult_type *arearesult, area_type *arearesult_subbanked, 
        parameter_type *parameters, double *NSubbanks, final_results *fin_res)
{
    mem_array **tag_arr, **data_arr;
    solution **best_solution, **best_delay_solution_within_best_area_solutions;
    int pure_ram, tag_arr_index, data_arr_index, max_tag_arr_index, max_data_arr_index, is_valid_partition;
    int is_tag;
    int Ndwl, Ndbl, Ndcm, Ndsam_level_1, Ndsam_level_2, i, j;
    double Nspd;
    double max_efficiency, min_efficiency, area, efficiency;
    int weight_dynamic_energy, weight_leakage_power, weight_dynamic_power, weight_cycle_time;
    solution curr_solution;
    int index_insertion_slot, number_of_solutions, number_of_best_delay_within_best_area_solutions, best_min_acc_time_in_best_area_solutions;
    double min_acc_time, min_acc_time_in_best_area_solutions,
		percent_diff_efficiency_wrt_max_efficiency, percent_diff_acc_time_wrt_min_acc_time, 
		perc_away_from_aspect_ratio, aspect_ratio, perc_wasted_area;
	double acc_time_tag_arr, best_acc_time_tag_arr;
	int best_acc_time_tag_arr_index;
	int saved_is_main_mem;
	double stacked_die_allot_area;

    array_edge_to_bank_edge_htree_sizing arr_edge_to_bank_edge_htree_sizing;
	bank_htree_sizing bnk_htree_sizing;

    /* alloc mem for tag_arr, data_arr & solution*/
	tag_arr = (mem_array **) calloc(MAX_NUMBER_ARRAY_PARTITIONS, sizeof(mem_array *));
    data_arr = (mem_array **) calloc(MAX_NUMBER_ARRAY_PARTITIONS, sizeof(mem_array *));
    best_solution = (solution **) calloc(10000000, sizeof(solution *));
	best_delay_solution_within_best_area_solutions = (solution **) calloc(10000000, sizeof(solution *));

    tag_arr[0] = (mem_array *) malloc(sizeof(mem_array));
    data_arr[0] = (mem_array *) malloc(sizeof(mem_array));
    best_solution[0] = (solution *) malloc(sizeof(solution));
	best_delay_solution_within_best_area_solutions[0] = (solution *) malloc(sizeof(solution));
/*#ifdef __unix__
    bzero(best_solution[0], sizeof(solution));
#endif*/
    FUDGEFACTOR = parameters->fudgefactor;
    pure_ram = !parameters->cache;
    BITOUT = parameters->nr_bits_out;
    parameters->vdd_periph_global = vdd_periph_global;
    result->cycle_time = BIGNUM;
    result->access_time = BIGNUM;
    result->total_power.readOp.dynamic = result->total_power.readOp.leakage =
        result->total_power.writeOp.dynamic = result->total_power.writeOp.leakage =BIGNUM;
    result->max_access_time = 0;
    result->min_access_time = BIGNUM;
    min_acc_time = BIGNUM;
	min_acc_time_in_best_area_solutions = BIGNUM;
    result->max_cycle_time = 0;
    result->min_cycle_time = BIGNUM;
    result->max_leakage_power = 0;
    result->min_leakage_power = BIGNUM;
    result->max_dynamic_power = 0;
    result->min_dynamic_power = BIGNUM;
	result->max_dynamic_energy = 0;
	result->min_dynamic_energy = BIGNUM;
    max_efficiency = 1.0 / BIGNUM;
    min_efficiency = BIGNUM;
    arearesult->efficiency = 1.0 / BIGNUM;
	best_acc_time_tag_arr = BIGNUM;
	fin_res->tag_array.access_time = 0;
	fin_res->tag_array.Ndwl = 0;
	fin_res->tag_array.Ndbl = 0;
	fin_res->tag_array.Nspd = 0;
	fin_res->tag_array.deg_bitline_muxing = 0;
	fin_res->tag_array.Ndsam_level_1 = 0;
	fin_res->tag_array.Ndsam_level_2 = 0;
	max_tag_arr_index = 0;
	max_data_arr_index = 0;

	tag_arr_index = 0;
	data_arr_index = 0;
	saved_is_main_mem = is_main_mem;
    //If it's a cache, first calculate the area, delay and power for all tag array partitions.
    if(!pure_ram){//cache
        is_tag = 1;
		is_main_mem = 0;
        ram_cell_tech_flavor = tag_arr_ram_cell_tech_flavor;
		periph_global_tech_flavor = tag_arr_periph_global_tech_flavor;
		init_tech_params(parameters->tech_size);

		compute_widths_repeaters_array_edge_to_bank_edge(&arr_edge_to_bank_edge_htree_sizing);
		compute_widths_repeaters_bank_htree(&bnk_htree_sizing);

        for(Nspd = 0.125; Nspd <= MAXDATASPD; Nspd = Nspd * 2){
            for(Ndwl = 1; Ndwl <= MAXDATAN; Ndwl = Ndwl * 2){
                for(Ndbl = 1; Ndbl <= MAXDATAN; Ndbl = Ndbl * 2){
                    for(Ndcm = 1; Ndcm <= MAX_COL_MUX; Ndcm = Ndcm * 2){
                        for(Ndsam_level_1 = 1; Ndsam_level_1 <= MAX_COL_MUX; Ndsam_level_1 = Ndsam_level_1 * 2){
							for(Ndsam_level_2 = 1; Ndsam_level_2 <= MAX_COL_MUX; Ndsam_level_2 = Ndsam_level_2 * 2){
								is_valid_partition = calculate_time(parameters, NSubbanks, is_tag, pure_ram, Nspd, Ndwl, 
										Ndbl, Ndcm, Ndsam_level_1, Ndsam_level_2, tag_arr[tag_arr_index], 0, NULL, NULL, &arr_edge_to_bank_edge_htree_sizing, &bnk_htree_sizing);
								if(parameters->fully_assoc){
									is_valid_partition = calculate_time(parameters, NSubbanks, 0, pure_ram, Nspd, Ndwl, 
										Ndbl, Ndcm, Ndsam_level_1, Ndsam_level_2, data_arr[data_arr_index], 0, NULL, NULL, &arr_edge_to_bank_edge_htree_sizing, &bnk_htree_sizing);
								}
								if(is_valid_partition){
									++tag_arr_index;
									tag_arr[tag_arr_index] = (mem_array *) malloc(sizeof(mem_array));
									if(parameters->fully_assoc){
										++data_arr_index;
										data_arr[data_arr_index] = (mem_array *) malloc(sizeof(mem_array));
									}
								}
							}
                        }
                    }
                }
            }
        }
        /* deallocate the extra tag_arr entry */
        
        free(tag_arr[tag_arr_index]);
        max_tag_arr_index = tag_arr_index - 1;
		max_data_arr_index = data_arr_index - 1;
	}
/*#ifdef __unix__
    pthread_mutex_lock (&com_mut_var); 
#endif*/

    //Calculate the area, delay and power for all data array partitions. (for cache or pure RAM)
	if(!parameters->fully_assoc){
    is_tag = 0;
	is_main_mem = saved_is_main_mem;
    data_arr_index = 0;
    ram_cell_tech_flavor = data_arr_ram_cell_tech_flavor;
	periph_global_tech_flavor = data_arr_periph_global_tech_flavor;
	init_tech_params(parameters->tech_size);

	compute_widths_repeaters_array_edge_to_bank_edge(&arr_edge_to_bank_edge_htree_sizing);
	compute_widths_repeaters_bank_htree(&bnk_htree_sizing);

    for(Nspd = (double)(parameters->nr_bits_out)/(double)(parameters->block_size*8); Nspd <= MAXDATASPD; Nspd = Nspd * 2){
	//for(Nspd = 0.125; Nspd <= MAXDATASPD; Nspd = Nspd * 2){	
        for(Ndwl = 1; Ndwl <= MAXDATAN; Ndwl = Ndwl * 2){
            for(Ndbl = 1; Ndbl <= MAXDATAN; Ndbl = Ndbl * 2){
                for(Ndcm = 1; Ndcm <= MAX_COL_MUX; Ndcm = Ndcm * 2){
                    for(Ndsam_level_1 = 1; Ndsam_level_1 <= MAX_COL_MUX; Ndsam_level_1 = Ndsam_level_1 * 2){
						for(Ndsam_level_2 = 1; Ndsam_level_2 <= MAX_COL_MUX; Ndsam_level_2 = Ndsam_level_2 * 2){
							is_valid_partition = calculate_time(parameters, NSubbanks, is_tag, pure_ram, Nspd, Ndwl, 
								Ndbl, Ndcm, Ndsam_level_1, Ndsam_level_2, data_arr[data_arr_index], 0, NULL, NULL, &arr_edge_to_bank_edge_htree_sizing, &bnk_htree_sizing);
							if(is_valid_partition){
								++data_arr_index;
								data_arr[data_arr_index] = (mem_array *) malloc(sizeof(mem_array));
							}
						}
                    }
                }
            }
        }
    }
    free(data_arr[data_arr_index]);
    max_data_arr_index = data_arr_index - 1;

	if(!pure_ram){
		for(i = 0; i <= max_tag_arr_index; ++i){
		//Find the tag array with the best access time
			acc_time_tag_arr = tag_arr[i]->access_time;
			if(acc_time_tag_arr < best_acc_time_tag_arr){
				best_acc_time_tag_arr = acc_time_tag_arr;
				best_acc_time_tag_arr_index = i;
			}
		}
	}

    //Find best area for cache
    if(!pure_ram){
        //for(i = 0; i < max_tag_arr_index; ++i){
		    i = best_acc_time_tag_arr_index;
			for(j = 0; j < max_data_arr_index; ++j){
				area = tag_arr[i]->area + data_arr[j]->area;
				efficiency = (tag_arr[i]->area_ram_cells + data_arr[j]->area_ram_cells) * 100 / area;
                if(efficiency > max_efficiency){
                    max_efficiency = efficiency;
                }
            }
        //}
    }
    else{//Pure RAM, find best area.
        for(j = 0; j < max_data_arr_index; ++j){
            area = data_arr[j]->area;
			efficiency = data_arr[j]->area_ram_cells * 100 / area;
                if(efficiency > max_efficiency){
					max_efficiency = efficiency;
                }
		}
	}
	}
	
	//Find all solutions that are within MAXAREACONSTRAINT_PERC of the best area solution.
    index_insertion_slot = 0; 
	if(parameters->fully_assoc){
		for(j = 0; j < max_tag_arr_index; ++j){
			area = tag_arr[j]->area + data_arr[j]->area;
			efficiency = (tag_arr[j]->area_ram_cells + data_arr[j]->area_ram_cells) * 100 / area;
			if(efficiency > max_efficiency){
				max_efficiency = efficiency;
			}
		}
		for(j = 0; j <= max_tag_arr_index; ++j){
			curr_solution.area = tag_arr[j]->area + data_arr[j]->area;
			curr_solution.access_time = tag_arr[j]->access_time + data_arr[j]->access_time;
			curr_solution.cycle_time = MAX(tag_arr[j]->cycle_time, data_arr[j]->cycle_time);
			curr_solution.efficiency = (tag_arr[j]->area_ram_cells + data_arr[j]->area_ram_cells) * 100 / curr_solution.area;
			percent_diff_efficiency_wrt_max_efficiency = (max_efficiency - curr_solution.efficiency) * 100 / max_efficiency;
			aspect_ratio = tag_arr[j]->height / tag_arr[j]->width;
			perc_away_from_aspect_ratio = abs((aspect_ratio - STACKED_DIE_LAYER_ASPECT_RATIO)* 100 / STACKED_DIE_LAYER_ASPECT_RATIO);
			stacked_die_allot_area = STACKED_DIE_LAYER_ALLOTED_AREA_mm2;
			perc_wasted_area = 0;
			if(stacked_die_allot_area != 0){
				perc_wasted_area = abs((stacked_die_allot_area - curr_solution.area * 1e-6) * 100 / stacked_die_allot_area);
			}
			if(((ram_cell_tech_flavor != 3)&&(ram_cell_tech_flavor != 4)&&(curr_solution.cycle_time <= TARGET_CYCLE_TIME_ns * 1e-9))||
				(ram_cell_tech_flavor == 3) || (ram_cell_tech_flavor == 4)){
					if(((STACKED_DIE_LAYER_ALLOTED_AREA_mm2 > 0)&&(MAX_PERCENT_AWAY_FROM_ASPECT_RATIO > 100)&&(curr_solution.area * 1e-6 <= STACKED_DIE_LAYER_ALLOTED_AREA_mm2)&&(perc_wasted_area <= MAX_PERCENT_AWAY_FROM_ALLOTED_AREA)&&(curr_solution.efficiency >= MIN_AREA_EFFICIENCY))||
						((STACKED_DIE_LAYER_ALLOTED_AREA_mm2 > 0)&&((MAX_PERCENT_AWAY_FROM_ASPECT_RATIO <= 100))&&(perc_away_from_aspect_ratio <= MAX_PERCENT_AWAY_FROM_ASPECT_RATIO))||
						((STACKED_DIE_LAYER_ALLOTED_AREA_mm2 == 0)&&(percent_diff_efficiency_wrt_max_efficiency <= MAXAREACONSTRAINT_PERC))){
							curr_solution.tag_array_index = j;
							curr_solution.data_array_index = j;
							curr_solution.total_power.readOp.leakage = tag_arr[j]->power.readOp.leakage + data_arr[j]->power.readOp.leakage;
							curr_solution.total_power.readOp.dynamic = tag_arr[j]->power.readOp.dynamic + data_arr[j]->power.readOp.dynamic;
							curr_solution.total_power.writeOp.dynamic = tag_arr[j]->power.writeOp.dynamic + data_arr[j]->power.writeOp.dynamic;
							*best_solution[index_insertion_slot] = curr_solution;
							if(curr_solution.access_time < min_acc_time_in_best_area_solutions ){
								min_acc_time_in_best_area_solutions = curr_solution.access_time;
							}
							++index_insertion_slot;
							best_solution[index_insertion_slot] = (solution *) malloc(sizeof(solution));

/*#ifdef __unix__
                    bzero(best_solution[index_insertion_slot], sizeof(solution));
#endif*/
					}
			}
		}
        //}
	}
    else if(!pure_ram){//cache
        //for(i = 0; i <= max_tag_arr_index; ++i){
		i = best_acc_time_tag_arr_index;
            for(j = 0; j <= max_data_arr_index; ++j){
				curr_solution.area = tag_arr[i]->area + data_arr[j]->area ;
				curr_solution.cycle_time = MAX(tag_arr[i]->cycle_time, data_arr[j]->cycle_time);
				curr_solution.efficiency = (tag_arr[i]->area_ram_cells + data_arr[j]->area_ram_cells) * 100 / curr_solution.area;
                percent_diff_efficiency_wrt_max_efficiency = 
                    (max_efficiency - curr_solution.efficiency) * 100 / max_efficiency;
				aspect_ratio = data_arr[j]->height / data_arr[j]->width;
				perc_away_from_aspect_ratio = abs((aspect_ratio - STACKED_DIE_LAYER_ASPECT_RATIO)* 100 / STACKED_DIE_LAYER_ASPECT_RATIO);
				stacked_die_allot_area = STACKED_DIE_LAYER_ALLOTED_AREA_mm2;
			    perc_wasted_area = 0;
			    if(stacked_die_allot_area != 0){	
					perc_wasted_area = abs((stacked_die_allot_area - curr_solution.area * 1e-6) * 100 / stacked_die_allot_area);
				}
				if(((ram_cell_tech_flavor != 3)&&(ram_cell_tech_flavor != 4)&&(curr_solution.cycle_time <= TARGET_CYCLE_TIME_ns * 1e-9))||
					(ram_cell_tech_flavor == 3) || (ram_cell_tech_flavor == 4)){
				if(((STACKED_DIE_LAYER_ALLOTED_AREA_mm2 > 0)&&(MAX_PERCENT_AWAY_FROM_ASPECT_RATIO > 100)&&(curr_solution.area * 1e-6 <= STACKED_DIE_LAYER_ALLOTED_AREA_mm2)&&(perc_wasted_area <= MAX_PERCENT_AWAY_FROM_ALLOTED_AREA)&&(curr_solution.efficiency > 30))||
					((STACKED_DIE_LAYER_ALLOTED_AREA_mm2 > 0)&&((MAX_PERCENT_AWAY_FROM_ASPECT_RATIO <= 100))&&(perc_away_from_aspect_ratio <= MAX_PERCENT_AWAY_FROM_ASPECT_RATIO))||
					((STACKED_DIE_LAYER_ALLOTED_AREA_mm2 == 0)&&(percent_diff_efficiency_wrt_max_efficiency <= MAXAREACONSTRAINT_PERC))){
                    curr_solution.tag_array_index = i;
                    curr_solution.data_array_index = j;
					if(parameters->sequential_access){//Sequential access
						curr_solution.access_time = tag_arr[i]->access_time + data_arr[j]->access_time;
					}
					else 
						if(parameters->fast_access){
							curr_solution.access_time = MAX(tag_arr[i]->access_time, data_arr[j]->access_time);
						}
						else{//normal access
							if(parameters->tag_associativity > 1){//set-associative cache
								curr_solution.access_time = MAX(tag_arr[i]->access_time +
									data_arr[j]->delay_senseamp_mux_decoder,
									data_arr[j]->delay_before_subarray_output_driver) +
									data_arr[j]->delay_from_subarray_output_driver_to_output;
							}
							else{//direct-mapped cache
								curr_solution.access_time = MAX(tag_arr[i]->access_time, data_arr[j]->access_time);
							}
						}
					curr_solution.total_power.readOp.leakage = tag_arr[i]->power.readOp.leakage + data_arr[j]->power.readOp.leakage;
                    curr_solution.total_power.readOp.dynamic = tag_arr[i]->power.readOp.dynamic + data_arr[j]->power.readOp.dynamic;
					curr_solution.total_power.writeOp.dynamic = tag_arr[i]->power.writeOp.dynamic + data_arr[j]->power.writeOp.dynamic;
                    *best_solution[index_insertion_slot] = curr_solution;
					if(curr_solution.access_time < min_acc_time_in_best_area_solutions ){
						min_acc_time_in_best_area_solutions = curr_solution.access_time;
					}
					++index_insertion_slot;
					best_solution[index_insertion_slot] = (solution *) malloc(sizeof(solution));
/*#ifdef __unix__
                    bzero(best_solution[index_insertion_slot], sizeof(solution));
#endif*/
                }
            }
			}
        //}
    }
    else{//plain RAM
		for(j = 0; j <= max_data_arr_index; ++j){
			curr_solution.area = data_arr[j]->area;
            curr_solution.efficiency =  data_arr[j]->area_ram_cells * 100 / curr_solution.area;
			percent_diff_efficiency_wrt_max_efficiency = 
				(max_efficiency - curr_solution.efficiency) * 100 / max_efficiency;
			aspect_ratio = data_arr[j]->height / data_arr[j]->width;
			perc_away_from_aspect_ratio = abs((aspect_ratio - STACKED_DIE_LAYER_ASPECT_RATIO)* 100 / STACKED_DIE_LAYER_ASPECT_RATIO);
            //if(percent_diff_efficiency_wrt_max_efficiency <= MAXAREACONSTRAINT_PERC){
			if(((STACKED_DIE_LAYER_ALLOTED_AREA_mm2 > 0)&&(MAX_PERCENT_AWAY_FROM_ASPECT_RATIO > 100)&&(data_arr[j]->area * 1e-6 <= STACKED_DIE_LAYER_ALLOTED_AREA_mm2))||((STACKED_DIE_LAYER_ALLOTED_AREA_mm2 > 0)&&((MAX_PERCENT_AWAY_FROM_ASPECT_RATIO <= 100))&&(perc_away_from_aspect_ratio <= MAX_PERCENT_AWAY_FROM_ASPECT_RATIO))||((STACKED_DIE_LAYER_ALLOTED_AREA_mm2 == 0)&&(percent_diff_efficiency_wrt_max_efficiency <= MAXAREACONSTRAINT_PERC))){
				curr_solution.data_array_index = j;
				if((ram_cell_tech_flavor == 3)||(ram_cell_tech_flavor == 4)){
					curr_solution.access_time = data_arr[j]->access_time;
					curr_solution.cycle_time = data_arr[j]->cycle_time;
				}
				else{
					curr_solution.access_time = data_arr[j]->access_time;
					curr_solution.cycle_time = data_arr[j]->cycle_time;
				}
				copy_powerDef(&curr_solution.total_power, data_arr[j]->power);
				*best_solution[index_insertion_slot] = curr_solution;
                if(curr_solution.access_time < min_acc_time_in_best_area_solutions){
					best_min_acc_time_in_best_area_solutions = index_insertion_slot;
					min_acc_time_in_best_area_solutions = curr_solution.access_time;
				}
                ++index_insertion_slot;
                best_solution[index_insertion_slot] = (solution *) malloc(sizeof(solution));
/*#ifdef __linux__
                bzero(best_solution[index_insertion_slot], sizeof(solution));
#endif*/
            }
        }
    }
    free(best_solution[index_insertion_slot]);
    number_of_solutions = index_insertion_slot;
	
    //Inside the best area solutions, find all solutions that are within MAXACCTIMECONSTRAINT_PERC of 
	//min_acc_time_in_best_area.
    //We apply the objective function only to these solutions. 
	index_insertion_slot = 0; 
	for(i = 0; i < number_of_solutions; ++i){
		curr_solution = *best_solution[i];
		curr_solution.access_time = best_solution[i]->access_time;
		percent_diff_acc_time_wrt_min_acc_time = 
			(curr_solution.access_time - min_acc_time_in_best_area_solutions) * 100 / min_acc_time_in_best_area_solutions;
		if(percent_diff_acc_time_wrt_min_acc_time <= MAXACCTIMECONSTRAINT_PERC){
			*best_delay_solution_within_best_area_solutions[index_insertion_slot] = curr_solution;
			++index_insertion_slot;
			best_delay_solution_within_best_area_solutions[index_insertion_slot] = 
				(solution *) malloc(sizeof(solution));
/*#ifdef __unix__
		bzero(best_delay_solution_within_best_area_solutions[index_insertion_slot], sizeof(solution));
#endif*/
		}
    }
	free(best_delay_solution_within_best_area_solutions[index_insertion_slot]);
    number_of_best_delay_within_best_area_solutions = index_insertion_slot;
  

    //Find the values for best dynamic energy, dynamic power, best leakage power and best cycle time.
    for(i = 0; i < number_of_best_delay_within_best_area_solutions; ++i){
		if(result->min_dynamic_energy > best_delay_solution_within_best_area_solutions[i]->total_power.readOp.dynamic){
            result->min_dynamic_energy = best_delay_solution_within_best_area_solutions[i]->total_power.readOp.dynamic;
        }
        if(result->min_dynamic_power > best_delay_solution_within_best_area_solutions[i]->total_power.readOp.dynamic / best_delay_solution_within_best_area_solutions[i]->cycle_time){
            result->min_dynamic_power = best_delay_solution_within_best_area_solutions[i]->total_power.readOp.dynamic / best_delay_solution_within_best_area_solutions[i]->cycle_time;
        }
        if(result->min_leakage_power > best_delay_solution_within_best_area_solutions[i]->total_power.readOp.leakage){
            result->min_leakage_power = best_delay_solution_within_best_area_solutions[i]->total_power.readOp.leakage;
        }
        if(result->min_cycle_time > best_delay_solution_within_best_area_solutions[i]->cycle_time){
            result->min_cycle_time = best_delay_solution_within_best_area_solutions[i]->cycle_time;
        }
    }

	weight_dynamic_energy = 1;
    weight_leakage_power = 1;
    weight_dynamic_power = 1;
    weight_cycle_time = 1;

    for(i = 0; i < number_of_best_delay_within_best_area_solutions; ++i){
        if((objective_function(parameters->obj_func_dynamic_energy, parameters->obj_func_dynamic_power, parameters->obj_func_leakage_power, 
                    parameters->obj_func_cycle_time, weight_dynamic_energy, weight_dynamic_power, weight_leakage_power,
                    weight_cycle_time, result->total_power.readOp.dynamic / result->min_dynamic_energy,
                    (result->total_power.readOp.dynamic / result->cycle_time) / result->min_dynamic_power, 
                    result->total_power.readOp.leakage / result->min_leakage_power, 
                    result->cycle_time / result->min_cycle_time) >
                objective_function(parameters->obj_func_dynamic_energy, parameters->obj_func_dynamic_power, parameters->obj_func_leakage_power, 
                    parameters->obj_func_cycle_time, weight_dynamic_energy, weight_dynamic_power, weight_leakage_power, 
                    weight_cycle_time, best_delay_solution_within_best_area_solutions[i]->total_power.readOp.dynamic / result->min_dynamic_energy,
                    (best_delay_solution_within_best_area_solutions[i]->total_power.readOp.dynamic / best_delay_solution_within_best_area_solutions[i]->cycle_time) / result->min_dynamic_power, 
                    best_delay_solution_within_best_area_solutions[i]->total_power.readOp.leakage / result->min_leakage_power, 
                    best_delay_solution_within_best_area_solutions[i]->cycle_time / result->min_cycle_time))||i == 0){
            copy_powerDef(&result->total_power, best_delay_solution_within_best_area_solutions[i]->total_power);
            arearesult->totalarea = best_delay_solution_within_best_area_solutions[i]->area * 1e-6;
            result->cycle_time = best_delay_solution_within_best_area_solutions[i]->cycle_time;
            result->access_time = best_delay_solution_within_best_area_solutions[i]->access_time;
            arearesult->efficiency = best_delay_solution_within_best_area_solutions[i]->efficiency;
            data_arr_index = best_delay_solution_within_best_area_solutions[i]->data_array_index;
            result->best_Nspd = data_arr[data_arr_index]->Nspd;
            result->best_Ndwl = data_arr[data_arr_index]->Ndwl;
            result->best_Ndbl = data_arr[data_arr_index]->Ndbl;
            result->best_data_deg_bitline_muxing = data_arr[data_arr_index]->deg_bitline_muxing;
            result->best_Ndsam_level_1 = data_arr[data_arr_index]->Ndsam_level_1;
			result->best_Ndsam_level_2 = data_arr[data_arr_index]->Ndsam_level_2;
            if(!pure_ram){
                tag_arr_index = best_delay_solution_within_best_area_solutions[i]->tag_array_index;
                result->best_Ntspd = tag_arr[tag_arr_index]->Nspd;
                result->best_Ntwl = tag_arr[tag_arr_index]->Ndwl;
                result->best_Ntbl = tag_arr[tag_arr_index]->Ndbl;
                result->best_tag_deg_bitline_muxing = tag_arr[tag_arr_index]->deg_bitline_muxing;
                result->best_Ntsam_level_1 = tag_arr[tag_arr_index]->Ndsam_level_1;
				result->best_Ntsam_level_2 = tag_arr[tag_arr_index]->Ndsam_level_2;
            }
        }
    }
	
	free(tag_arr[0]);
	for(i = 1; i <= max_tag_arr_index; i++){
		free(tag_arr[i]);
	}

	free(data_arr[0]);
	for(i = 1; i <= max_data_arr_index; i++){
		free(data_arr[i]);
	}

	free(best_solution[0]);
    for(i = 1; i < number_of_solutions; i++){
		free(best_solution[i]);
    }
 
    free(best_delay_solution_within_best_area_solutions[0]);
	for(i = 1; i < number_of_best_delay_within_best_area_solutions; i++) {
        free(best_delay_solution_within_best_area_solutions[i]);
    }

    fin_res->access_time = result->access_time;
    fin_res->cycle_time = result->cycle_time;
    fin_res->area = arearesult->totalarea;
    fin_res->area_efficiency = arearesult->efficiency;
    fin_res->power = result->total_power;
	
	if(!pure_ram){
		ram_cell_tech_flavor = tag_arr_ram_cell_tech_flavor;
		periph_global_tech_flavor = tag_arr_periph_global_tech_flavor;
		saved_is_main_mem = is_main_mem;
		is_main_mem = 0;
		init_tech_params(parameters->tech_size);
		compute_widths_repeaters_array_edge_to_bank_edge(&arr_edge_to_bank_edge_htree_sizing);
		compute_widths_repeaters_bank_htree(&bnk_htree_sizing);
        is_valid_partition = calculate_time(parameters, NSubbanks, 1, pure_ram, result->best_Ntspd, result->best_Ntwl, 
                result->best_Ntbl, result->best_tag_deg_bitline_muxing, result->best_Ntsam_level_1, result->best_Ntsam_level_2, NULL, 1, &fin_res->tag_array, fin_res,
				&arr_edge_to_bank_edge_htree_sizing, &bnk_htree_sizing);
        ram_cell_tech_flavor = data_arr_ram_cell_tech_flavor;
		periph_global_tech_flavor = data_arr_periph_global_tech_flavor;
		is_main_mem = saved_is_main_mem;
		init_tech_params(parameters->tech_size);
		compute_widths_repeaters_array_edge_to_bank_edge(&arr_edge_to_bank_edge_htree_sizing);
		compute_widths_repeaters_bank_htree(&bnk_htree_sizing);
        is_valid_partition = calculate_time(parameters, NSubbanks, 0, pure_ram, result->best_Nspd, result->best_Ndwl, 
                result->best_Ndbl, result->best_data_deg_bitline_muxing, result->best_Ndsam_level_1, result->best_Ndsam_level_2, NULL, 1, &fin_res->data_array, fin_res,
				&arr_edge_to_bank_edge_htree_sizing, &bnk_htree_sizing);
		fin_res->leak_power_with_sleep_transistors_in_mats =(100 - fin_res->data_array.perc_leak_mats -  
			fin_res->tag_array.perc_leak_mats) * fin_res->power.readOp.leakage / 100 +
			fin_res->data_array.perc_active_mats  * (fin_res->data_array.perc_leak_mats * 
			fin_res->power.readOp.leakage / 100) / 100 + 
			fin_res->tag_array.perc_active_mats  * (fin_res->tag_array.perc_leak_mats * 
			fin_res->power.readOp.leakage / 100) / 100  +
			((100 - fin_res->data_array.perc_active_mats)  * (fin_res->data_array.perc_leak_mats * 
			fin_res->power.readOp.leakage / 100) / 100) / MAT_LEAKAGE_REDUCTION_DUE_TO_SLEEP_TRANSISTORS_FACTOR + 
			((100 - fin_res->tag_array.perc_active_mats)  * (fin_res->tag_array.perc_leak_mats * 
			fin_res->power.readOp.leakage / 100) / 100) / MAT_LEAKAGE_REDUCTION_DUE_TO_SLEEP_TRANSISTORS_FACTOR; 
    }
    else{
		compute_widths_repeaters_array_edge_to_bank_edge(&arr_edge_to_bank_edge_htree_sizing);
		compute_widths_repeaters_bank_htree(&bnk_htree_sizing);
        is_valid_partition = calculate_time(parameters, NSubbanks, 0, pure_ram, result->best_Nspd, result->best_Ndwl, 
                result->best_Ndbl, result->best_data_deg_bitline_muxing, result->best_Ndsam_level_1, result->best_Ndsam_level_2, NULL, 1, &fin_res->data_array, fin_res,
				&arr_edge_to_bank_edge_htree_sizing, &bnk_htree_sizing);
		fin_res->leak_power_with_sleep_transistors_in_mats =(100 - fin_res->data_array.perc_leak_mats) * 
			fin_res->power.readOp.leakage / 100 +
			fin_res->data_array.perc_active_mats  * (fin_res->data_array.perc_leak_mats * 
			fin_res->power.readOp.leakage / 100) / 100 + 
			((100 - fin_res->data_array.perc_active_mats)  * (fin_res->data_array.perc_leak_mats * 
			fin_res->power.readOp.leakage / 100) / 100) / MAT_LEAKAGE_REDUCTION_DUE_TO_SLEEP_TRANSISTORS_FACTOR;
    }
	
		
/*#ifdef __unix__
    pthread_mutex_unlock(&com_mut_var); 
#endif*/
    fin_res->params = *parameters;
    if (fin_res) {
        fin_res->cache_ht = MAX(fin_res->tag_array.all_banks_height, fin_res->data_array.all_banks_height);
        fin_res->cache_len = fin_res->tag_array.all_banks_width + fin_res->data_array.all_banks_width;
        //PRINTD(fprintf(stderr, "calculate_time: cache_ht x cache_len = %f x %f\n", 
                    //fin_res->cache_ht, fin_res->cache_len));
    }
    //fprintf(stderr,"do_it: valid fin_res %f\n", fin_res->access_time);
    //fig_out(fin_res);
}




