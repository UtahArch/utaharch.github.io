/*------------------------------------------------------------
 *                               CACTI 5.2
 *         Copyright 2008 Hewlett-Packard Development Corporation
 *                         All Rights Reserved
 *
 * Permission to use, copy, and modify this software and its documentation is
 * hereby granted only under the following terms and conditions.  Both the
 * above copyright notice and this permission notice must appear in all copies
 * of the software, derivative works or modified versions, and any portions
 * thereof, and both notices must appear in supporting documentation.
 *
 * Users of this software agree to the terms and conditions set forth herein, and
 * hereby grant back to Hewlett-Packard Company and its affiliated companies ("HP")
 * a non-exclusive, unrestricted, royalty-free right and license under any changes, 
 * enhancements or extensions  made to the core functions of the software, including 
 * but not limited to those affording compatibility with other hardware or software
 * environments, but excluding applications which incorporate this software.
 * Users further agree to use their best efforts to return to HP any such changes,
 * enhancements or extensions that they make and inform HP of noteworthy uses of
 * this software.  Correspondence should be provided to HP at:
 *
 *                       Director of Intellectual Property Licensing
 *                       Office of Strategy and Technology
 *                       Hewlett-Packard Company
 *                       1501 Page Mill Road
 *                       Palo Alto, California  94304
 *
 * This software may be distributed (but not offered for sale or transferred
 * for compensation) to third parties, provided such third parties agree to
 * abide by the terms and conditions of this notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND HP DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS.   IN NO EVENT SHALL HP 
 * CORPORATION BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 *------------------------------------------------------------*/


#ifndef ioh
#define ioh
#include "time.h"

typedef struct fig_mat_dim {
    int h;
    int w;
    int top_y;
    int bottom_y;
}fig_mat_dim_t;

typedef struct input_args {
		int cache_size;
		int line_size;
		int associativity;
		int rw_ports;
		int excl_read_ports;
		int excl_write_ports;
		int single_ended_read_ports;
		int banks;
		double tech_node;
		int output_width;
		int specific_tag;
		int tag_width;
		int access_mode;
		int cache;
		int main_mem;
		int obj_func_dynamic_energy;
		int obj_func_dynamic_power;
		int obj_func_leakage_power;
		int obj_func_cycle_time;
		int temp;
        int nuca_bank_count;
}input_args_t;

/* if you add any variable to bank_out, make appropriate modifications 
 * to copy_bank_out function.
 */
typedef struct bank_out {
    int size;
    /* area, power, access time, and cycle time stats */
    pda_res_t nuca_pda;
    pda_res_t bank_pda;
    pda_res_t router_pda;
    pda_res_t wire_pda_horizontal;
    pda_res_t wire_pda_vertical;

    /* grid network stats */
    int rows;
    int columns;
    input_args_t input_params;
}bank_out_t;

void strreverse(char *, char*);
#ifdef __unix__
void itoa(int, char*, int);
#endif
bank_out_t *
find_optimal_config(bank_out_t **, int);

void copy_bank_out(bank_out_t *, bank_out_t *);
bank_out_t * find_optimal_config(bank_out_t **, int);
void dump_bank_out(bank_out_t *);
int calc_hoplat(double);
int input_data(int argc,char *argv[]);
void output_data(result_type *result,arearesult_type *arearesult, parameter_type *parameters);
void output_data_csv(final_results* result);
void init_tech_params_default_process();
void output_area_components(arearesult_type *arearesult, parameter_type *parameters);
void output_time_components(result_type *result,parameter_type *parameters);
void fig_out (final_results *fr);
void insert_mat (int a, int b, int c, int d, FILE *f);
//final_results sim_cache(int, int, int, int, int, int, int, int, double,
//    int, int, int, int, int, int, int, int, int, int, int,
//    bank_out_t *);
//final_results sim_cache(
//		int cache_size,
//		int line_size,
//		int associativity,
//		int rw_ports,
//		int excl_read_ports,
//		int excl_write_ports,
//		int single_ended_read_ports,
//		int banks,
//		double tech_node,
//		int output_width,
//		int specific_tag,
//		int tag_width,
//		int access_mode,
//		int cache,
//		int main_mem,
//		int obj_func_dynamic_energy,
//		int obj_func_dynamic_power,
//		int obj_func_leakage_power,
//		int obj_func_cycle_time,
//		int temp,
//        bank_out_t *out
//        );
final_results sim_cache(bank_out_t *);
void * sim_nuca(bank_out_t *);
#endif
