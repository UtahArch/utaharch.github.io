/*------------------------------------------------------------
 *                              CACTI 5.0
 *         Copyright 2007 Hewlett-Packard Development Corporation
 *                         All Rights Reserved
 *
 * Permission to use, copy, and modify this software and its documentation is
 * hereby granted only under the following terms and conditions.  Both the
 * above copyright notice and this permission notice must appear in all copies
 * of the software, derivative works or modified versions, and any portions
 * thereof, and both notices must appear in supporting documentation.
 *
 * Users of this software agree to the terms and conditions set forth herein, and
 * hereby grant back to Hewlett-Packard Company and its affiliated companies ("HP")
 * a non-exclusive, unrestricted, royalty-free right and license under any changes, 
 * enhancements or extensions  made to the core functions of the software, including 
 * but not limited to those affording compatibility with other hardware or software
 * environments, but excluding applications which incorporate this software.
 * Users further agree to use their best efforts to return to HP any such changes,
 * enhancements or extensions that they make and inform HP of noteworthy uses of
 * this software.  Correspondence should be provided to HP at:
 *
 *                       Director of Intellectual Property Licensing
 *                       Office of Strategy and Technology
 *                       Hewlett-Packard Company
 *                       1501 Page Mill Road
 *                       Palo Alto, California  94304
 *
 * This software may be distributed (but not offered for sale or transferred
 * for compensation) to third parties, provided such third parties agree to
 * abide by the terms and conditions of this notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND HP DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS.   IN NO EVENT SHALL HP 
 * CORPORATION BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 *------------------------------------------------------------*/
#ifndef _def
#define _def
#endif
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "stdio.h"
#include <stdlib.h>
/*#ifdef __unix__
#include <pthread.h>
#include <assert.h>
#endif*/

/*  The following are things you might want to change
 *  when compiling
 */


/*
 * Address bits in a word, and number of output bits from the cache 
 */

/*
was: #define ADDRESS_BITS 32
now: I'm using 42 bits as in the Power4, 
since that's bigger then the 36 bits on the Pentium 4 
and 40 bits on the Opteron
*/
#define ADDRESS_BITS 42

int BITOUT;

/*dt: In addition to the tag bits, the tags also include 1 valid bit, 1 dirty bit, 2 bits for a 4-state 
  cache coherency protocoll (MESI), 1 bit for MRU (change this to log(ways) for full LRU). 
  So in total we have 1 + 1 + 2 + 1 = 5 */
#define EXTRA_TAG_BITS 5


/* limits on the various N parameters */


#define MAXDATAN 4096       /* Maximum for Ndwl,Ndbl */
#define MAXSUBARRAYS 1048576  /* Maximum subarrays for data and tag arrays */
#define MAXDATASPD 4096         /* Maximum for Nspd */


double FUDGEFACTOR;

double FEATURESIZE;


double Cwordmetal;
double Cbitmetal;
double Rwordmetal;
double Rbitmetal;

double TagCwordmetal;
double TagCbitmetal;
double TagRwordmetal;
double TagRbitmetal;



double Cgate;	
double Cgatepass;		

/* note that the value of Cgatepass will be different depending on 
   whether or not the source and drain are at different potentials or
   the same potential.  The two values were averaged */
	
double Cpolywire;			 


;

//static double vdd_periph_global;
/* Threshold voltages (as a proportion of Vdd)
   If you don't know them, set all values to 0.5 */

#define SizingRatio   0.33
#define VTHNAND       0.561
#define VTHFA1        0.452
#define VTHFA2        0.304
#define VTHFA3        0.420
#define VTHFA4        0.413
#define VTHFA5        0.405
#define VTHFA6        0.452
#define VSINV         0.452   
#define VTHINV100x60  0.438   /* inverter with p=100,n=60 */
#define VTHINV360x240 0.420   /* inverter with p=360, n=240 */
#define VTHNAND60x90  0.561   /* nand with p=60 and three n=90 */
#define VTHNOR12x4x1  0.503   /* nor with p=12, n=4, 1 input */
#define VTHNOR12x4x2  0.452   /* nor with p=12, n=4, 2 inputs */
#define VTHNOR12x4x3  0.417   /* nor with p=12, n=4, 3 inputs */
#define VTHNOR12x4x4  0.390   /* nor with p=12, n=4, 4 inputs */
#define VTHOUTDRINV    0.437
#define VTHOUTDRNOR   0.379
#define VTHOUTDRNAND  0.63
#define VTHOUTDRIVE   0.425
#define VTHCOMPINV    0.437
#define VTHMUXNAND    0.548
#define VTHMUXDRV1    0.406
#define VTHMUXDRV2    0.334
#define VTHMUXDRV3    0.478
#define VTHEVALINV    0.452
#define VTHSENSEEXTDRV  0.438

#define VTHNAND60x120 0.522


double Gm_sense_amp_transistors;


double Wmemcella_dram, Wmemcella_sram;
double Wmemcellpmos_dram, Wmemcellpmos_sram;
double Wmemcellnmos_dram, Wmemcellnmos_sram;


double Wpchmax;


double Wiso;
double WsenseEn;
double WsenseN;
double WsenseP;


double width_nmos_bit_mux, width_nmos_sense_amp_mux, width_pmos_bitline_precharge, 
width_pmos_bitline_equalization;


//#define Wcompinvp1	(10.0)
double Wcompinvp1;
//#define Wcompinvn1	(6.0)
double Wcompinvn1;
//#define Wcompinvp2	(20.0)
double Wcompinvp2;
//#define Wcompinvn2	(12.0)
double Wcompinvn2;
//#define Wcompinvp3	(40.0)
double Wcompinvp3;
//#define Wcompinvn3	(24.0)
double Wcompinvn3;
//#define Wevalinvp	(80.0)
double Wevalinvp;
//#define Wevalinvn	(40.0)
double Wevalinvn;



//#define Wcompn		(10.0)
double Wcompn;
//#define Wcompp		(30.0)
double Wcompp;



double WmuxdrvNANDn    ;
double WmuxdrvNANDp    ;






double Vbitpre_dram;
double Vt_dram;
double Vbitpre_sram;
double Vt_sram;

double Vbitsense;




/*===================================================================*/

/*
 * The following are things you probably wouldn't want to change.  
 */


#define TRUE 1
#define FALSE 0
#ifndef NULL
#define NULL 0
#endif
#define OK 1
#define ERROR 0
#define BIGNUM 1e30
#define INF 9999999
#define DIVIDE(a,b) ((b)==0)? 0:(a)/(b)
#define MAX(a,b) (((a)>(b))?(a):(b))
//v5.0
#define MIN(a,b) (((a)<(b))?(a):(b))

#define WAVE_PIPE 3
#define MAX_COL_MUX 1024

/* Used to communicate with the horowitz model */

#define RISE 1
#define FALL 0
#define NCH  1
#define PCH  0


/* Used to pass values around the program */


int sequential_access_flag;
int fast_cache_access_flag;
int pure_sram_flag;
int is_dram;

#define EPSILON 0.5 //v4.1: This constant is being used in order to fix floating point -> integer
//conversion problems that were occuring within CACTI. Typical problem that was occuring was
//that with different compilers a floating point number like 3.0 would get represented as either 
//2.9999....or 3.00000001 and then the integer part of the floating point number (3.0) would 
//be computed differently depending on the compiler. What we are doing now is to replace 
//int (x) with (int) (x+EPSILON) where EPSILON is 0.5. This would fix such problems. Note that
//this works only when x is an integer >= 0. 

#define EPSILON2 0.1  

#define EPSILON3 0.6


#define MINSUBARRAYROWS 16 //For simplicity in modeling, for the row decoding structure, we assume
//that each row predecode block is composed of at least one 2-4 decoder. When the outputs from the
//row predecode blocks are combined this means that there are at least 4*4=16 row decode outputs
#define MAXSUBARRAYROWS 262144 //Each row predecode block produces a max of 2^9 outputs. So 
//the maximum number of row decode outputs will be 2^9*2^9
#define MINSUBARRAYCOLS 2
#define MAXSUBARRAYCOLS 262144


double MIN_GAP_BET_P_AND_N_DIFFS, HPOWERRAIL, DEFAULTHEIGHTCELL, MIN_GAP_BET_SAME_TYPE_DIFFS;
double WIDTHPOLYCONTACT, SPACINGPOLYTOPOLY, SPACINGPOLYTOCONTACT;


#define INV 0
#define NOR 1
#define NAND 2

double Wcolmuxdec3to8p, Wcolmuxdec3to8n, Wcolmuxnorp, Wcolmuxnorn;

double c_dram_cell;

double restore_delay;
double refresh_power;
double dram_refresh_period;

double input_tech;



#define NUMBER_TECH_FLAVORS 4
double vdd[NUMBER_TECH_FLAVORS];
double Lphy[NUMBER_TECH_FLAVORS];
double Lelec[NUMBER_TECH_FLAVORS];
double t_ox[NUMBER_TECH_FLAVORS];
double v_th[NUMBER_TECH_FLAVORS];
double c_ox[NUMBER_TECH_FLAVORS];
double mobility_eff[NUMBER_TECH_FLAVORS];
double Vdsat[NUMBER_TECH_FLAVORS];
double c_g_ideal[NUMBER_TECH_FLAVORS];
double c_fringe[NUMBER_TECH_FLAVORS];
double c_junc[NUMBER_TECH_FLAVORS];
double I_on_n[NUMBER_TECH_FLAVORS];
double I_on_p[NUMBER_TECH_FLAVORS];
double Rnchannelon[NUMBER_TECH_FLAVORS];
double Rpchannelon[NUMBER_TECH_FLAVORS];
double nmos_to_pmos_effective_current_drive_ratio[NUMBER_TECH_FLAVORS];
double I_off_n[NUMBER_TECH_FLAVORS][200];
double I_off_p[NUMBER_TECH_FLAVORS][200];

#define NUMBER_INTERCONNECT_PROJECTION_TYPES 2 //aggressive and conservative
//0 = Aggressive projections, 1 = Conservative projections
#define NUMBER_WIRE_TYPES 3 //local, semi-global and global
//1 = 'Semi-global' wire type, 2 = 'Global' wire type


double wire_inside_mat_pitch, wire_inside_mat_r_per_micron, wire_inside_mat_c_per_micron,
wire_outside_mat_pitch, wire_outside_mat_r_per_micron, wire_outside_mat_c_per_micron,
wire_local_pitch, wire_local_r_per_micron, wire_local_c_per_micron;

double wire_pitch[NUMBER_INTERCONNECT_PROJECTION_TYPES][NUMBER_WIRE_TYPES],
wire_r_per_micron[NUMBER_INTERCONNECT_PROJECTION_TYPES][NUMBER_WIRE_TYPES],
wire_c_per_micron[NUMBER_INTERCONNECT_PROJECTION_TYPES][NUMBER_WIRE_TYPES];
int interconnect_projection_type;
int wire_inside_mat_type, wire_outside_mat_type; 

double wire_local_pitch_tech_node[2], wire_local_r_per_micron_tech_node[2],
wire_local_c_per_micron_tech_node[2], wire_inside_mat_pitch_tech_node[2],
wire_inside_mat_r_per_micron_tech_node[2], wire_inside_mat_c_per_micron_tech_node[2],
wire_outside_mat_pitch_tech_node[2], wire_outside_mat_r_per_micron_tech_node[2],
wire_outside_mat_c_per_micron_tech_node[2];


int periph_global_tech_flavor;
int sram_cell_and_wordline_tech_flavor;
int dram_cell_tech_flavor;
	  

double vdd_periph_global;
double Lphy_periph_global;
double Lelec_periph_global;
double t_ox_periph_global;
double v_th_periph_global;
double c_ox_periph_global;
double mobility_eff_periph_global;
double Vdsat_periph_global;
double c_g_ideal_itrs_periph_global ;
double c_fringe_itrs_periph_global ;
double c_junc_itrs_periph_global ;
double c_overlap_itrs_periph_global ;
double I_on_n_periph_global ;
double I_on_p_periph_global ;
double Rnchannelon_itrs_periph_global ;
double Rpchannelon_itrs_periph_global ;
double nmos_to_pmos_effective_current_drive_ratio_periph_global;
double  I_off_n_periph_global[200];
double  I_off_p_periph_global[200];

double vdd_sram_cell;
double Lphy_sram_cell_transistor;
double t_ox_sram_cell_transistor;
double v_th_sram_cell_transistor;

double Lmemcella;
double Lmemcellpmos;
double Lmemcellnmos;
double Lphy_sram_cell_transistor;
double Lelec_sram_cell_transistor;
double area_cell_dram;
double asp_ratio_cell_dram; 
double BitWidth_dram;
double BitHeight_dram;
double area_cell_sram;
double asp_ratio_cell_sram; 
double BitWidth_sram;
double BitHeight_sram;
double c_g_ideal_itrs_sram_cell_transistor;
double c_fringe_itrs_sram_cell_transisor;
double c_junc_itrs_sram_cell_transistor;
double c_fringe_itrs_sram_cell_transistor;
double c_overlap_itrs_sram_cell_transistor;
double I_on_n_sram_cell_transistor;
double I_on_p_sram_cell_transistor;
double Rnchannelon_itrs_sram_cell_transistor;
double Rpchannelon_itrs_sram_cell_transistor;
double nmos_to_pmos_effective_current_drive_ratio_sram_cell_transistor;
double I_off_n_sram_cell_transistor[200];
double I_off_p_sram_cell_transistor[200];
double t_ox_lstp;
double v_th_lstp;
double vth_lstp_sram_cell;

double vdd_dram_cell;
double vpp;
double v_th_dram_access_transistor;
double Lphy_dram_wordline_transistor;
double Lelec_dram_wordline_transistor;
double width_dram_access_transistor;
double c_g_ideal_itrs_dram_wordline_transistor;
double c_fringe_itrs_dram_wordline_transistor;
double c_junc_itrs_dram_wordline_transistor;
double c_fringe_itrs_dram_wordline_transistor;
double c_overlap_itrs_dram_wordline_transistor;
double I_on_n_dram_wordline_transistor;
double I_on_p_dram_wordline_transistor;
double Rnchannelon_itrs_dram_wordline_transistor;
double Rpchannelon_itrs_dram_wordline_transistor;
double nmos_to_pmos_effective_current_drive_ratio_dram_wordline_transistor;
double I_off_n_dram_wordline_transistor[200];
double I_off_p_dram_wordline_transistor[200];
double Lphy_dram_access_transistor;
double Lelec_dram_access_transistor;
double c_g_ideal_itrs_dram_access_transistor;
double c_fringe_itrs_dram_access_transistor;
double c_junc_itrs_dram_access_transistor;
double c_fringe_itrs_dram_access_transistor;
double c_overlap_itrs_dram_access_transistor;
double I_on_n_dram_access_transistor;
double I_on_p_dram_access_transistor;
double Rnchannelon_itrs_dram_access_transistor;
double Rpchannelon_itrs_dram_access_transistor;
int is_wordline_transistor;
int is_access_transistor;
int is_sram_cell;
int is_cell;
double I_on_dram_cell;
double  I_off_dram_cell_worst_case_length_temp;
double gmn_sense_amp_latch;
double gmp_sense_amp_latch;
double Gm_sense_amp_latch;

double vdd_periph_global_tech_node[2], t_ox_periph_global_tech_node[2],
v_th_periph_global_tech_node[2], c_ox_periph_global_tech_node[2],
c_g_ideal_itrs_periph_global_tech_node[2], c_fringe_itrs_periph_global_tech_node[2],
c_junc_itrs_periph_global_tech_node[2], 
Lphy_periph_global_tech_node[2], Lelec_periph_global_tech_node[2], I_on_n_periph_global_tech_node[2],
I_off_n_periph_global_tech_node[2][200], I_off_p_periph_global_tech_node[2][200],
Rnchannelon_itrs_periph_global_tech_node[2], Rpchannelon_itrs_periph_global_tech_node[2],
nmos_to_pmos_effective_current_drive_ratio_periph_global_tech_node[2]; 

double vdd_sram_cell_tech_node[2], Lphy_sram_cell_transistor_tech_node[2], Lelec_sram_cell_transistor_tech_node[2],
t_ox_sram_cell_transistor_tech_node[2], v_th_sram_cell_transistor_tech_node[2], c_g_ideal_itrs_sram_cell_transistor_tech_node[2],
c_fringe_itrs_sram_cell_transistor_tech_node[2], c_junc_itrs_sram_cell_transistor_tech_node[2],
I_on_n_sram_cell_transistor_tech_node[2],
I_off_n_sram_cell_transistor_tech_node[2][200], I_off_p_sram_cell_transistor_tech_node[2][200],
Rnchannelon_itrs_sram_cell_tech_node[2], Rpchannelon_itrs_sram_cell_tech_node[2],
nmos_to_pmos_effective_current_drive_ratio_sram_cell_tech_node[2];

double  vdd_dram_cell_tech_node[2], v_th_dram_access_transistor_tech_node[2], Lphy_dram_access_transistor_tech_node[2], 
Lelec_dram_access_transistor_tech_node[2], c_g_ideal_itrs_dram_access_transistor_tech_node[2],
c_fringe_itrs_dram_access_transistor_tech_node[2], c_junc_itrs_dram_access_transistor_tech_node[2], I_on_dram_cell_tech_node[2],
I_on_n_dram_access_transistor_tech_node[2], c_dram_cell_tech_node[2],
vpp_tech_node[2], Lphy_dram_wordline_transistor_tech_node[2], Lelec_dram_wordline_transistor_tech_node[2], c_g_ideal_itrs_dram_wordline_transistor_tech_node[2],
c_fringe_itrs_dram_wordline_transistor_tech_node[2], c_junc_itrs_dram_wordline_transistor_tech_node[2],
I_on_n_dram_wordline_transistor_tech_node[2],
I_off_n_dram_wordline_transistor_tech_node[2][200], I_off_p_dram_wordline_transistor_tech_node[2][200],
 mobility_eff_periph_global_tech_node[2], Vdsat_periph_global_tech_node[2];

double Rnchannelon_itrs_dram_wordline_transistor_tech_node[2], Rpchannelon_itrs_dram_wordline_transistor_tech_node[2],
nmos_to_pmos_effective_current_drive_ratio_dram_wordline_transistor_tech_node[2];

double Wmemcella_dram_tech_node[2], Wmemcellpmos_dram_tech_node[2], Wmemcellnmos_dram_tech_node[2],
 area_cell_dram_tech_node[2], asp_ratio_cell_dram_tech_node[2];
double Wmemcella_sram_tech_node[2], Wmemcellpmos_sram_tech_node[2], Wmemcellnmos_sram_tech_node[2],
 area_cell_sram_tech_node[2], asp_ratio_cell_sram_tech_node[2];

double nmos_effective_resistance_multiplier;
double gmp_to_gmn_multiplier[2], gmp_to_gmn_multiplier_periph_global, 
gmp_to_gmn_multiplier_periph_global_tech_node[2];



double height_cell;
double width_cell;



#define DEBUG
#ifdef DEBUG
#define PRINTD(a);\
a;
#endif

#define ERROR_EXIT(a,b);\
fprintf(a,b);\
exit(0);

#define VBITSENSEMIN 0.08 //minimum bitline sense voltage is fixed to be 80 mV.


int temper;

double height_mat;
double width_mat;
double height_subarray;
double width_subarray;

#define fopt 4.0

double minimum_width_nmos;


double gnand2;
double gnor2;
double gnand3;
double gpmos;
double gnmos;

double MAXAREACONSTRAINT_PERC;
double MAXACCTIMECONSTRAINT_PERC;

#define INPUT_WIRE_TO_INPUT_GATE_CAP_RATIO 0
double kinv;
double FO4, FO1, KLOAD;
double unit_length_wire_delay;
double normalized_unit_length_wire_delay;
double MAX_NMOS_WIDTH;

double MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION;
#define BUFFER_SEPARATION_LENGTH_MULTIPLIER 1

#define SRAM_NUMBER_CELLS_WORDLINE_STITCHING 16
#define DRAM_NUMBER_CELLS_WORDLINE_STITCHING 64
double RAM_NUMBER_CELLS_WORDLINE_STITCHING;
double RAM_WORDLINE_STITCHING_OVERHEAD;
#define NUMBER_BITS_PER_ECC_BIT 8
#define NUMBER_MATS_PER_REDUNDANT_MAT 8

#define VDD_STORAGE_LOSS_FRACTION_WORST 0.125
#define CU_RESISTIVITY 0.022 //ohm-micron
#define BULK_CU_RESISTIVITY 0.018 //ohm-micron
#define PERMITTIVITY_FREE_SPACE 8.854e-18 //F/micron

double cam_cell_height, cam_cell_width;
