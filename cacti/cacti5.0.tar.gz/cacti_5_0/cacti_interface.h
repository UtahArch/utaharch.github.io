/*------------------------------------------------------------
 *                              CACTI 5.0
 *         Copyright 2007 Hewlett-Packard Development Corporation
 *                         All Rights Reserved
 *
 * Permission to use, copy, and modify this software and its documentation is
 * hereby granted only under the following terms and conditions.  Both the
 * above copyright notice and this permission notice must appear in all copies
 * of the software, derivative works or modified versions, and any portions
 * thereof, and both notices must appear in supporting documentation.
 *
 * Users of this software agree to the terms and conditions set forth herein, and
 * hereby grant back to Hewlett-Packard Company and its affiliated companies ("HP")
 * a non-exclusive, unrestricted, royalty-free right and license under any changes, 
 * enhancements or extensions  made to the core functions of the software, including 
 * but not limited to those affording compatibility with other hardware or software
 * environments, but excluding applications which incorporate this software.
 * Users further agree to use their best efforts to return to HP any such changes,
 * enhancements or extensions that they make and inform HP of noteworthy uses of
 * this software.  Correspondence should be provided to HP at:
 *
 *                       Director of Intellectual Property Licensing
 *                       Office of Strategy and Technology
 *                       Hewlett-Packard Company
 *                       1501 Page Mill Road
 *                       Palo Alto, California  94304
 *
 * This software may be distributed (but not offered for sale or transferred
 * for compensation) to third parties, provided such third parties agree to
 * abide by the terms and conditions of this notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND HP DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS.   IN NO EVENT SHALL HP 
 * CORPORATION BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 *------------------------------------------------------------*/
#ifndef _cacti_interface
#define _cacti_interface
#endif

/*dt: currently we assume that everything is counted in bytes*/
#define CHUNKSIZE 8

typedef struct {
	double dynamic;
	double leakage;
} powerComponents;


typedef struct {
	powerComponents readOp;
	powerComponents writeOp;
} powerDef;



/* Used to pass values around the program */

struct cache_params_t
{
  unsigned int nsets;
  unsigned int assoc;
  unsigned int dbits;
  unsigned int tbits;

  unsigned int nbanks;
  unsigned int rport;
  unsigned int wport;
  unsigned int rwport;
  unsigned int serport; // single-ended bitline read ports 

  unsigned int obits;
  unsigned int abits;

  double dweight;
  double pweight;
  double aweight;
};

struct subarray_params_t
{
  unsigned int Ndwl;
  unsigned int Ndbl;
  unsigned int Nspd;
  unsigned int Ntwl;
  unsigned int Ntbl;
  unsigned int Ntspd;
  unsigned int muxover;
};


struct tech_params_t 
{
  double tech_size;
  double crossover;
  double standby;
  double vdd_periph_global;
  double scaling_factor;
};


typedef struct {
	double height;
	double width;
	double area;
	double scaled_area;
}area_type;

typedef struct {
        area_type dataarray_area,datapredecode_area;
        area_type datacolmuxpredecode_area,datacolmuxpostdecode_area;
		area_type datawritesig_area;
        area_type tagarray_area,tagpredecode_area;
        area_type tagcolmuxpredecode_area,tagcolmuxpostdecode_area;
        area_type tagoutdrvdecode_area;
        area_type tagoutdrvsig_area;
        double totalarea, subbankarea;
		double total_dataarea;
        double total_tagarea;
		double max_efficiency, efficiency;
		double max_aspect_ratio_total, aspect_ratio_total;
		double perc_data, perc_tag, perc_cont, sub_eff, total_eff;
}arearesult_type;

typedef struct {
   int cache_size;
   int number_of_sets;
   //int associativity;
   int tag_associativity, data_associativity;
   int block_size;
   int num_write_ports;
   int num_readwrite_ports;
   int num_read_ports;
   int num_single_ended_read_ports;
  char fully_assoc;
  double fudgefactor;
  double tech_size;
  double vdd_periph_global;
  int sequential_access;
  int fast_access;
  int force_tag;
  int tag_size;
  int nr_bits_out;
  int pure_sram;
  int number_banks;
  int obj_func_dynamic_energy;
  int obj_func_dynamic_power;
  int obj_func_leakage_power;
  int obj_func_cycle_time;
  int temp;
} parameter_type;

typedef struct {
	int subbanks;
   double access_time,cycle_time;
  double senseext_scale;
  powerDef total_power;
   int best_Ndwl,best_Ndbl, best_data_deg_bitline_muxing, best_Ndsam;
  double max_leakage_power, max_access_time, max_cycle_time, max_dynamic_power, max_dynamic_energy;
  double min_leakage_power, min_access_time, min_cycle_time, min_dynamic_power, min_dynamic_energy;
   double best_Nspd;
   int best_Ntwl,best_Ntbl, best_tag_deg_bitline_muxing, best_Ntsam;
   double best_Ntspd;
   int best_muxover;
   powerDef total_routing_power;
   powerDef total_power_without_routing, total_power_allbanks;
   double subbank_address_routing_delay;
   powerDef subbank_address_routing_power;
   double decoder_delay_data,decoder_delay_tag;
   powerDef decoder_power_data,decoder_power_tag;
   double dec_data_driver,dec_data_3to8,dec_data_inv;
   double dec_tag_driver,dec_tag_3to8,dec_tag_inv;
   double wordline_delay_data,wordline_delay_tag;
   powerDef wordline_power_data,wordline_power_tag;
   double bitline_delay_data,bitline_delay_tag;
   powerDef bitline_power_data,bitline_power_tag;
  double sense_amp_delay_data,sense_amp_delay_tag;
  powerDef sense_amp_power_data,sense_amp_power_tag;
  double total_out_driver_delay_data;
  powerDef total_out_driver_power_data;
   double compare_part_delay;
   double drive_mux_delay;
   double selb_delay;
   powerDef compare_part_power, drive_mux_power, selb_power;
   double data_output_delay;
   powerDef data_output_power;
   double drive_valid_delay;
   powerDef drive_valid_power;
   double precharge_delay;
  int data_nor_inputs;
  int tag_nor_inputs;
} result_type;

typedef struct{
	result_type result;
	arearesult_type area;
	parameter_type params;
}total_result_type;


typedef struct{
	double delay;
	powerDef power;
}output_tuples;

typedef struct{
	output_tuples
			decoder,
			wordline,
			bitline,
			senseamp;
	double senseamp_outputrisetime;
}cached_tag_entry;


//v5.0 results interface
typedef struct{
	int Ndwl;
	int Ndbl;
	double Nspd;
	int deg_bitline_muxing;
	int Ndsam;
	int number_activated_mats_horizontal_direction;
	double delay_route_to_bank;
	double delay_addr_din_horizontal_htree;
	double delay_addr_din_vertical_htree;
	double delay_row_predecode_driver_and_block;
	double delay_row_decoder;
	double delay_bitlines;
	double delay_sense_amp;
	double delay_subarray_output_driver;
	double delay_bit_mux_predecode_driver_and_block;
	double delay_bit_mux_decoder;
	double delay_senseamp_mux_predecode_driver_and_block;
	double delay_senseamp_mux_decoder;
	double delay_dout_vertical_htree;
	double delay_dout_horizontal_htree;
	double delay_comparator;
	double access_time;
	double cycle_time;
	double multisubbank_interleave_cycle_time;
	powerDef power_routing_to_bank;
	powerDef power_addr_horizontal_htree;
	powerDef power_datain_horizontal_htree;
	powerDef power_dataout_horizontal_htree;
	powerDef power_addr_vertical_htree;
	powerDef power_datain_vertical_htree;
	powerDef power_row_predecoder_drivers;
	powerDef power_row_predecoder_blocks;
	powerDef power_row_decoders;
	powerDef power_bit_mux_predecoder_drivers;
	powerDef power_bit_mux_predecoder_blocks;
	powerDef power_bit_mux_decoders;
	powerDef power_senseamp_mux_predecoder_drivers;
	powerDef power_senseamp_mux_predecoder_blocks;
	powerDef power_senseamp_mux_decoders;
	powerDef power_bitlines;
	powerDef power_sense_amps;
	powerDef power_output_drivers_at_subarray;
	powerDef power_dataout_vertical_htree;
	powerDef power_comparators;
	powerDef total_power;
	double area;
	double all_banks_height;
	double all_banks_width;
	double bank_height;
	double bank_width;
	double subarray_memory_cell_area_height;
	double subarray_memory_cell_area_width;
	double mat_height;
	double mat_width;
	double routing_area_height_within_bank;
	double routing_area_width_within_bank;
	double area_efficiency;
	double perc_power_dyn_routing_to_bank;
    double perc_power_dyn_addr_horizontal_htree;
	double perc_power_dyn_datain_horizontal_htree;
	double perc_power_dyn_dataout_horizontal_htree;
	double perc_power_dyn_addr_vertical_htree;
	double perc_power_dyn_datain_vertical_htree;
	double perc_power_dyn_row_predecoder_drivers;
	double perc_power_dyn_row_predecoder_blocks;
	double perc_power_dyn_row_decoders;
	double perc_power_dyn_bit_mux_predecoder_drivers;
	double perc_power_dyn_bit_mux_predecoder_blocks;
	double perc_power_dyn_bit_mux_decoders;
	double perc_power_dyn_senseamp_mux_predecoder_drivers;
	double perc_power_dyn_senseamp_mux_predecoder_blocks;
	double perc_power_dyn_senseamp_mux_decoders;
	double perc_power_dyn_bitlines;
	double perc_power_dyn_sense_amps;
	double perc_power_dyn_subarray_output_drivers;
	double perc_power_dyn_dataout_vertical_htree;
	double perc_power_dyn_comparators;
	double perc_power_leak_routing_to_bank;
	double perc_power_leak_addr_horizontal_htree;
	double perc_power_leak_datain_horizontal_htree;
	double perc_power_leak_dataout_horizontal_htree;
	double perc_power_leak_addr_vertical_htree;
	double perc_power_leak_datain_vertical_htree;
	double perc_power_leak_row_predecoder_drivers;
	double perc_power_leak_row_predecoder_blocks;
	double perc_power_leak_row_decoders;
	double perc_power_leak_bit_mux_predecoder_drivers;
	double perc_power_leak_bit_mux_predecoder_blocks;
	double perc_power_leak_bit_mux_decoders;
	double perc_power_leak_senseamp_mux_predecoder_drivers;
	double perc_power_leak_senseamp_mux_predecoder_blocks;
	double perc_power_leak_senseamp_mux_decoders;
	double perc_power_leak_bitlines;
	double perc_power_leak_sense_amps;
	double perc_power_leak_subarray_output_drivers;
	double perc_power_leak_dataout_vertical_htree;
	double perc_power_leak_comparators;
	double perc_leak_mats;
	double perc_active_mats;
	double refresh_power;
	double dram_refresh_period;
	double dram_array_availability;
}results_mem_array;


typedef struct{
	results_mem_array tag_array;
	results_mem_array data_array;
	double access_time;
	double cycle_time;
	double area;
	double area_efficiency;
	powerDef power;
	double leak_power_with_sleep_transistors_in_mats;
	parameter_type params;
    double cache_ht;
    double cache_len;
    char file_n[100];
}final_results;

typedef struct pda_res{
    powerComponents power;
    area_type area_stats;
    double delay;
    double cycle_time;
}pda_res_t;

final_results cacti_interface(
		int cache_size,
		int line_size,
		int associativity,
		int rw_ports,
		int excl_read_ports,
		int excl_write_ports,
		int single_ended_read_ports,
		int banks,
		double tech_node,
		int output_width,
		int specific_tag,
		int tag_width,
		int access_mode,
		int pure_sram,
		int dram,
		int obj_func_dynamic_energy,
		int obj_func_dynamic_power,
		int obj_func_leakage_power,
		int obj_func_cycle_time,
		int temp,
		int sram_cell_and_wordline_tech_flavor_in, 
		int periph_global_tech_flavor_in, 
		int interconnect_projection_type_in,
		int wire_inside_mat_type_in, 
		int wire_outside_mat_type_in, 
		int REPEATERS_IN_HTREE_SEGMENTS_in, 
		int VERTICAL_HTREE_WIRES_OVER_THE_ARRAY_in,
		int BROADCAST_ADDR_DATAIN_OVER_VERTICAL_HTREES_in, 
		double MAXAREACONSTRAINT_PERC_in, 
		double MAXACCTIMECONSTRAINT_PERC_in,
		double MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION_in);
