/*------------------------------------------------------------
 *                              CACTI 5.0
 *         Copyright 2007 Hewlett-Packard Development Corporation
 *                         All Rights Reserved
 *
 * Permission to use, copy, and modify this software and its documentation is
 * hereby granted only under the following terms and conditions.  Both the
 * above copyright notice and this permission notice must appear in all copies
 * of the software, derivative works or modified versions, and any portions
 * thereof, and both notices must appear in supporting documentation.
 *
 * Users of this software agree to the terms and conditions set forth herein, and
 * hereby grant back to Hewlett-Packard Company and its affiliated companies ("HP")
 * a non-exclusive, unrestricted, royalty-free right and license under any changes, 
 * enhancements or extensions  made to the core functions of the software, including 
 * but not limited to those affording compatibility with other hardware or software
 * environments, but excluding applications which incorporate this software.
 * Users further agree to use their best efforts to return to HP any such changes,
 * enhancements or extensions that they make and inform HP of noteworthy uses of
 * this software.  Correspondence should be provided to HP at:
 *
 *                       Director of Intellectual Property Licensing
 *                       Office of Strategy and Technology
 *                       Hewlett-Packard Company
 *                       1501 Page Mill Road
 *                       Palo Alto, California  94304
 *
 * This software may be distributed (but not offered for sale or transferred
 * for compensation) to third parties, provided such third parties agree to
 * abide by the terms and conditions of this notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND HP DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS.   IN NO EVENT SHALL HP 
 * CORPORATION BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 *------------------------------------------------------------*/
#include "io.h"

#define NEXTINT(a) skip(); scanf("%d",&(a));
#define NEXTFLOAT(a) skip(); scanf("%lf",&(a));
						
int CONTR_2_BANK_LAT = 8; /* in cycles */
/*---------------------------------------------------------------*/

/*
 * Ansi C "itoa" based on Kernighan & Ritchie's "Ansi C"
 */
void strreverse(char* begin, char* end) {
    char aux;
    while(end>begin)
        aux=*end, *end--=*begin, *begin++=aux;
}

#ifdef __linux__
void itoa(int value, char* str, int base) {
    static char num[] = "0123456789abcdefghijklmnopqrstuvwxyz";
    char* wstr=str;
    int sign;
    div_t res;

    // Validate base
    if (base<2 || base>35){ *wstr='\0'; return; }

    // Take care of sign
    if ((sign=value) < 0) value = -value;

    // Conversion. Number is reversed.
    do {
        res = div(value,base);
        *wstr++ = num[res.rem];
    }while(value=res.quot);
    if(sign<0) *wstr++='-';
    *wstr='\0';

    // Reverse string
    strreverse(str,wstr-1);
}
#endif

/* 
 * find the bank config with min lat or power 
 * for now the focus is on lat :TODO power
 */
bank_out_t *
find_optimal_config(bank_out_t **list, int size)
{
    bank_out_t *opt;
	int i = 0;
    opt = list[0];
    for (i=1; i<size; i++) {
        if (list[i]->nuca_pda.delay < opt->nuca_pda.delay) {
            opt = list[i];
        }
    }
    PRINTD(fprintf(stderr, "Optimal bank size is %d\n", opt->size));
    return opt;
}
    

void
dump_bank_out(bank_out_t *b)
{
    if (b)
    fprintf(stderr, "dump_bank_out:\n"
                    "\tSize = %d\n"
                    "\taccess time = %f\n"
                    "\tcycle time = %e\n"
                    "\tdyn_power = %e\n"
                    "\tleakage power = %f\n"
                    "\tbank area = %f\n",
                    b->size, b->bank_pda.delay, b->bank_pda.cycle_time, 
                    b->bank_pda.power.dynamic, b->bank_pda.power.leakage,
                    b->bank_pda.area_stats.area);
}

void
dump_input_args(input_args_t *b)
{
    if (b)
        fprintf(stderr, "dump_input_args:\n"
                        "\t cache_size - %d\n"
                        "\t line_size - %d\n"
                        "\t associativity - %d\n"
                        "\t rw_ports - %d\n"
                        "\t excl_read_ports - %d\n"
                        "\t excl_write_ports - %d\n"
                        "\t single_ended_read_ports - %d\n"
                        "\t banks - %d\n"
                        "\t tech_node - %f\n"
                        "\t output_width - %d\n"
                        "\t specific_tag - %d\n"
                        "\t tag_width - %d\n"
                        "\t access_mode - %d\n"
                        "\t pure_sram - %d\n"
                        "\t dram - %d\n"
                        "\t obj_func_dynamic_energy - %d\n"
                        "\t obj_func_dynamic_power - %d\n"
                        "\t obj_func_leakage_power - %d\n"
                        "\t obj_func_cycle_time - %d\n"
                        "\t temp - %d\n",
                        b->cache_size, b->line_size, b->associativity,
                        b->rw_ports, b->excl_read_ports, b->excl_write_ports,
                        b->single_ended_read_ports, b->banks,
                        b->tech_node, b->output_width, b->specific_tag,
                        b->tag_width, b->access_mode, b->pure_sram,
                        b->dram, b->obj_func_dynamic_energy, b->obj_func_dynamic_power,
                        b->obj_func_leakage_power, b->obj_func_cycle_time, 
                        b->temp);

}


int input_data(int argc,char *argv[])
{
   int C,B,A,ERP,EWP,RWP,NSER, NSubbanks, fully_assoc;
   double tech;
   double logbanks, assoc;
   double logbanksfloor, assocfloor;
   int bits_output = 64;

   /*if ((argc!=6) && (argc!=9)) {
      printf("Cmd-line parameters: C B A TECH NSubbanks\n");
      printf("                 OR: C B A TECH RWP ERP EWP NSubbanks\n");
      exit(0);
   }*/

   if ((argc!=6) && (argc!=9)&& (argc!=32)) {
      printf("Cmd-line parameters: C B A TECH NSubbanks\n");
      printf("                 OR: C B A TECH RWP ERP EWP NSubbanks\n");
      exit(1);
   }

   B = atoi(argv[2]);
   if ((B < 1)) {
       printf("Block size must >=1\n");
       exit(1);
   }

    if (argc==9)
     {
		if ((B*8 < bits_output)) {
			printf("Block size must be at least %d\n", bits_output/8);
			exit(1);
		}
 
		tech = atof(argv[4]);
		if ((tech <= 0)) {
			printf("Feature size must be > 0\n");
			exit(1);
		 }
		if ((tech > 0.8)) {
			printf("Feature size must be <= 0.80 (um)\n");
			 exit(1);
		 }

       RWP = atoi(argv[5]);
       ERP = atoi(argv[6]);
       EWP = atoi(argv[7]);
       NSER = 0;

       if ((RWP < 0) || (EWP < 0) || (ERP < 0)) {
		 printf("Ports must >=0\n");
		 exit(1);
       }
       if (RWP > 2) {
		 printf("Maximum of 2 read/write ports\n");
		 exit(1);
       }
       if ((RWP+ERP+EWP) < 1) {
       	 printf("Must have at least one port\n");
       	 exit(1);
       }

       NSubbanks = atoi(argv[8]);

       if (NSubbanks < 1 ) {
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         exit(1);
       }

       logbanks = logtwo((double)(NSubbanks));
       logbanksfloor = floor(logbanks);
      
       if(logbanks > logbanksfloor){
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         exit(1);
       }

     }
   
   else if(argc==6)
     {

		if ((B*8 < bits_output)) {
			printf("Block size must be at least %d\n", bits_output/8);
			exit(1);
		}
 
		tech = atof(argv[4]);
		if ((tech <= 0)) {
			printf("Feature size must be > 0\n");
			exit(1);
		 }

		if ((tech > 0.8)) {
			printf("Feature size must be <= 0.80 (um)\n");
			exit(1);
		 }

       RWP=1;
       ERP=0;
       EWP=0;
       NSER=0;

       NSubbanks = atoi(argv[5]);
       if (NSubbanks < 1 ) {
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         exit(1); 
       }
       logbanks = logtwo((double)(NSubbanks));
       logbanksfloor = floor(logbanks);

       if(logbanks > logbanksfloor){
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         exit(1);
       }

     }
	 else 
     {
       tech = atof(argv[9]) / 1000;//Convert from nm to micron
	   NSubbanks = atoi(argv[8]);
	   if ((tech <= 0)) {
			printf("Feature size must be > 0\n");
			exit(1);
		 }

	   if ((tech > 0.8)) {
			printf("Feature size must be <= 0.80 (um)\n");
			exit(1);
		}
     }

   C = atoi(argv[1])/((int) (NSubbanks));
   if (atoi(argv[1]) < 64) {
       printf("Cache size must be greater than 32!\n");
       exit(1);
   }
 
   if ((strcmp(argv[3],"FA") == 0) || (argv[3][0] == '0'))
     {
       A=C/B;
       fully_assoc = 1;
     }
   else
     {
       if (strcmp(argv[3],"DM") == 0)
         {
           A=1;
           fully_assoc = 0;
         }
       else
         {
           fully_assoc = 0;
           A = atoi(argv[3]);
		   //if ((A < 0)||(A > 16)) {
             //printf("Associativity must be  1,2,4,8,16 or 0(fully associative)\n");
             //exit(1);
           //}
           assoc = logtwo((double)(A));
           assocfloor = floor(assoc);

           if(assoc > assocfloor){
             printf("Associativity should be a power of 2\n");
             exit(1);
           }

           }
     }

   if (!fully_assoc && C/(B*A) < 1) {
     printf("Number of sets is less than 1:\n  Need to either increase cache size, or decrease associativity or block size\n  (or use fully associative cache)\n");
       exit(1);
   }
 
   return(OK);
}

void
output_all (final_results *fr)
{
    
    fprintf(stderr,"\nCache Parameters:\n");
    fprintf(stderr,"    Total Cache Size: %d\n",
            (int) (fr->params.cache_size));
    fprintf(stderr,"    Number of banks: %d\n",
            (int)fr->params.number_banks);
    fprintf(stderr,"    Size in bytes of a bank: %d\n",
            fr->params.cache_size /(int)fr->params.number_banks);
    fprintf(stderr,"    Number of sets per bank:%d\n",
            fr->params.number_of_sets);
    if (fr->params.fully_assoc)
        fprintf(stderr,"    Associativity: fully associative\n");
    else {
        if (fr->params.tag_associativity==1)
            fprintf(stderr,"    Associativity: direct mapped\n");
        else
            fprintf(stderr,"    Associativity: %d\n",
                    fr->params.tag_associativity);
    }
    fprintf(stderr,"    Block Size (bytes): %d\n",fr->params.block_size);
    fprintf(stderr,"    Read/Write Ports: %d\n",
            fr->params.num_readwrite_ports);
    fprintf(stderr,"    Read Ports: %d\n",
            fr->params.num_read_ports);
    fprintf(stderr,"    Write Ports: %d\n",
            fr->params.num_write_ports);
    fprintf(stderr,"    Technology Size: %2.2fum\n", 
            fr->params.tech_size);
    fprintf(stderr,"    Vdd: %2.1fV\n", fr->params.vdd_periph_global);

    fprintf(stderr,"\n    Access Time (ns): %g\n",fr->access_time*1e9);
    fprintf(stderr,"    Cycle Time (ns):  %g\n",fr->cycle_time*1e9);
    fprintf(stderr,"    Total dynamic Read Power at max. freq. (W):%g\n",
            fr->power.readOp.dynamic/fr->cycle_time);
    fprintf(stderr,"    Total leakage Read/Write Power all Banks"
            " (mW):%g\n", fr->power.readOp.leakage*1e3);
    fprintf(stderr,"    Total dynamic Read Energy all Banks (nJ):%g\n",
            fr->power.readOp.dynamic*1e9);
    fprintf(stderr, "    Refresh power (mW): %g\n", 
            fr->data_array.refresh_power*1e3); 
    fprintf(stderr, "    Area of the cache height x width (mm):"
            " %f x %f\n", fr->cache_ht*1e-3, fr->cache_len*1e-3);

    fprintf(stderr,"\n    Best Ndwl (L1): %d\n",fr->data_array.Ndwl);
    fprintf(stderr,"    Best Ndbl (L1): %d\n",fr->data_array.Ndbl);
    fprintf(stderr,"    Best Nspd (L1): %f\n",fr->data_array.Nspd);
    fprintf(stderr,"    Best Ntwl (L1): %d\n",fr->tag_array.Ndwl);
    fprintf(stderr,"    Best Ntbl (L1): %d\n",fr->tag_array.Ndbl);
    fprintf(stderr,"    Best Ntspd (L1): %f\n",fr->tag_array.Nspd);

    /* Delay stats */
    /* data array stats */ 
    fprintf(stderr,"\nTime Components:\n");
    fprintf(stderr,"  Data side (with Output driver) (ns): %g\n",
            fr->data_array.access_time/1e-9);
    fprintf(stderr, "    delay_route_to_bank (ns): %g\n", 
            fr->data_array.delay_route_to_bank * 1e9);
    fprintf(stderr, "    addr_datain_horizontal_htree (ns): %g\n",
            fr->data_array.delay_addr_din_horizontal_htree * 1e9);
    fprintf(stderr, "    addr_datain_vertical_htree (ns): %g\n",
            fr->data_array.delay_addr_din_vertical_htree * 1e9);
    fprintf(stderr, "    row_predecode_driver_and_block (ns): %g\n",
            fr->data_array.delay_row_predecode_driver_and_block * 1e9);
    fprintf(stderr, "    row_decoder (ns): %g\n",
            fr->data_array.delay_row_decoder * 1e9);
    fprintf(stderr, "    bitline data (ns):  %g\n",
            fr->data_array.delay_bitlines/1e-9);
    fprintf(stderr, "    sense_amp (ns): %g\n",
            fr->data_array.delay_sense_amp * 1e9);
    fprintf(stderr, "    subarray_output_driver (ns): %g\n",
            fr->data_array.delay_subarray_output_driver * 1e9);
    fprintf(stderr, "    bit_mux_predecode_driver_and_block (ns): %g\n",
            fr->data_array.delay_senseamp_mux_predecode_driver_and_block * 1e9);
    fprintf(stderr, "    senseamp_mux_decoder (ns): %g\n", 
            fr->data_array.delay_senseamp_mux_decoder * 1e9);
    fprintf(stderr, "    dataout_htree (ns): %g\n",
            fr->data_array.delay_dout_vertical_htree * 1e9);
    fprintf(stderr, "    dataout_horizontal_htree (ns): %g\n",
            fr->data_array.delay_dout_horizontal_htree * 1e9);
    fprintf(stderr,"    address routing delay (ns): %g\n",
            fr->data_array.delay_route_to_bank/1e-9);
    fprintf(stderr,"    decode_data (ns): %g\n",
            fr->data_array.delay_row_predecode_driver_and_block/1e-9);

    /* tag array stats */
    fprintf(stderr,"\n  Tag side (with Output driver) (ns): %g\n",
            fr->tag_array.access_time/1e-9);
    fprintf(stderr, "    delay_route_to_bank (ns): %g\n", 
            fr->tag_array.delay_route_to_bank * 1e9);
    fprintf(stderr, "    addr_datain_horizontal_htree (ns): %g\n",
            fr->tag_array.delay_addr_din_horizontal_htree * 1e9);
    fprintf(stderr, "    addr_datain_vertical_htree (ns): %g\n",
            fr->tag_array.delay_addr_din_vertical_htree * 1e9);
    fprintf(stderr, "    row_predecode_driver_and_block (ns): %g\n",
            fr->tag_array.delay_row_predecode_driver_and_block * 1e9);
    fprintf(stderr, "    row_decoder (ns): %g\n",
            fr->tag_array.delay_row_decoder * 1e9);
    fprintf(stderr, "    bitline data (ns):  %g\n",
            fr->tag_array.delay_bitlines/1e-9);
    fprintf(stderr, "    sense_amp (ns): %g\n",
            fr->tag_array.delay_sense_amp * 1e9);
    fprintf(stderr, "    subarray_output_driver (ns): %g\n",
            fr->tag_array.delay_subarray_output_driver * 1e9);
    fprintf(stderr, "    bit_mux_predecode_driver_and_block (ns): %g\n",
            fr->tag_array.delay_senseamp_mux_predecode_driver_and_block * 1e9);
    fprintf(stderr, "    senseamp_mux_decoder (ns): %g\n", 
            fr->tag_array.delay_senseamp_mux_decoder * 1e9);
    fprintf(stderr, "    dataout_htree (ns): %g\n",
            fr->tag_array.delay_dout_vertical_htree * 1e9);
    fprintf(stderr, "    dataout_horizontal_htree (ns): %g\n",
            fr->tag_array.delay_dout_horizontal_htree * 1e9);
    fprintf(stderr,"    address routing delay (ns): %g\n",
            fr->tag_array.delay_route_to_bank/1e-9);
    fprintf(stderr,"    decode_data (ns): %g\n",
            fr->tag_array.delay_row_predecode_driver_and_block/1e-9);

    /* Energy/Power stats */
    fprintf(stderr,"\nPower Components:\n");
    fprintf(stderr,"  Data array: Total dynamic read energy/access  (nJ): %g\n",
            fr->power.readOp.dynamic * 1e9);
    fprintf(stderr,"    Total leakage read/write power all banks at "
            "maximum frequency (mW): %g\n",
            fr->power.readOp.leakage * 1e3);
    fprintf(stderr, "    address horizontal htree (nJ): %g\n",
        (fr->data_array.power_addr_horizontal_htree.readOp.dynamic) * 1e9);
    fprintf(stderr, "    datain_horizontal_htree (nJ): %g\n",
        fr->data_array.power_datain_horizontal_htree.readOp.dynamic * 1e9);
    fprintf(stderr, "    addr_vertical_htree (nJ): %g\n",
        fr->data_array.power_addr_vertical_htree.readOp.dynamic * 1e9);
    fprintf(stderr, "    row_predecoder_drivers (nJ): %g\n",
        fr->data_array.power_row_predecoder_drivers.readOp.dynamic * 1e9);
    fprintf(stderr, "    row_predecoder_blocks (nJ): %g\n",
        fr->data_array.power_row_predecoder_blocks.readOp.dynamic * 1e9);
    fprintf(stderr, "    row_decoders (nJ): %g\n",
        fr->data_array.power_row_decoders.readOp.dynamic * 1e9);
    fprintf(stderr, "    bit_mux_predecoder_drivers: %g\n",
        fr->data_array.power_bit_mux_predecoder_drivers.readOp.dynamic * 1e9);
    fprintf(stderr, "    bit_mux_predecoder_blocks: %g\n",
        fr->data_array.power_bit_mux_predecoder_blocks.readOp.dynamic * 1e9);
    fprintf(stderr, "    bit_mux_decoders: %g\n",
        fr->data_array.power_bit_mux_decoders.readOp.dynamic * 1e9);
    fprintf(stderr, "    senseamp_mux_predecoder_drivers: %g\n",
        fr->data_array.power_senseamp_mux_predecoder_drivers.readOp.dynamic * 1e9);
    fprintf(stderr, "    senseamp_mux_predecoder_blocks: %g\n",
        fr->data_array.power_senseamp_mux_predecoder_blocks.readOp.dynamic * 1e9);
    fprintf(stderr, "    senseamp_mux_decoders: %g\n",
        fr->data_array.power_senseamp_mux_decoders.readOp.dynamic * 1e9);
    fprintf(stderr, "    bitlines: %g\n", 
            fr->data_array.power_bitlines.readOp.dynamic * 1e9);
    fprintf(stderr, "    sense_amps: %g\n", 
            fr->data_array.power_sense_amps.readOp.dynamic * 1e9);
    fprintf(stderr, "    subarray_output_drivers: %g\n",
            fr->data_array.power_output_drivers_at_subarray.readOp.dynamic * 1e9);
    fprintf(stderr, "    dataout_vertical_htree: %g\n",
            fr->data_array.power_dataout_vertical_htree.readOp.dynamic * 1e9);
//    fprintf(stderr, "    dataout_horizontal_htree (for writes): %g\n",
//            fr->data_array.power_dataout_horizontal_intcnt_within_bank * 1e9);
    fprintf(stderr,"\n  Tag array: Total dynamic read energy/access  (nJ): %g\n",
            fr->power.readOp.dynamic * 1e9);
    fprintf(stderr,"    Total leakage read/write power all banks at "
            "maximum frequency (mW): %g\n",
            fr->power.readOp.leakage * 1e3);
    fprintf(stderr, "    address horizontal htree (nJ): %g\n",
        fr->tag_array.power_addr_horizontal_htree.readOp.dynamic * 1e9);
    fprintf(stderr, "    datain_horizontal_htree (nJ): %g\n",
        fr->tag_array.power_datain_horizontal_htree.readOp.dynamic * 1e9);
    fprintf(stderr, "    addr_datain_vertical_htree (nJ): %g\n",
        fr->tag_array.power_addr_vertical_htree.readOp.dynamic * 1e9);
    fprintf(stderr, "    row_predecoder_drivers (nJ): %g\n",
        fr->tag_array.power_row_predecoder_drivers.readOp.dynamic * 1e9);
    fprintf(stderr, "    row_predecoder_blocks (nJ): %g\n",
        fr->tag_array.power_row_predecoder_blocks.readOp.dynamic * 1e9);
    fprintf(stderr, "    row_decoders (nJ): %g\n",
        fr->tag_array.power_row_decoders.readOp.dynamic * 1e9);
    fprintf(stderr, "    bit_mux_predecoder_drivers: %g\n",
        fr->tag_array.power_bit_mux_predecoder_drivers.readOp.dynamic * 1e9);
    fprintf(stderr, "    bit_mux_predecoder_blocks: %g\n",
        fr->tag_array.power_bit_mux_predecoder_blocks.readOp.dynamic * 1e9);
    fprintf(stderr, "    bit_mux_decoders: %g\n",
        fr->tag_array.power_bit_mux_decoders.readOp.dynamic * 1e9);
    fprintf(stderr, "    senseamp_mux_predecoder_drivers: %g\n",
        fr->tag_array.power_senseamp_mux_predecoder_drivers.readOp.dynamic * 1e9);
    fprintf(stderr, "    senseamp_mux_predecoder_blocks: %g\n",
        fr->tag_array.power_senseamp_mux_predecoder_blocks.readOp.dynamic * 1e9);
    fprintf(stderr, "    senseamp_mux_decoders: %g\n",
        fr->tag_array.power_senseamp_mux_decoders.readOp.dynamic * 1e9);
    fprintf(stderr, "    bitlines: %g\n", 
            fr->tag_array.power_bitlines.readOp.dynamic * 1e9);
    fprintf(stderr, "    sense_amps: %g\n", 
            fr->tag_array.power_sense_amps.readOp.dynamic * 1e9);
    fprintf(stderr, "    subarray_output_drivers: %g\n",
            fr->tag_array.power_output_drivers_at_subarray.readOp.dynamic * 1e9);
    fprintf(stderr, "    dataout_vertical_htree: %g\n",
            fr->tag_array.power_dataout_vertical_htree.readOp.dynamic * 1e9);
    /* Area stats */
    fprintf(stderr, "\nArea Components:\n");
    /* Data array area stats */
    fprintf(stderr, "  Data array: Area (mm2): %g\n", fr->data_array.area);
    fprintf(stderr, "    Data_array_height: %g\n",
            fr->data_array.all_banks_height);
    fprintf(stderr, "    Data_array_width: %g\n",
            fr->data_array.all_banks_width);
    fprintf(stderr, "    Mat height: %g\n",
            fr->data_array.mat_height);
    fprintf(stderr, "    Mat width: %g\n",
            fr->data_array.mat_width);
    fprintf(stderr, "    Subarray height: %g\n",
            fr->data_array.subarray_memory_cell_area_height);
    fprintf(stderr, "    Subarray width: %g\n",
            fr->data_array.subarray_memory_cell_area_width);
    /* Tag array area stats */
    fprintf(stderr, "\n  Tag array: Area (mm2): %g\n", fr->tag_array.area);
    fprintf(stderr, "    Tag_array_height: %g\n",
            fr->tag_array.all_banks_height);
    fprintf(stderr, "    Tag_array_width: %g\n",
            fr->tag_array.all_banks_width);
    fprintf(stderr, "    Mat height: %g\n",
            fr->tag_array.mat_height);
    fprintf(stderr, "    Mat width: %g\n",
            fr->tag_array.mat_width);
    fprintf(stderr, "    Subarray height: %g\n",
            fr->tag_array.subarray_memory_cell_area_height);
    fprintf(stderr, "    Subarray width: %g\n",
            fr->tag_array.subarray_memory_cell_area_width);

}


int
get_cpucount()
{
    #define CPUINFO    "/proc/cpuinfo"

    int r, proc = 0;
#ifdef __linux__
    char line[5000];
    FILE *fp = fopen(CPUINFO, "r");

    if (fp == NULL) {
        fprintf(stderr, "Unable to open %s\n", CPUINFO);
        /* have atleast 2 threads */
        return 2;
    }

    while(fscanf(fp, "%[^\n]\n", line) != EOF) {
        if (!strncmp("processor", line, strlen("processor")))
            if (sscanf(line, "processor : %d", &r))
                proc++;
    }
    fclose(fp);

    if (!proc)
        return 2;
    return proc;
#endif
/* have atleast 2 threads */
    proc = 2;
    return proc;
}

final_results cacti_interface(
		int cache_size,
		int line_size,
		int associativity,
		int rw_ports,
		int excl_read_ports,
		int excl_write_ports,
		int single_ended_read_ports,
		int banks,
		double tech_node,
		int output_width,
		int specific_tag,
		int tag_width,
		int access_mode,
		int pure_sram,
		int dram,
		int obj_func_dynamic_energy,
		int obj_func_dynamic_power,
		int obj_func_leakage_power,
		int obj_func_cycle_time,
		int temp,
		int sram_cell_and_wordline_tech_flavor_in, 
		int periph_global_tech_flavor_in, 
		int interconnect_projection_type_in,
		int wire_inside_mat_type_in, 
		int wire_outside_mat_type_in, 
		int REPEATERS_IN_HTREE_SEGMENTS_in, 
		int VERTICAL_HTREE_WIRES_OVER_THE_ARRAY_in,
		int BROADCAST_ADDR_DATAIN_OVER_VERTICAL_HTREES_in, 
		double MAXAREACONSTRAINT_PERC_in, 
		double MAXACCTIMECONSTRAINT_PERC_in,
		double MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION_in)
{
	input_args_t input_params;
    final_results fr/*final result var*/;
    bank_out_t *uca;
	fr.access_time = 99999;
	
	sram_cell_and_wordline_tech_flavor = sram_cell_and_wordline_tech_flavor_in;
	periph_global_tech_flavor = periph_global_tech_flavor_in;
    interconnect_projection_type = interconnect_projection_type_in;
	wire_inside_mat_type = wire_inside_mat_type_in;
	wire_outside_mat_type = wire_outside_mat_type_in;
	REPEATERS_IN_HTREE_SEGMENTS = REPEATERS_IN_HTREE_SEGMENTS_in;
	VERTICAL_HTREE_WIRES_OVER_THE_ARRAY = VERTICAL_HTREE_WIRES_OVER_THE_ARRAY_in;
	BROADCAST_ADDR_DATAIN_OVER_VERTICAL_HTREES = BROADCAST_ADDR_DATAIN_OVER_VERTICAL_HTREES_in;
	MAXAREACONSTRAINT_PERC = MAXAREACONSTRAINT_PERC_in;
    MAXACCTIMECONSTRAINT_PERC = MAXACCTIMECONSTRAINT_PERC_in;
	MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION = MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION_in;

    input_params.cache_size = cache_size;
    input_params.line_size = line_size;
    input_params.associativity = associativity;
    input_params.rw_ports = rw_ports;
    input_params.excl_read_ports = excl_read_ports;
    input_params.excl_write_ports = excl_write_ports;
    input_params.single_ended_read_ports = single_ended_read_ports;
    input_params.banks = banks;
    input_params.tech_node = tech_node;
    input_params.output_width = output_width;
    input_params.specific_tag = specific_tag;
    input_params.tag_width = tag_width;
    input_params.access_mode = access_mode;
    input_params.pure_sram = pure_sram;
    input_params.dram = dram;
    input_params.obj_func_dynamic_energy = obj_func_dynamic_energy;
    input_params.obj_func_dynamic_power = obj_func_dynamic_power;
    input_params.obj_func_leakage_power = obj_func_leakage_power;
    input_params.obj_func_cycle_time = obj_func_cycle_time;
    input_params.temp = temp;
    input_params.nuca_bank_count = 1;
	
	uca = (bank_out_t *) malloc(sizeof(bank_out_t));
	uca->input_params = input_params;
	fr = sim_cache(uca);
	free(uca);
    return fr;
}


final_results sim_cache(bank_out_t *out)
{
    int cache_size = out->input_params.cache_size;
    int line_size = out->input_params.line_size;
    int associativity = out->input_params.associativity;
    int rw_ports = out->input_params.rw_ports;
    int excl_read_ports = out->input_params.excl_read_ports;
    int excl_write_ports = out->input_params.excl_write_ports;
    int single_ended_read_ports = out->input_params.single_ended_read_ports;
    int banks = out->input_params.banks;
    double tech_node = out->input_params.tech_node;
    int output_width = out->input_params.output_width;
    int specific_tag = out->input_params.specific_tag;
    int tag_width = out->input_params.tag_width;
    int access_mode = out->input_params.access_mode;
    int pure_sram = out->input_params.pure_sram;
    int dram = out->input_params.dram;
    int obj_func_dynamic_energy = out->input_params.obj_func_dynamic_energy;
    int obj_func_dynamic_power = out->input_params.obj_func_dynamic_power;
    int obj_func_leakage_power = out->input_params.obj_func_leakage_power;
    int obj_func_cycle_time = out->input_params.obj_func_cycle_time;
    int temp = out->input_params.temp;
    int nuca_bank_count = out->input_params.nuca_bank_count;
    int C,B,A,ERP,EWP,RWP,NSER;
    double tech;
    double logbanks, assoc;
    double logbanksfloor, assocfloor;
    int seq_access = 0;
    int fast_access = 0;
    int bits_output = output_width;
    int nr_args = 9;
    double NSubbanks = (double)banks;
     

   total_result_type endresult;

   result_type result;
   arearesult_type arearesult;
   area_type arearesult_subbanked;
   parameter_type parameters; 

   final_results ret_result;
   //dump_input_args(&(out->input_params));
  
   /* input parameters:
         C B A ERP EWP */


   parameters.force_tag = 0;

   if(specific_tag) {
	   parameters.force_tag = 1;
	   parameters.tag_size = tag_width;
   }
   switch (access_mode){
	   case 0:
		   seq_access = fast_access = FALSE;
		   break;
	   case 1:
		   seq_access = TRUE;
		   fast_access = FALSE;
		   break;
	   case 2:
		   seq_access = FALSE;
		   fast_access = TRUE;
		   break;
   }

   B = line_size;
   if ((B < 1)) {
       printf("Block size must >=1\n");
       return ret_result;
	   //exit(1);
   }

   if ((B*8 < bits_output)) {
       printf("Block size must be at least %d\n", bits_output/8);
       return ret_result;
	   //exit(1);
   }
   

   tech = tech_node / 1000;//convert from nm to micron
   if ((tech <= 0)) {
       printf("Feature size must be > 0\n");
       return ret_result;
	   //exit(1);
   }
   if ((tech > 0.8)) {
       printf("Feature size must be <= 0.80 (um)\n");
       return ret_result;
	   //exit(1);
   }

   if (nr_args ==9)
     {
       RWP = rw_ports;
       ERP = excl_read_ports;
       EWP = excl_write_ports;
       NSER = single_ended_read_ports;

   //If multiple banks and multiple ports are specified, then if number of ports is less than or equal to
   //the number of banks, we assume that the multiple ports are implemented via the multiple banks.
   //In such a case we assume that each bank has 1 RWP port. 
   if((RWP + ERP + EWP) <= NSubbanks){
	   parameters.num_readwrite_ports = 1;
       parameters.num_read_ports = 0;
       parameters.num_write_ports = 0;
       parameters.num_single_ended_read_ports = 0;
	   RWP = parameters.num_readwrite_ports;
	   ERP = parameters.num_read_ports;
	   EWP =  parameters.num_write_ports;
	   NSER = parameters.num_single_ended_read_ports;
	}


       if ((RWP < 0) || (EWP < 0) || (ERP < 0)) {
			printf("Ports must >=0\n");
			return ret_result;
			//exit(1);
       }
       if (RWP > 2) {
			printf("Maximum of 2 read/write ports\n");
			return ret_result;
			//exit(1);
       }
       if ((RWP+ERP+EWP) < 1) {
       	 printf("Must have at least one port\n");
       	 return ret_result;
		 //exit(1);
       }

       if (NSubbanks < 1 ) {
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         return ret_result;
		 //exit(1);
       }

       logbanks = logtwo((double)(NSubbanks));
       logbanksfloor = floor(logbanks);
      
       if(logbanks > logbanksfloor){
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         return ret_result;
		 //exit(1);
       }

     }
   else if (nr_args==10)
     {
       RWP = rw_ports;
       ERP = excl_read_ports;
       EWP = excl_write_ports;
       NSER = single_ended_read_ports;

	   seq_access = 1;

       if ((RWP < 0) || (EWP < 0) || (ERP < 0)) {
			printf("Ports must >=0\n");
			return ret_result;
			//exit(1);
       }
       if (RWP > 2) {
			printf("Maximum of 2 read/write ports\n");
			return ret_result;
			//exit(1);
       }
       if ((RWP+ERP+EWP) < 1) {
       	 printf("Must have at least one port\n");
       	 return ret_result;
		 //exit(1);
       }
       

       if (NSubbanks < 1 ) {
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         return ret_result;
		 //exit(1);
       }

       logbanks = logtwo((double)(NSubbanks));
       logbanksfloor = floor(logbanks);
      
       if(logbanks > logbanksfloor){
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         return ret_result;
		 //exit(1);
       }

     }
   else if(nr_args==6)
     {
       RWP=1;
       ERP=0;
       EWP=0;
       NSER=0;

       if (NSubbanks < 1 ) {
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         return ret_result; 
		 //exit(1);
       }
       logbanks = logtwo((double)(NSubbanks));
       logbanksfloor = floor(logbanks);

       if(logbanks > logbanksfloor){
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         return ret_result;
		 //exit(1);
       }

     }
	 else if(nr_args==8)
     {
       RWP=1;
       ERP=0;
       EWP=0;
       NSER=0;

	   bits_output = output_width;
	   seq_access = 1;

       NSubbanks = banks;
       if (NSubbanks < 1 ) {
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         return ret_result;
		 //exit(1);
       }
       logbanks = logtwo((double)(NSubbanks));
       logbanksfloor = floor(logbanks);

       if(logbanks > logbanksfloor){
         printf("Number of subbanks should be greater than or equal to 1 and should be a power of 2\n");
         return ret_result;
		 //exit(1);
       }

     }
 
   C = cache_size/((int) (NSubbanks));
   if ((C < 64)) {
       printf("Cache size must >=64\n");
       return ret_result;
	   //exit(1);
   }
 
   if (associativity == 0)
     {
       A=C/B;
       parameters.fully_assoc = 1;
     }
   else
     {
       if (associativity == 1)
         {
           A=1;
           parameters.fully_assoc = 0;
         }
       else
         {
           parameters.fully_assoc = 0;
           A = associativity;
           if ((A < 1)) {
             printf("Associativity must >= 1\n");
             return ret_result;
			 //exit(1);
           }
           assoc = logtwo((double)(A));
           assocfloor = floor(assoc);

           if(assoc > assocfloor){
             printf("Associativity should be a power of 2\n");
             return ret_result;
			 //exit(1);
           }

           //if ((A > 32)) {
             //printf("Associativity must <= 32\n or try FA (fully associative)\n");
             //return ret_result;
			 //exit(1);
           //}
         }
     }

   if (C/(B*A)<=1 && !parameters.fully_assoc) {
     printf("Number of sets is too small:\n  Need to either increase cache size, or decrease associativity or block size\n  (or use fully associative cache)\n");
     return ret_result;
	//exit(1); 
   }
 
   parameters.cache_size = cache_size;
   parameters.block_size = B;
   parameters.number_banks = banks;
   parameters.nr_bits_out = bits_output;
   parameters.obj_func_dynamic_energy = obj_func_dynamic_energy;
   parameters.obj_func_dynamic_power = obj_func_dynamic_power;
   parameters.obj_func_leakage_power = obj_func_leakage_power;
   parameters.obj_func_cycle_time = obj_func_cycle_time;
  
   /*dt: testing sequential access mode*/
   if(seq_access) {
	parameters.tag_associativity = A;
	parameters.data_associativity = 1;
	parameters.sequential_access = 1;
   }
   else {
	parameters.tag_associativity = parameters.data_associativity = A;
	parameters.sequential_access = 0;
   }
   if(fast_access) {
	   parameters.fast_access = 1;
   }
   else {
	   parameters.fast_access = 0;
   }
   if(parameters.fully_assoc){
	   parameters.data_associativity = 1;
   }
   parameters.num_readwrite_ports = RWP;
   parameters.num_read_ports = ERP;
   parameters.num_write_ports = EWP;
   parameters.num_single_ended_read_ports =NSER;
   parameters.number_of_sets = C/(B*A);
   parameters.fudgefactor = .8/tech;   
   parameters.tech_size=(double) tech;
   parameters.pure_sram = pure_sram;
   parameters.temp = temp;
   temper = temp;


   if (parameters.number_of_sets < 1) {
      printf("Less than one set...\n");
      return ret_result;
	  //exit(1);
   }   

   if(dram){
	   is_dram = 1;
   }
   else{
	   is_dram = 0;
   }
   input_tech = tech_node;
 
   init_tech_params(parameters.tech_size);

   do_it(&result,&arearesult,&arearesult_subbanked,&parameters,&NSubbanks, &ret_result);

   
   endresult.result = result;
   endresult.result.subbanks = banks;
   endresult.area = arearesult;
   endresult.params = parameters;

   ret_result.params = parameters;
   
   return ret_result;
}

/* insert a mat to .fig file at the specified coordinate*/
void
insert_mat (int x, int y, int l, int w, FILE *file)
{
    char temp1[10], temp2[10];
    int xt = x;
    int yt = y;
    int i=0;
    fprintf (file, "%s", "\t");
    while (i != 4) {
        itoa (x, temp1, 10);
        itoa (y, temp2, 10);
        fprintf (file, "%s ", temp1);
        fprintf (file, "%s ", temp2);
        if (i < 2) {
            if (i%2) y = y + w;
            else x = x + l;
        }
        else {
            if (i%2) y = y - w;
            else x = x - l;
        }
        i++;
    }
    /* finish the loop */
    itoa (xt, temp1, 10);
    itoa (yt, temp2, 10);
    fprintf (file, "%s ", temp1);
    fprintf (file, "%s\n", temp2);
}

/* insert a line from the given co-ordinates */
void
insert_line (int x1, int y1, int x2, int y2, FILE *file)
{
    char temp1[10], temp2[10], temp3[10], temp4[10];
    fprintf (file, "%s ", "\t");
    itoa (x1, temp1, 10);
    itoa (y1, temp2, 10);
    itoa (x2, temp3, 10);
    itoa (y2, temp4, 10);
    fprintf (file, "%s %s %s %s\n", temp1, temp2, temp3, temp4);
}
/* Show the organization of a sample mat */
void
print_mat (FILE *fp)
{
    fprintf (fp, "%s\n", "2 2 0 1 0 17 50 -1 20 0.000 0 0 -1 0 0 5");
    fprintf (fp, "\t%s\n", "7725 1875 8250 1875 8250 2400 7725 2400 7725 1875");
    fprintf (fp, "%s\n", "2 2 0 1 0 7 50 -1 -1 0.000 0 0 -1 0 0 5");
    fprintf (fp, "\t%s\n", "6525 825 8475 825 8475 2625 6525 2625 6525 825");
    fprintf (fp, "%s\n", "2 1 0 1 0 7 50 -1 -1 0.000 0 0 -1 0 0 2");
    fprintf (fp, "\t%s\n", "7575 1725 9000 1725");
    fprintf (fp, "%s\n", "2 4 0 1 0 7 50 -1 -1 0.000 0 0 7 0 0 5");
    fprintf (fp, "\t%s\n", "7650 1800 7650 1650 7425 1650 7425 1800 7650 1800");
    fprintf (fp, "%s\n", "2 1 1 1 0 7 50 -1 -1 4.000 0 0 -1 1 0 2");
    fprintf (fp, "\t%s\n", "2 1 2.00 90.00 135.00");
    fprintf (fp, "\t%s\n", "8925 2850 7650 1800");
    fprintf (fp, "%s\n", "2 2 0 1 0 17 50 -1 20 0.000 0 0 -1 0 0 5");
    fprintf (fp, "\t%s\n", "7725 1050 8250 1050 8250 1575 7725 1575 7725 1050");
    fprintf (fp, "%s\n", "2 2 0 1 0 17 50 -1 20 0.000 0 0 -1 0 0 5");
    fprintf (fp, "\t%s\n", "6825 1050 7350 1050 7350 1575 6825 1575 6825 1050");
    fprintf (fp, "%s\n", "2 2 0 1 0 17 50 -1 20 0.000 0 0 -1 0 0 5");
    fprintf (fp, "\t%s\n", "6825 1875 7350 1875 7350 2400 6825 2400 6825 1875");
    fprintf (fp, "%s\n", "2 1 1 1 0 7 50 -1 -1 4.000 0 0 -1 1 0 2");
    fprintf (fp, "\t%s\n", "2 1 3.00 90.00 135.00");
    fprintf (fp, "\t%s\n", "9000 675 8250 1050");
    fprintf (fp, "%s\n", "4 0 0 50 -1 1 14 0.0000 0 195 870 9150 675 Sub-array\\001");
    fprintf (fp, "%s\n", "4 0 0 50 -1 1 14 0.0000 0 150 360 7350 2925 Mat\\001");
    fprintf (fp, "%s\n", "4 0 0 50 -1 1 14 0.0000 0 150 1695 8250 3150 Central "
                         "Predecoder\\001");
}

/* Print data/tag array parameteres */
void
print_headers (char *c, int y, int lx, int rx, FILE *fp, final_results *fs)
{
    char *color1, *color2;
    char temp1[10], temp2[10], temp3[10];
    int x = lx;
    results_mem_array *rma;
        if (strcmp (c, "Data") == 0) {
        rma = &fs->data_array;
        color1 = "8";
        color2 = "1";
    }
    else {
        rma = &fs->tag_array;
        color1 = "18";
        color2 = "4";
    }

    fprintf (fp, "%s %s %s", "4 0", color1, "50 -1 1 20 0.0000 4 255 2925 ");
    itoa (y, temp2, 10);
    lx += 100;
    itoa (lx, temp1, 10);
    fprintf (fp, "%s %s %s %s\n", temp1, temp2, c, "Array Organization\\001");
    lx += 3100;
    itoa (lx, temp1, 10);
    fprintf (fp, "%s %s %s %s %s %s", "4 0", color2, "50 -1 1 14 0.0000 4 180 "
        "3240", temp1, temp2, "(Mat height - ");

    itoa ((int)rma->mat_height, temp1, 10);
    fprintf (fp, "%s) %s", temp1, " (Mat width - ");
    itoa ((int)rma->mat_width, temp1, 10);
    fprintf (fp, "%s) (%s %s", temp1, c, "array dim. - ");
    itoa ((int)rma->bank_height, temp1, 10);
    fprintf (fp, "%s %s", temp1, "x ");
    itoa ((int)rma->bank_width, temp1, 10);
    fprintf (fp, "%s)%s\n", temp1, "\\001");
    fprintf (fp, "%s\n", "2 1 0 1 0 7 50 -1 -1 0.000 0 0 -1 0 0 2");
    itoa (x, temp1, 10);
    itoa (y+150, temp2, 10);
    itoa (rx, temp3, 10);
    fprintf (fp, "\t%s %s %s %s\n", temp1, temp2, temp3, temp2);
}

void
print_array (char *c, int ty, int by, int lx, int rx,
             FILE *fp, final_results *fs, struct fig_mat_dim *matdim)
{
    int max_box = 1600;
    int min_box = 700;
    int spacing = 0;
    int h_exceed = 0;
    int v_exceed = 0;
    int center, h_range, v_range, cur_x, cur_y, temp_ty;
    results_mem_array *rma;
    int wl, bl;
    int h, i, j, k, l, w;
    double mat_h, mat_w;

    if (strcmp (c, "Data") == 0) {
        rma = &fs->data_array;
        bl = rma->Ndbl/2;
        wl = rma->Ndwl/2;
        center = (rx + 200 - lx)/2;
        h_range = (rx - lx);
        v_range = (by - ty);

        /* calculate l and w of the mat */
        w = (h_range - (wl * spacing))/wl;
        if (w > max_box) {
            w = max_box;
        }
        else if (w < min_box) {
            w = min_box;
            h_exceed = 1;
        }
        l = (v_range - (bl * spacing))/bl;
        if (l > max_box) {
            l = max_box;
        }
        else if (l < min_box) {
            l = min_box;
            v_exceed = 1;
        }
        mat_h = rma->mat_height;
        mat_w = rma->mat_width;
        if (mat_h > mat_w) {
            l = MIN (l, w);
            w = (int)((double)l * (mat_w/mat_h));
        }
        else {
            w = MIN (l, w);
            l = (int)((double)w * (mat_h/mat_w));
        }
    }
    else {
        rma = &fs->tag_array;
        bl = rma->Ndbl/2;
        wl = rma->Ndwl/2;
        center = (rx + 200 - lx)/2;
        h_range = (rx - lx);
        v_range = (by - ty);

        /* calculate l and w of the mat */
        l = ((double) rma->mat_height * ((double) matdim->h/fs->data_array.mat_height));
        w = ((double) rma->mat_width * ((double) matdim->w/fs->data_array.mat_width));
    }

    /* draw the array */
    cur_x = center+spacing/2;
    cur_y = ty;
    j = 0;
    /* regular cases */
    /* draw all the mats */
    for (h=0; h<bl; h++) {
        for (i=0; i<wl; i++) {
            if (i == wl/2) {
                j=1;
                cur_x = center - (w + spacing/2);
            }
            /* if the mat size is big then use thicker lines */
            if (l > 600) {
                fprintf (fp, "%s\n", "2 2 0 3 0 7 50 -1 -1 0.000 0 0 -1 0 0 5");
            }
            else {
                fprintf (fp, "%s\n", "2 2 0 1 0 7 50 -1 -1 0.000 0 0 -1 0 0 5");
            }
            insert_mat (cur_x, cur_y, w, l, fp);
            if (j) {
                cur_x -= (spacing + w);
            }
            else {
                cur_x += (spacing + w);
            }
        }
        cur_y += (spacing + l);
        cur_x = center+spacing/2;
        j = 0;
    }
    matdim->h = l;
    matdim->w = w;
    matdim->top_y = ty;
    matdim->bottom_y = cur_y;
}

/* Dumps a .fig file that shows the organization of the cache for
   the given input parameters
   Fig format for version 3.2 can be found at
   http://www.xfig.org/userman/fig-format.html */
void fig_out (final_results *fs)
{
    /* Cache input parameters and other parameters calculated by cacti */
    int wl, bl, nspd, size, blk_size, assoc;
    int ntwl, ntbl, ntspd; /* tag array param */
    int tot_subarr; /* sub-array count */
    int mat_count;
    int fa; /* fully assoc? */
    char *temp1;
    char temp[20];
    char filename[100];
    char cmd[300];
    FILE *fp;
    int h, i, j, k, l, w;
    int cy;
    struct fig_mat_dim figdim;

    /* Usable area in the figure.
    If the page size is changed from letter to a3 or a2 then modify these
    values accordingly */

    int LEFT_x = (150+100);
    int RIGHT_x = 10075;
    int TOP_y = 3750; /* y coordinate value after showing Mat org. */
    int MAX_y = 13000;
    int D_y = 9000; /* Max y val data array can take */

    /* fig param */
    int thick = 1; /* default thickness of objects */

    ntwl = fs->tag_array.Ndwl;
    ntbl = fs->tag_array.Ndbl;
    ntspd = fs->tag_array.Nspd;

    wl = fs->data_array.Ndwl/2; /* each mat has four sub-arrays */
    bl = fs->data_array.Ndbl/2; /* and sub-arrays are grouped as four */
    nspd = (int) fs->data_array.Nspd;
    size = fs->params.cache_size;
    blk_size = fs->params.block_size;
    assoc = fs->params.data_associativity;
    fa = fs->params.fully_assoc;

    itoa(size, filename, 10);
    strcpy(fs->file_n, filename);
    itoa(wl*2, filename, 10);
    strcat(fs->file_n, filename);
    itoa(bl*2, filename, 10);
    strcat(fs->file_n, filename);
    itoa(ntwl, filename, 10);
    strcat(fs->file_n, filename);
    itoa(ntbl, filename, 10);
    strcat(fs->file_n, filename);
    itoa(fs->params.data_associativity, filename, 10);
    strcat(fs->file_n, filename);
    itoa(fs->params.block_size, filename, 10);
    strcat(fs->file_n, filename);
    itoa(fs->params.temp, filename, 10);
    strcat(fs->file_n, filename);
    strcpy(filename, fs->file_n);
    strcat(filename, ".fig");
    strcat(fs->file_n, ".png");

    /* create cache.fig file that shows data/tag array organization */
    printf("File name(s) = %s\n", fs->file_n);
    fp = fopen ((char *) &(filename), "w");
    if (!fp) fprintf (stderr, "Unable to create cache.fig file\n");
    /* .fig headers */
    fprintf(fp, "%s\n", "#FIG 3.2\nPortrait\nCenter\nInches\nLetter\n"
        "100.00\nSingle\n-2\n1200 2");

    /* show a sample Mat organization */
    print_mat (fp);

    /* print basic cache parameters */
    itoa (size, temp, 10);
    strcat (temp, " bytes\\001");
    fprintf (fp, "%s", "4 0 0 50 -1 1 16 0.0000 0 225 3165 750 675 Cache Size - ");
    fprintf (fp, "%s\n", temp);
    itoa (blk_size, temp, 10);
    strcat (temp, " bytes\\001");
    fprintf (fp, "%s", "4 0 0 50 -1 1 16 0.0000 0 225 3150 750 960 Block Size - ");
    fprintf (fp, "%s\n", temp);
    fprintf (fp, "%s", "4 0 0 50 -1 1 16 0.0000 0 225 2100 750 1275 Associativity - ");
    if (fa) {
        fprintf (fp, "%s\n", "Fully associative\\001");
    }
    else {
        itoa (assoc, temp, 10);
        strcat (temp, " \\001");
        fprintf (fp, "%s\n", temp);
    }
    fprintf (fp, "4 0 0 50 -1 1 14 0.0000 0 135 690 750 1575 Ndwl = ");
    itoa (fs->data_array.Ndwl, temp, 10);
    fprintf (fp, "%s\\001\n", temp);
    fprintf (fp, "4 0 0 50 -1 1 14 0.0000 0 135 645 750 1800 Ndbl = ");
    itoa (fs->data_array.Ndbl, temp, 10);
    fprintf (fp, "%s\\001\n", temp);
    fprintf (fp, "4 0 0 50 -1 1 14 0.0000 0 180 690 750 2025 Nspd = ");
    itoa (fs->data_array.Nspd, temp, 10);
    fprintf (fp, "%s\\001\n", temp);
    fprintf (fp, "4 0 0 50 -1 1 14 0.0000 0 135 660 750 2250 Ntwl = ");
    itoa (fs->data_array.Ndwl, temp, 10);
    fprintf (fp, "%s\\001\n", temp);
    fprintf (fp, "4 0 0 50 -1 1 14 0.0000 0 135 615 750 2475 Ntbl = ");
    itoa (fs->data_array.Ndbl, temp, 10);
    fprintf (fp, "%s\\001\n", temp);
    fprintf (fp, "4 0 0 50 -1 1 14 0.0000 0 180 750 750 2700 Ntspd = ");
    itoa (fs->data_array.Nspd, temp, 10);
    fprintf (fp, "%s\\001\n", temp);
    /*Show the data array organization */
    print_headers ("Data" /* data or tag */, 3750 /* y co-ordinate */, LEFT_x, RIGHT_x, fp, fs);
    print_array ("Data" /* data or tag */, 4050 /* top y */, 9000 /* bottom y */,
         LEFT_x, RIGHT_x, fp, fs, &figdim);
    cy = figdim.bottom_y;
    cy += 700;
    print_headers ("Tag", cy,  LEFT_x, RIGHT_x, fp, fs);
    cy += 400;
    print_array ("Tag", cy, 13000,  LEFT_x, RIGHT_x, fp, fs, &figdim);

    if (fclose (fp) != 0) fprintf (stderr, "Error creating cache.fig file\n");

#ifdef __linux__
    strcpy(cmd, "convert ");
    strcat(cmd, filename);
    strcat(cmd, " ");
    strcat(cmd, fs->file_n);
    system(cmd);
    strcpy(cmd, "mv ");
    strcat(cmd, fs->file_n);
    strcat(cmd, " webapps/cacti/docroot/");
#ifdef WEB_CACTI
    system(cmd);
#endif
    /* remove the .fig file */
    strcpy(cmd, "rm ");
    strcat(cmd, filename);
    system(cmd);
#endif
}

void output_data_csv(final_results* result)
{
	 FILE *fptr;
	 //errno_t err;

	 fptr = fopen("out.csv", "a");
	 if(fptr == NULL){
		 printf("File out.csv could not be opened successfully\n");
	 }
	 else{
		//fprintf(fptr, "%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s", "Tech node (nm),", "Capacity (bytes),", "Associativity,", "Access time (ns), ", "Cycle time (ns), ", "Dynamic read energy (nJ), ", "Dynamic read power (mW), ", "Leakage read power(mW), ", "Area (mm2), ", "Ndwl, ", "Ndbl, ", "Nspd, ", "Ntwl, ", "Ntbl, ", "Ntspd\n");
		 //fprintf(fptr, "%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s", "Tech node (nm),", "Capacity (bytes),", "Associativity,", "Access time (ns), ", "Cycle time (ns), ", "Dynamic read energy (nJ), ", "Dynamic read power (mW), ", "Leakage read power(mW), ", "Area (mm2), ", "Ndwl, ", "Ndbl, ", "Nspd, ", "Ntwl, ", "Ntbl, ", "Ntspd", ",", "Area efficiency", ",", "Aspect ratio\n");
		 //fprintf(fptr, "%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s", "Tech node (nm),", "Capacity (bytes),", "Number of banks," , "Associativity,", "Access time (ns), ", "Cycle time (ns), ", "Dynamic read energy (nJ), ", "Dynamic read power (mW), ", "Leakage read power(mW), ", "Area one bank (mm2), " , "Area all banks (mm2), ", "Ndwl, ", "Ndbl, ", "Nspd, ", "Ntwl, ", "Ntbl, ", "Ntspd", ",", "Area efficiency", ",", "Aspect ratio\n");
		 //fprintf(fptr, "%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s", "Tech node (nm),", "Capacity (bytes),", "Number of banks," , "Associativity,", "Access time (ns), ", "Cycle time (ns), ", "Dynamic read energy (nJ), ", "Dynamic read power (mW), ", "Leakage read power(mW), ", "Area (mm2), " , "Ndwl, ", "Ndbl, ", "Nspd, ", "Ntwl, ", "Ntbl, ", "Ntspd, ",  "Area efficiency, ", "Aspect ratio\n");
		 //fprintf(fptr, "%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s", "Tech node (nm),", "Capacity (bytes),", "Number of banks," , "Associativity,", "Output width (bits),", "Access time (ns), ", "Random cycle time (ns), ", "Multisubbank interleave cycle time (ns), ", "Refresh period (microsec), ", "DRAM array availability (%), ", "Dynamic read energy (nJ), ", "Dynamic write energy (nJ), ", "Dynamic read power (mW), ", "Standby leakage per bank(mW), ", "Leakage per bank with leak power management (mW), ","Refresh power as percentage of standby leakage, ", "Area (mm2), " , "Ndwl, ", "Ndbl, ", "Nspd, ", "Ndcm, ", "Ndsam, ", "Ntwl, ", "Ntbl, ", "Ntspd, ", "Ntcm, ", "Ntsam, ",  "Area efficiency, ",  "Resistance per unit micron (ohm-micron), ",  "Capacitance per unit micron (fF per micron), ",  "Unit-length wire delay (ps), ",  "FO4 delay (ps), ", "Area opt (perc), ", "Delay opt (perc), ", "Repeater opt (perc), ", "Aspect ratio\n");
		//fprintf(fptr, "%f%s%d%s%d%s%f%s%f%s%f%s%f%s%f%s%f%s%d%s%d%s%f%s%d%s%d%s%d%s", result->params.tech_size*1000, ",", result->params.cache_size, "," , result->params.tag_associativity, ",", result->result.access_time*1e+9, ",", result->result.cycle_time*1e+9, ",", result->result.total_power.readOp.dynamic*1e+9, ",", result->result.total_power.readOp.dynamic*1000/result->result.cycle_time, ",", result->result.total_power.readOp.leakage*1000, ",", result->area.totalarea, ",", result->result.best_Ndwl, ",", result->result.best_Ndbl, ",", result->result.best_Nspd, ",", result->result.best_Ntwl, ",", result->result.best_Ntbl, ",", result->result.best_Ntspd, "\n");
		//fprintf(fptr, "%f%s%d%s%d%s%f%s%f%s%f%s%f%s%f%s%f%s%d%s%d%s%f%s%d%s%d%s%d%s", result->params.tech_size*1000, ",", result->params.cache_size, "," , result->params.tag_associativity, ",", result->result.access_time*1e+9, ",", result->result.cycle_time*1e+9, ",", result->result.total_power.readOp.dynamic*1e+9, ",", result->result.total_power.readOp.dynamic*1000/result->result.cycle_time, ",", result->result.total_power.readOp.leakage*1000, ",", result->area.totalarea, ",", result->result.best_Ndwl, ",", result->result.best_Ndbl, ",", result->result.best_Nspd, ",", result->result.best_Ntwl, ",", result->result.best_Ntbl, ",", result->result.best_Ntspd, "\n");
		 //fprintf(fptr, "%f%s%d%s%d%s%f%s%f%s%f%s%f%s%f%s%f%s%d%s%d%s%f%s%d%s%d%s%d%s%f%s%f%s", result->params.tech_size*1000, ",", result->params.cache_size, "," , result->params.tag_associativity, ",", result->result.access_time*1e+9, ",", result->result.cycle_time*1e+9, ",", result->result.total_power.readOp.dynamic*1e+9, ",", result->result.total_power.readOp.dynamic*1000/result->result.cycle_time, ",", result->result.total_power.readOp.leakage*1000, ",", result->area.totalarea, ",", result->result.best_Ndwl, ",", result->result.best_Ndbl, ",", result->result.best_Nspd, ",", result->result.best_Ntwl, ",", result->result.best_Ntbl, ",", result->result.best_Ntspd, ",", result->area.efficiency, ",", result->area.aspect_ratio_total, "\n");
		 //fprintf(fptr, "%f%s%d%s%d%s%d%s%f%s%f%s%f%s%f%s%f%s%f%s%f%s%d%s%d%s%f%s%d%s%d%s%d%s%f%s%f%s", result->params.tech_size*1000, ",", result->params.cache_size * result->result.subbanks, "," , result->result.subbanks, "," , result->params.tag_associativity, ",", result->result.access_time*1e+9, ",", result->result.cycle_time*1e+9, ",", result->result.total_power.readOp.dynamic*1e+9, ",", result->result.total_power.readOp.dynamic*1000/result->result.cycle_time, ",", result->result.total_power.readOp.leakage*1000, ",", result->area.totalarea, "," , result_area_macro, "," , result->result.best_Ndwl, ",", result->result.best_Ndbl, ",", result->result.best_Nspd, ",", result->result.best_Ntwl, ",", result->result.best_Ntbl, ",", result->result.best_Ntspd, ",", result->area.efficiency, ",", result->area.aspect_ratio_total, "\n");
		 fprintf(fptr, "%f%s%d%s%d%s%d%s%d%s%f%s%f%s%f%s%f%s%f%s%f%s%f%s%f%s%f%s%f%s%f%s%f%s%d%s%d%s%f%s%d%s%d%s%d%s%d%s%f%s%d%s%d%s%f%s%f%s%f%s%f%s%f%s%f%s%f%s%f%s%f%s", result->params.tech_size*1000, ",", result->params.cache_size, "," , result->params.number_banks, "," , result->params.tag_associativity, ",", result->params.nr_bits_out, ",", result->access_time*1e+9, ",", result->cycle_time*1e+9, ",", result->data_array.multisubbank_interleave_cycle_time*1e+9, ",", result->data_array.dram_refresh_period*1e+6, ",", result->data_array.dram_array_availability, ",",result->power.readOp.dynamic*1e+9, ",", result->power.writeOp.dynamic*1e+9, ",", result->power.readOp.dynamic*1000/result->cycle_time, ",", result->power.readOp.leakage*1000, ",", result->leak_power_with_sleep_transistors_in_mats*1000, ",", result->data_array.refresh_power / result->data_array.total_power.readOp.leakage, ",", result->area, ",", result->data_array.Ndwl, ",", result->data_array.Ndbl, ",", result->data_array.Nspd, ",", result->data_array.deg_bitline_muxing, ",", result->data_array.Ndsam, ",", result->tag_array.Ndwl, ",", result->tag_array.Ndbl, ",", result->tag_array.Nspd, "," , result->data_array.deg_bitline_muxing, ",", result->data_array.Ndsam, ",", result->area_efficiency, ",", wire_inside_mat_r_per_micron, ",", wire_inside_mat_c_per_micron / 1e-15, ",", unit_length_wire_delay / 1e-12, ",", FO4 / 1e-12, "," , MAXAREACONSTRAINT_PERC, ",", MAXACCTIMECONSTRAINT_PERC, ",", MAX_PERC_DIFF_IN_DELAY_FROM_BEST_DELAY_REPEATER_SOLUTION,",", result->data_array.all_banks_height / result->data_array.all_banks_width, "\n");
		fclose(fptr);
	 }
}